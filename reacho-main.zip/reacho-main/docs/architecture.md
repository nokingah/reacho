# Architecture

## Goal

Reacho is a browser-side local data workspace, not a generic web scraper. Its job is to understand the page the user is actively viewing, normalize useful data through a site adapter, retain relationships across pages, and expose the result through a persistent side panel.

## High-level architecture

```text
Current tab
   |
   v
Content bridge
   |
   v
Adapter runtime
   |
   +----> media discovery
   |
   v
Normalized entities + relationships
   |
   v
Local workspace (IndexedDB first)
   |
   +----> side-panel inspector/query UI
   +----> explicit JSON export
   +----> explicit downloads

Optional later:
Extension <-> native host <-> arbitrary filesystem / large media / indexing
```

## Runtime components

### 1. Content bridge

Runs only where permission has been granted.

Responsibilities:
- inspect DOM;
- read page-visible metadata and embedded state where feasible;
- provide a stable page context to adapters;
- relay adapter output to the extension runtime.

Non-goals:
- broad permanent access to every site;
- arbitrary background crawling;
- hidden collection.

### 2. Adapter runtime

Adapters encapsulate site-specific knowledge.

The runtime should:
- determine which adapter matches the active page;
- execute adapter methods with a bounded context;
- validate normalized output;
- report diagnostics and failures visibly;
- keep adapter-specific selectors and parsing rules outside core code.

### 3. Workspace store

MVP storage should use IndexedDB.

Responsibilities:
- persist pages, collections/albums, assets, metadata, and relationships;
- deduplicate entities by stable source identity where possible;
- retain source URLs and timestamps;
- support inspection/export;
- permit schema migration.

SQLite or a native database should not be added until concrete scale or query requirements justify it.

### 4. Side panel

The side panel is the primary interface.

It should show:
- matched adapter;
- active permissions;
- current page identity;
- extracted entities;
- relationships;
- diagnostics;
- discovered media;
- actions such as Extract, Refresh, Export, and Save.

A toolbar popup may be used only for a minimal launcher/status surface.

### 5. Downloads

MVP should support explicit user-triggered downloads for ordinary accessible resources.

The system must distinguish:
- direct downloadable resource;
- unresolved or segmented media;
- protected/unsupported media.

It must not imply universal video-download capability.

### 6. Optional native host

Not part of MVP.

Add only when needed for:
- arbitrary filesystem destinations;
- large media libraries;
- retention policies;
- checksums/deduplication;
- background indexing;
- local processing outside extension constraints.

## Permissions strategy

Default:
- Manifest V3;
- `activeTab`;
- `scripting`;
- `sidePanel`;
- `storage`;
- `downloads` only if MVP media save is implemented.

Persistent host permissions should be explicit per-site opt-in.

`webRequest`, main-world instrumentation, or `userScripts` should be added only when a proven adapter requires them.

## Technology bias

Initial implementation should prefer:
- TypeScript;
- vanilla HTML/CSS or a very small UI layer;
- browser-native APIs;
- IndexedDB;
- minimal dependencies.

Do not introduce React, a backend server, SQLite, Electron, or a native helper without a measured need.

## Relationship to TEDdy

Reacho and TEDdy may share concepts, fixtures, schemas, or adapter logic, but they serve different execution modes.

Reacho:
- interactive;
- user-in-the-loop;
- current-tab oriented;
- local workspace and inspection.

TEDdy-style automation:
- scripted browser workflows;
- repeatability;
- navigation automation;
- heavier capture and orchestration.

Do not embed a full Playwright runtime into the extension.
