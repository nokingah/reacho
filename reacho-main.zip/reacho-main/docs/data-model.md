# Data Model

## Goal

Reacho should treat browsing output as structured local data with provenance and relationships, not as disconnected scraped text.

## Core entities

### Page

Represents a source page observed by the user.

Suggested fields:
- `id`;
- `url`;
- `canonicalUrl`;
- `title`;
- `site`;
- `adapterId`;
- `observedAt`;
- `metadata`.

### Collection

A generic grouping entity. A site adapter may label it as an album, gallery, thread, playlist, project, or another site-specific concept.

Suggested fields:
- `id`;
- `sourceId`;
- `kind`;
- `title`;
- `sourceUrl`;
- `metadata`.

### Asset

Represents a discovered item or media/resource record.

Suggested fields:
- `id`;
- `sourceId`;
- `kind`;
- `sourceUrl`;
- `mimeType`;
- `width`;
- `height`;
- `duration`;
- `metadata`;
- `localState`.

### Person / Creator

Optional normalized entity when adapters can identify a creator, author, artist, uploader, or participant.

## Relationships

Relationships should be first-class records.

Examples:

```text
Page -> contains -> Collection
Collection -> contains -> Asset
Collection -> createdBy -> Person
Page -> linksTo -> Page
Asset -> derivedFrom -> Asset
```

Suggested shape:

```ts
interface Relationship {
  id: string;
  fromId: string;
  type: string;
  toId: string;
  observedAt: string;
  sourcePageId?: string;
}
```

## Identity

Prefer stable source IDs supplied by the site.

Fallback order:
1. site-native stable ID;
2. canonical source URL;
3. adapter-defined deterministic compound key;
4. generated local ID.

Do not use DOM position alone as durable identity.

## Provenance

Every normalized record should retain enough information to answer:
- where did this come from?
- which adapter produced it?
- when was it observed?
- from which source page?
- was it user-edited later?

## Local state

Local-only state should be separated from source metadata.

Examples:
- downloaded;
- local path or handle reference;
- favorite/tagged;
- ignored;
- last inspected;
- checksum.

This prevents refreshes from overwriting user workspace state.

## Schema evolution

Persist a schema version.

Migrations should be explicit and testable. Avoid premature abstractions, but do not store an unversioned free-form JSON heap as the only persistence model.

## Query direction

MVP can begin with simple indexed lookup and inspection.

Useful future queries include:
- collections discovered from this page;
- assets not yet saved;
- all assets associated with a creator;
- collections visited but not fully extracted;
- duplicate assets across collections;
- records produced by a specific adapter version.
