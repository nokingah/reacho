# Roadmap

## Phase 0 - Design baseline

Status: done.

Deliverables:
- README;
- architecture;
- adapter contract;
- normalized data model;
- privacy/security posture;
- implementation issue with MVP acceptance criteria.

Exit gate:
- implementation can begin without inventing core product boundaries.

## Phase 1 - Browser MVP

Status: implemented (see [implementation notes](implementation.md) and [testing](testing.md)).

Goal: prove the workflow on one real site.

Required:
- Manifest V3 Chromium extension;
- Brave/Chrome load-unpacked workflow;
- side panel;
- `activeTab`-first permissions;
- adapter registry;
- one real site adapter;
- Extract action;
- normalized Page -> Collection -> Asset persistence;
- IndexedDB workspace;
- raw data inspector;
- visible adapter diagnostics;
- explicit JSON export;
- ordinary media discovery;
- explicit browser download for supported direct resources.

Acceptance:
1. User opens a supported page.
2. Reacho identifies the correct adapter.
3. User selects Extract.
4. Structured entities and relationships appear in the side panel.
5. Data persists across navigation/reload.
6. User can navigate to a related collection/album page and Reacho links newly extracted data to prior records.
7. User can inspect raw normalized JSON.
8. User can export the relevant workspace records.
9. A supported direct media resource can be explicitly saved.
10. No page/extracted data is sent to a remote service.

Non-goals:
- universal scraper;
- arbitrary background crawler;
- React requirement;
- backend service;
- native helper;
- DRM handling;
- full TEDdy/Playwright automation.

## Phase 2 - Adapter workbench

Goal: make Reacho meaningfully hackable.

Candidate work:
- adapter editor;
- test current adapter against active tab;
- saved HTML fixtures;
- expected JSON fixture tests;
- richer diagnostics;
- adapter versioning;
- optional trusted user-authored adapters.

Exit gate:
- an adapter can be changed and validated without rebuilding unrelated extension code.

## Phase 3 - Advanced page/network access

Only add proven requirements.

Candidates:
- embedded application-state helpers;
- narrowly scoped fetch/XHR observation;
- main-world instrumentation;
- request metadata observation;
- richer media manifest discovery.

Gate:
- each added permission/API must be justified by at least one concrete adapter limitation.

## Phase 4 - Filesystem/native workspace

Add only when browser-native storage becomes the bottleneck.

Candidates:
- user-selected workspace directory;
- native messaging helper;
- large media persistence;
- checksums;
- deduplication;
- retention policies;
- local indexing/search.

## Phase 5 - Local intelligence

Optional:
- structured queries;
- local search;
- local model integration;
- summaries over explicitly selected local workspace records.

Remote AI must not become a hidden dependency.
