# Adapter Model

## Purpose

Adapters are the main extension point in Reacho. Each adapter contains the minimum site-specific knowledge required to recognize, extract, relate, and optionally discover media from pages on one site or site family.

## Proposed contract

The exact TypeScript types may evolve, but implementation should preserve this conceptual boundary:

```ts
interface SiteAdapter {
  id: string;
  version: string;
  matches(url: URL): boolean;

  discover?(ctx: PageContext): Promise<Discovery[]>;
  extract(ctx: PageContext): Promise<Entity[]>;
  relate?(entities: Entity[], ctx: PageContext): Promise<Relationship[]>;
  media?(ctx: PageContext): Promise<MediaCandidate[]>;
}
```

## PageContext

A page context should expose only the capabilities an adapter needs, for example:

```ts
interface PageContext {
  url: URL;
  title: string;
  document: Document;
  now: string;
}
```

If later adapters require page-world state, request metadata, or helper APIs, extend the context deliberately instead of exposing unrestricted extension internals.

## Adapter responsibilities

An adapter should:
- detect whether it applies;
- extract stable source identifiers when available;
- return normalized entities rather than arbitrary HTML blobs;
- preserve source URL and provenance;
- discover relationships;
- report recoverable extraction problems;
- avoid side effects during pure extraction.

## Core responsibilities

The core should:
- choose an adapter;
- validate output;
- persist entities and relationships;
- handle deduplication;
- display diagnostics;
- manage permissions;
- perform downloads only after user action;
- keep adapters isolated from storage implementation details.

## Development workflow

The intended loop is:

```text
Open page
 -> adapter matches
 -> Extract
 -> inspect normalized result
 -> edit adapter
 -> Test
 -> compare diagnostics/result
 -> save
```

## Fixtures

Add fixture support early.

Suggested layout:

```text
fixtures/
  example-site/
    album-normal.html
    album-empty.html
    expected/
      album-normal.json
      album-empty.json
```

Fixture tests should:
- run without contacting the live site;
- assert normalized entities;
- assert key relationships;
- make selector breakage obvious;
- avoid embedding sensitive authenticated page content in the repository.

## User-authored adapters

Not MVP.

A later advanced mode may allow trusted user-authored scripts using browser user-script APIs. This must be explicitly enabled and visually distinguish built-in adapters from editable user code.

Do not execute arbitrary third-party adapter code by default.

## Adapter quality bar

A production-ready adapter should have:
- a stable ID;
- explicit match rules;
- fixture coverage;
- deterministic normalized output for fixtures;
- visible failure diagnostics;
- documented permissions beyond `activeTab`, if any;
- no hidden network exfiltration.
