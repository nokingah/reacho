# Reference: existing video-stats workflow

## Why this exists

Before Reacho, a small working Manifest V3 extension was already used successfully to inspect album pages and summarize video metadata. Reacho should preserve that useful behavior while moving it behind the adapter/workspace model.

Source archive supplied during design:

- archive SHA-256: `5257dc372cbc808a8ecc7c033adb0ebd8e262440da1e8bd9add6dc3c1315b992`
- `background.js` SHA-256: `dfe0daa0d346a94abfc94a51d0a2a2892c0ae1d9fede0c200893ac530a33c872`
- `manifest.json` SHA-256: `fe7bb09f8e54134cc02c51a7bc02025eeb91a215541a63e2bd330818219de8f4`

The source used a placeholder `example.com` host pattern, so this document describes behavior rather than assuming a production hostname.

## Existing behavior

The extension has two useful flows.

### 1. Album-page video analysis

On demand, it inspects visible `<video>` elements on the current page.

It:

1. collects every `video` element;
2. ignores hidden or zero-size elements;
3. de-duplicates elements that share the same `currentSrc`, `src`, or poster;
4. requests metadata when a video has not loaded it yet;
5. waits up to roughly 1.5 seconds for metadata;
6. records duration;
7. classifies orientation as horizontal or vertical from `videoWidth` / `videoHeight`;
8. buckets resolution as 1080p, 720p, or SD using video height;
9. produces:
   - video count;
   - total duration;
   - horizontal/vertical counts;
   - horizontal/vertical duration totals;
   - resolution counts.

The current extension renders those results in an in-page HUD.

### 2. Album-list enhancement

On listing pages, it modifies existing album thumbnails.

It reads:

- `.album-thumbnail-container`;
- `.album-videos`;
- `.album-images`;
- `.album-bottom-views`.

It then:

- makes image count more prominent;
- combines video count and view count into a large label;
- reduces opacity for albums with zero videos;
- can auto-run when a matching albums URL finishes loading.

This proves that the top-level/listing page already exposes useful collection metadata that a Reacho adapter can normalize without navigating into every album.

## Reacho mapping

These behaviors should become adapter output instead of DOM-only presentation.

### Album-list page

The site adapter should emit one `Collection` per album card, with whatever is available from the listing page:

```text
Collection
  sourceUrl
  title / sourceId when available
  metadata.videoCount
  metadata.imageCount
  metadata.viewCount
```

The adapter should also emit:

```text
Page -> contains -> Collection
```

The side panel may reproduce useful visual cues, but DOM restyling should not be the primary data model.

### Album page

The album adapter should emit one `Asset` per de-duplicated video and collection-level aggregates.

Suggested per-video fields:

```text
Asset
  kind: video
  sourceUrl
  posterUrl
  durationSeconds
  width
  height
  orientation
  resolutionClass
```

Suggested collection-derived fields:

```text
videoCount
totalDurationSeconds
horizontalCount
verticalCount
horizontalDurationSeconds
verticalDurationSeconds
resolutionCounts
```

## URL-first requirement

The important improvement over the existing hotkey workflow is that the user should not need to manually open every album before collecting its video statistics.

Reacho should support a bounded URL-probe workflow for a discovered or pasted album URL.

### Strategy A: fetch and parse

Prefer this when the album page contains sufficient information in server-rendered HTML or embedded application state.

```text
album URL
 -> extension fetch with explicit site permission
 -> adapter parses HTML/embedded state
 -> normalized collection/assets
 -> local workspace
```

Benefits:

- fast;
- no visible navigation;
- low overhead.

Limitation:

- does not execute the site's JavaScript;
- cannot obtain metadata that only appears after media/page runtime initialization.

### Strategy B: render and extract

Use this only when the working adapter requires a real rendered page.

```text
album URL
 -> create inactive/background tab
 -> wait for adapter readiness
 -> run normal loaded-page extraction
 -> persist result
 -> close temporary tab
```

This reproduces the semantics of the known-working `analyzeVideos()` flow while removing manual navigation.

Requirements:

- explicit user action or an explicitly bounded queue;
- never become an unrestricted crawler;
- expose status/errors in the side panel;
- close temporary tabs it created;
- respect per-site concurrency/rate limits;
- preserve cookies/session naturally through the browser profile without logging or exporting credentials.

## Acquisition capability

Adapters should declare what they can do rather than forcing every site through one mechanism.

Conceptually:

```ts
type AcquisitionMode =
  | "loaded-page"
  | "fetch"
  | "rendered-url";

interface AdapterCapabilities {
  acquisition: AcquisitionMode[];
}
```

The core can then choose the least expensive supported path:

1. already-loaded page;
2. fetch-and-parse;
3. rendered URL probe.

A failure of fetch-and-parse should not silently fall back to rendered probing unless the adapter explicitly supports that path.

## MVP use case

This existing workflow should be the first concrete behavior used to prove the Reacho architecture.

A successful MVP should demonstrate:

1. discover album URLs and basic counts from a listing page;
2. select or paste one album URL;
3. obtain the same useful video aggregates currently produced by the hotkey script;
4. do so without requiring the user to manually browse into the album;
5. retain the album/video records locally;
6. link the resulting assets back to the collection discovered on the listing page;
7. show exactly which acquisition path was used.

## Regression target

For the same rendered album page, Reacho's loaded-page extraction should match the reference workflow for:

- de-duplicated visible video count;
- total duration within normal metadata timing tolerance;
- horizontal/vertical classification;
- horizontal/vertical duration totals;
- 1080p / 720p / SD bucket counts.

Any intentional divergence should be documented and tested.
