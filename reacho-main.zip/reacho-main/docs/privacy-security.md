# Privacy and Security

## Default posture

Reacho is local-first.

Core operation should not require:
- analytics;
- telemetry;
- hosted databases;
- cloud sync;
- remote LLMs;
- external extraction services.

The intended data path is:

```text
website -> browser -> Reacho -> local workspace
```

## Least privilege

Use `activeTab` as the default access model.

Persistent host permissions:
- must be opt-in;
- should be scoped to adapters that need them;
- must be visible in settings;
- should be removable without breaking unrelated adapters.

## Network behavior

Built-in adapters should not send page contents or extracted records to external services unless the user explicitly configures such an integration.

Any future remote integration must:
- be disabled by default;
- identify the destination;
- explain what data is sent;
- provide a way to inspect/disable it.

## Stored data

MVP extracted data lives in browser-local storage/IndexedDB.

The UI should make it possible to:
- inspect stored records;
- export records;
- clear site-specific records;
- clear the workspace.

## Sensitive pages

Reacho should not silently run on:
- browser internal pages;
- extension stores;
- password managers;
- authentication pages;
- financial/medical or similarly sensitive sites without explicit adapter/user intent.

The project should prefer explicit adapter matching over broad generic extraction.

## Adapter trust

Built-in adapters are repository-controlled code.

Future user-authored adapters:
- must be explicitly enabled;
- should be visually marked as user code;
- should not be fetched and executed from arbitrary remote URLs by default.

## Media

Reacho may discover and save ordinary accessible resources when the user is authorized to do so.

Out of scope:
- DRM circumvention;
- bypassing access controls;
- credential theft;
- stealth capture;
- defeating paywalls or protected delivery systems.

## Diagnostics

Diagnostics should be useful without leaking page content unnecessarily.

Avoid:
- logging entire authenticated DOMs by default;
- persisting cookies, auth headers, or bearer tokens;
- including secrets in exported diagnostics.

## Native helper

If a native helper is added later:
- use a narrow command protocol;
- validate all paths and commands;
- do not expose a general shell;
- authenticate/allow-list the extension ID;
- document filesystem access clearly.
