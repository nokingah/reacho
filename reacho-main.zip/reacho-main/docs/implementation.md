# Phase 1 implementation notes

This page maps the Phase 1 browser MVP onto the design docs and lists where
the implementation departs from them, with reasons.

## Layout

```text
static/                     manifest.json, sidepanel.html/.css, icons (copied to dist/)
src/
  shared/types.ts           adapter contract, drafts, workspace records
  shared/url.ts             URL normalization, restricted-page guard
  adapters/
    registry.ts             built-in adapter list + URL matching
    commons/                Wikimedia Commons adapter (the real site adapter)
    demo/                   fixture adapter for fixtures/demo-site
    lib/dom.ts              shared DOM/media helpers for adapters
  content/bridge.ts         injected on demand; runs one adapter in the page
  core/
    runtime.ts              bounded adapter execution, timings, diagnostics
    structured-data.ts      JSON-LD / meta collection for the inspector
    normalize.ts            validation, identity resolution, provenance, media classification
    identity.ts             identity fallback order, record ids
    media.ts                direct / segmented / unresolved / unsupported classification
    merge.ts                re-observation merge rules
    workspace.ts            IndexedDB store, migrations, page graph, clearing
    export.ts               JSON export format
  background/service-worker.ts   toolbar click -> open side panel (grants activeTab)
  panel/                    side panel UI (vanilla TS + a 30-line DOM helper)
fixtures/                   saved Commons pages, demo site, expected JSON
tests/                      Vitest unit, fixture, workspace, and guard tests
scripts/                    build (esbuild), demo server, e2e (Playwright)
```

## Runtime flow

1. Clicking the toolbar button (or pressing Alt+Shift+R) opens the side panel.
   That same user action grants `activeTab` for the current tab.
2. The panel reads the tab URL. Only with access does Chrome expose it. The
   panel refuses browser-internal pages and extension stores, then picks an
   adapter with `matches(url)`.
3. **Extract** injects `content.js` into the tab's top frame with
   `chrome.scripting.executeScript` and calls the bridge. The bridge runs
   `discover → extract → relate → media` with per-phase timeouts and error
   isolation, and returns JSON-safe drafts plus diagnostics.
4. The panel normalizes the drafts (`core/normalize.ts`) and commits them to
   IndexedDB, merging with existing records (`core/merge.ts`).
5. Views read the stored *page graph*: records observed on the page, every
   stored relationship touching them, and the records at the other end. That
   is how links to records captured on earlier pages appear.
6. **Save** calls `chrome.downloads.download` for `direct` media only.
   **Export** builds JSON in the panel and hands a `blob:` URL to
   `chrome.downloads`.

## Identity

Identity follows `docs/data-model.md`:

| Strategy | Record id | Example |
| --- | --- | --- |
| site-native ID | `<type>:<site>:id:<sourceId>` | `asset:commons.wikimedia.org:id:File:Foo.jpg` |
| canonical URL | `<type>:url:<normalized url>` | `page:url:https://commons.wikimedia.org/wiki/Category:X` |
| compound key | `<type>:<site>:key:<key>` | |
| local (warns) | `<type>:local:<uuid>` | |

URL normalization drops fragments and well-known tracking parameters
(`utm_*`, `fbclid`, …) and sorts the query.

Page identity is always URL-based (canonical link if it is same-origin,
otherwise the tab URL), so page ids do not depend on which adapter ran.

For Commons, page titles (`Category:…`, `File:…`) are the site-native IDs.
They are the only stable key visible both in a listing and on the item's own
page. Numeric page IDs are kept in metadata.

## Design deviations (called out explicitly)

1. **Adapter output types are split from stored records.**
   `docs/adapters.md` uses `Entity` and `Relationship` for adapter output. The
   implementation names adapter output `EntityDraft` / `RelationshipDraft`,
   which refer to each other by adapter-local `ref`, and keeps `EntityRecord` /
   `RelationshipRecord` for normalized, persisted data. This keeps adapters
   free of storage details (ids, provenance, merge rules), as the core
   responsibilities require. The method signatures of `SiteAdapter` are
   unchanged.
2. **`PageContext` gained `report(level, code, message)`.** Adapters must
   "report recoverable extraction problems". This is the one deliberate
   context extension. Nothing else of the extension runtime is exposed.
3. **`SiteAdapter` has extra descriptive fields**: `name`, `description`,
   `site` (identity namespace), `hostPermissions` (the optional per-site
   pattern), and `demo` (UI label). Tests enforce that the manifest's
   `optional_host_permissions` equal the union of `hostPermissions`.
4. **Page → Collection uses `describes`.** For the collection a page *is
   about* (a category or album page), the relationship type is
   `page —describes→ collection`. `contains` is used for listings
   (`collection —contains→ asset`, `page —contains→ collection` on a creator
   page). The data-model examples are illustrative, so this does not conflict.
5. **No `storage` permission.** The architecture lists `storage`, but the
   workspace lives in IndexedDB, which needs no permission. Least privilege
   wins. `downloads` is included because media save is implemented.
6. **Media records are persisted** in their own store. They are not only
   ephemeral per run, so download state and the Media tab survive reloads.
7. **A fixture/demo adapter ships next to the real one.** It is marked as
   such in the UI. It provides an offline, deterministic end-to-end path and
   cases the real site does not exercise: segmented (HLS) and `blob:` media,
   and a deliberately malformed page.
8. **Toolbar click opens the panel from the service worker**
   (`action.onClicked` → `sidePanel.open`) instead of
   `openPanelOnActionClick`, so the click reliably grants `activeTab`.
9. **Side panel runs under a strict CSP** (`connect-src 'none'`, no remote
   images), so extension pages cannot make network requests even by mistake.

## Known limitations

- `activeTab` is a per-tab, temporary grant. After cross-page navigation the
  user may need to click the toolbar button again; the panel says so. The
  optional **Allow on this site** grant removes that friction for one
  adapter's site.
- The Commons adapter reads desktop-skin markup and MediaWiki's embedded
  `RLCONF` config. A Commons redesign would surface as diagnostics and as
  fixture-test diffs.
- Gallery-listed audio files have no thumbnail, so no original-file URL can be
  derived from the category page. The file page still provides it.
- Downloads for live Commons could not be verified from the CI sandbox:
  upload.wikimedia.org rate-limited the sandbox's shared egress IP (HTTP 429,
  inconsistent even for identical `curl` requests). Download behavior is
  verified end-to-end against the demo server. When a download fails, the
  panel shows **download interrupted** with the browser's error.
