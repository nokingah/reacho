# Testing

## Automated

```sh
npm install
npm run check        # typecheck + unit/fixture tests + build
npm run e2e          # real-Chromium acceptance run against the local demo site
npm run e2e -- --live   # also exercises live commons.wikimedia.org
```

- **Unit tests** (`tests/*.test.ts`, Vitest): URL normalization, identity
  fallback order, media classification, normalization/validation, merge rules.
- **Adapter fixture tests**: each adapter runs against saved HTML in
  `fixtures/` (jsdom). Normalized output is compared with
  `fixtures/*/expected/*.json`; selector breakage shows up as a diff.
  Regenerate on purpose with `UPDATE_FIXTURES=1 npm test`, then review the
  diff.
- **Workspace tests** use `fake-indexeddb`. They cover persistence across
  reopening, cross-page linking, local state surviving re-extraction, clearing,
  and export contents.
- **Guards**: the manifest stays least-privilege and its optional host
  patterns equal the adapters' declarations; `src/` contains no network APIs.
- **E2E** (`scripts/e2e.mjs`, Playwright driving Chromium): loads the built
  extension unpacked and drives the panel through extract → navigate → link →
  reload → inspect → save media → export → failure diagnostics. Screenshots
  and `report.json` go to `artifacts/e2e/`.

  Automation cannot click the browser toolbar, which is how a user grants
  `activeTab`. The e2e run therefore loads a **test-only copy** of `dist/`
  whose manifest pre-grants the adapters' optional host patterns. The shipped
  manifest does not change. The toolbar/`activeTab` flow is covered by the
  manual procedure below.

## Manual acceptance procedure (Brave / Chrome)

Prerequisites: `npm install && npm run build`.

1. **Load.** Open `chrome://extensions` (or `brave://extensions`), enable
   Developer mode, choose **Load unpacked**, and select `dist/`. Reacho loads
   with no errors. The install prompt asks only for "Download files"; no site
   access is requested.
2. **Grant access the activeTab way.** Open
   <https://commons.wikimedia.org/wiki/Category:Lighthouses_in_Maine>. Click
   the Reacho toolbar button, or press Alt+Shift+R. The side panel opens:
   - Adapter: **Wikimedia Commons** `wikimedia-commons@0.1.0`
   - Access: **Temporary `activeTab` grant for this tab**
3. **Extract.** Press **Extract**. The notice reports saved entities. The
   **Records** tab lists the page, the category collection, subcategory
   collections, and file assets. **Links** shows
   `category-page —describes→ category`,
   `category —contains→ image|category`, and parent categories
   `—contains→` this category.
4. **Navigate to a related collection.** Click the subcategory **Avery Rock
   Light** in the page. Click the toolbar button again, because activeTab may
   not survive navigation. Press **Extract**. The notice says some records
   were already in the workspace. Under **Links → Linked from earlier pages**,
   *Lighthouses in Maine* and the earlier page appear marked **recorded on an
   earlier page**. The Avery Rock Light record shows **seen on 2 pages**.
5. **Persistence.** Reload the tab and close and reopen the side panel. The
   stored records for the page reappear before you extract again. The footer
   shows workspace totals.
6. **Inspect.** Open **Inspector**. *Stored records for this page* shows
   normalized JSON with `provenance`. *Last run: raw adapter output* shows the
   adapter's drafts. *Page structured data* shows JSON-LD and meta tags.
   Clicking a record in Records or Links opens it here.
7. **Media and download.** Open a file page, e.g.
   <https://commons.wikimedia.org/wiki/File:Bass_Harbor_Head_Light_-_the_Bell.jpg>.
   Click the toolbar button, then Extract → **Media**. The original
   `upload.wikimedia.org` file is listed as **direct**. Press **Save**. The
   file lands in `Downloads/Reacho/commons.wikimedia.org/` and the item shows
   **download complete**.
8. **Export.** Press **Export JSON → Page**. A file
   `Downloads/Reacho/exports/reacho-page-<timestamp>.json` is written. Open
   it: it contains `format: "reacho-export"`, every entity has `sourceUrl`
   (where applicable) and `provenance` (`adapterId`, `adapterVersion`,
   `firstObservedAt`, `lastObservedAt`, `sourcePageIds`), and relationships
   carry `sourcePageIds`.
9. **Failure diagnostics (demo site).** Run `npm run demo` and open
   <http://localhost:8787/albums/broken.html>. Click the toolbar button, then
   Extract. A red notice appears, the **Diagnostics** tab is marked, and it
   lists `extract/state-unparsed` plus the phase timings.
10. **Segmented and page-scoped media (demo site).** On
    <http://localhost:8787/albums/harbor.html>, the Media tab lists the SVGs
    and PDF as **direct** (with Save), the `.m3u8` as **segmented**, and the
    `blob:` preview as **unsupported**. The last two have no Save button.
11. **No access, no extraction.** Switch to a tab you have not clicked
    Reacho on, or to `chrome://settings`. The panel reports no access or a
    restricted page, and Extract is disabled.
12. **Optional persistent access.** On a Commons page, click **Allow on this
    site** and approve the browser prompt. Access now reads *Persistent (opted
    in)*, and the toolbar click is no longer needed on that site. **Revoke
    persistent access** removes it.
13. **No remote data.** With DevTools open on the side panel (right-click →
    Inspect), the Network tab shows no requests while extracting or
    exporting. The extension CSP sets `connect-src 'none'`.
14. **Clearing.** **Clear → Site data** asks for a second click, then removes
    this site's records. **Clear → Workspace** removes everything.
