# Reacho

Reacho is a privacy-first, local browser workspace for extracting, relating, inspecting, and optionally archiving data from websites you are already browsing.

**Status:** Phase 1 browser MVP implemented (Manifest V3, Brave/Chrome). See [Getting started](#getting-started).

## What Reacho is

Reacho sits beside the page as a browser side panel and runs small, site-specific **adapters**. An adapter can:

- recognize supported pages;
- extract structured data from the DOM or page state;
- relate entities discovered across pages, such as a top-level page -> album -> asset;
- discover ordinary downloadable media and other resources;
- save extracted records in a local workspace;
- expose the current page, extracted records, relationships, and adapter diagnostics in a small UI;
- support a developer workflow for testing and iterating on adapters.

The default model is local-first:

```text
website -> browser -> Reacho -> local workspace
```

No cloud service, analytics service, or hosted model is required for core operation.

## Initial target

The first implementation should target Chromium-compatible browsers, especially Brave and Chrome, using Manifest V3.

### MVP

- persistent side-panel UI;
- `activeTab`-first permission model;
- adapter registry and one real site adapter;
- DOM/page-state extraction;
- normalized Page -> Collection/Album -> Asset relationships;
- local IndexedDB workspace;
- raw structured-data inspector;
- adapter test/diagnostic surface;
- ordinary media discovery;
- explicit downloads through browser APIs;
- JSON export.

### Later

- editable/user-authored adapters;
- fixture-based adapter tests;
- narrowly scoped request observation or page-world instrumentation;
- user-selected filesystem workspace;
- optional native helper for large media libraries, retention, deduplication, indexing, or arbitrary filesystem destinations;
- local querying and optional local-model integrations.

## Design principles

1. **Local by default.** Page contents and extracted data should not leave the machine unless the user explicitly configures an integration.
2. **Least privilege.** Prefer `activeTab` and per-site opt-in permissions over permanent access to all sites.
3. **Adapters over one-off scrapers.** Site knowledge belongs in small modules with a common contract.
4. **Structured data first.** Normalize useful entities and relationships instead of treating extraction as text scraping.
5. **Hackable, but bounded.** Adapter development should be easy without silently turning the extension into an unrestricted automation engine.
6. **Inspectable behavior.** The UI should show what matched, what was extracted, which permissions are active, and what will be written or downloaded.
7. **No universal media promise.** Reacho may save ordinary accessible resources; DRM circumvention is explicitly out of scope.
8. **Separate interactive browsing from heavy automation.** Reacho can share concepts with TEDdy-style browser tooling without absorbing a full Playwright automation runtime.

## Getting started

Requirements: Node.js 20+ and a Chromium browser (Brave or Chrome 116+).

```sh
npm install
npm run build          # outputs the unpacked extension to dist/
```

1. Open `chrome://extensions` (or `brave://extensions`) and enable **Developer mode**.
2. Choose **Load unpacked** and select `dist/`.
3. Visit a supported page, for example
   <https://commons.wikimedia.org/wiki/Category:Lighthouses_in_Maine>, and click
   the Reacho toolbar button (or press Alt+Shift+R). The click opens the side
   panel and grants one-time `activeTab` access to that tab.
4. Press **Extract**. Then browse into a subcategory or file page and extract
   again; the new records link to the ones captured earlier.

Built-in adapters:

| Adapter | Pages | Notes |
| --- | --- | --- |
| `wikimedia-commons` | `commons.wikimedia.org/wiki/Category:*`, `File:*` | Real site adapter. Category → subcategory/file, file → original download. |
| `reacho-demo` | `http://localhost:8787` (`npm run demo`) | Deterministic fixture site: segmented/blob media and a deliberately broken page. |

Development:

```sh
npm run check          # typecheck + tests + build
npm run watch          # rebuild on change (reload the extension afterwards)
npm run demo           # serve fixtures/demo-site on http://localhost:8787
npm run e2e            # real-Chromium acceptance run (add -- --live for Commons)
```

The manual acceptance procedure is in [docs/testing.md](docs/testing.md).
Implementation notes and design deviations are in
[docs/implementation.md](docs/implementation.md).

## Repository layout

```text
reacho/
├── README.md
├── docs/                 design docs, implementation notes, testing
├── static/               manifest.json, side panel HTML/CSS, icons
├── src/
│   ├── adapters/         adapter registry + site adapters (commons, demo)
│   ├── content/          on-demand content bridge
│   ├── core/             runtime, normalization, identity, IndexedDB workspace, export
│   ├── background/       service worker (toolbar -> side panel)
│   ├── panel/            side panel UI (vanilla TypeScript)
│   └── shared/           types and URL helpers
├── fixtures/             saved pages + expected normalized JSON
├── tests/                Vitest tests
└── scripts/              build, demo server, e2e
```

## Documentation

- [Architecture](docs/architecture.md)
- [Adapter model](docs/adapters.md)
- [Data model](docs/data-model.md)
- [Privacy and security](docs/privacy-security.md)
- [Roadmap and acceptance gates](docs/roadmap.md)
- [Phase 1 implementation notes](docs/implementation.md)
- [Testing and manual acceptance](docs/testing.md)

## Status

**Phase 1 (browser MVP): implemented.** Runtime dependencies: none. Dev dependencies: TypeScript, esbuild, Vitest, jsdom, fake-indexeddb, playwright-core.

The implementation stays deliberately small; further APIs and abstractions should be added only when a real adapter proves they are needed.

## Scope boundary

Reacho is intended for data and media the user is authorized to access and save. It should not include DRM bypass, credential theft, stealth collection, or hidden exfiltration.
