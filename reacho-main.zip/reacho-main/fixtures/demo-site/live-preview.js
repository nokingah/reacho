// Gives the "live preview" video a page-scoped blob: URL, like MediaSource players do.
document.getElementById('live').src = URL.createObjectURL(new Blob(['not really a video'], { type: 'video/webm' }));
