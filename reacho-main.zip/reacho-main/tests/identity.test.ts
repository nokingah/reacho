import { describe, expect, it } from 'vitest';
import { pageIdForUrl, relationshipId, resolveIdentity } from '../src/core/identity';

describe('resolveIdentity', () => {
  const site = 'example.org';

  it('prefers the site-native id', () => {
    expect(resolveIdentity({ type: 'asset', sourceId: ' 42 ', sourceUrl: 'https://example.org/a/42', key: 'k' }, site)).toEqual({
      id: 'asset:example.org:id:42',
      strategy: 'sourceId',
      value: '42',
    });
  });

  it('falls back to the normalized canonical URL', () => {
    expect(resolveIdentity({ type: 'collection', sourceUrl: 'https://Example.org/album/7?utm_source=feed#top' }, site)).toEqual({
      id: 'collection:url:https://example.org/album/7',
      strategy: 'canonicalUrl',
      value: 'https://example.org/album/7',
    });
  });

  it('then to the adapter compound key', () => {
    expect(resolveIdentity({ type: 'asset', key: 'album-7/item-3' }, site).id).toBe('asset:example.org:key:album-7/item-3');
  });

  it('finally to a generated local id', () => {
    const id = resolveIdentity({ type: 'asset' }, site, () => 'fixed');
    expect(id).toEqual({ id: 'asset:local:fixed', strategy: 'local', value: 'fixed' });
  });

  it('ignores an invalid source URL', () => {
    expect(resolveIdentity({ type: 'asset', sourceUrl: 'blob:https://x/1', key: 'k' }, site).strategy).toBe('compoundKey');
  });

  it('is deterministic for the same input', () => {
    const input = { type: 'asset' as const, sourceId: 'File:A.jpg' };
    expect(resolveIdentity(input, site).id).toBe(resolveIdentity({ ...input }, site).id);
  });

  it('namespaces site-native ids by site and type', () => {
    expect(resolveIdentity({ type: 'asset', sourceId: '1' }, 'a.test').id).not.toBe(resolveIdentity({ type: 'asset', sourceId: '1' }, 'b.test').id);
    expect(resolveIdentity({ type: 'asset', sourceId: '1' }, site).id).not.toBe(resolveIdentity({ type: 'collection', sourceId: '1' }, site).id);
  });
});

describe('page and relationship ids', () => {
  it('builds page ids from normalized URLs', () => {
    expect(pageIdForUrl('https://example.org/x?b=2&a=1#f')).toBe('page:url:https://example.org/x?a=1&b=2');
    expect(pageIdForUrl('chrome://newtab')).toBeNull();
  });

  it('builds deterministic relationship ids', () => {
    expect(relationshipId('a', 'contains', 'b')).toBe('a|contains|b');
  });
});
