import { describe, expect, it } from 'vitest';
import { demoAdapter } from '../src/adapters/demo';
import { expectMatchesFixture, extractFixture } from './helpers';

const BASE = 'http://localhost:8787';

describe('reacho-demo adapter', () => {
  it('only matches the local demo server', () => {
    expect(demoAdapter.matches(new URL(`${BASE}/`))).toBe(true);
    expect(demoAdapter.matches(new URL('http://127.0.0.1:8787/albums/harbor.html'))).toBe(true);
    expect(demoAdapter.matches(new URL('http://localhost:3000/'))).toBe(false);
    expect(demoAdapter.matches(new URL('https://example.com/'))).toBe(false);
  });

  it('extracts the creator page: person and album stubs', async () => {
    const { normalized } = await extractFixture(demoAdapter, 'demo-site/index.html', `${BASE}/`);
    expect(normalized.entities.filter((e) => e.type === 'collection').map((e) => e.sourceId)).toEqual(['a-harbor', 'a-dunes', 'a-broken']);
    expect(normalized.entities.find((e) => e.type === 'person')).toMatchObject({ id: 'person:reacho-demo.test:id:c-ada', title: 'Ada Lumen' });
    expectMatchesFixture(normalized, 'demo-site/expected/index.json');
  });

  it('extracts an album from embedded state and classifies its media', async () => {
    const { raw, normalized } = await extractFixture(demoAdapter, 'demo-site/albums/harbor.html', `${BASE}/albums/harbor.html`);
    expect(raw.structuredData.jsonLd).toHaveLength(1);
    expect(normalized.entities.filter((e) => e.type === 'asset')).toHaveLength(5);
    const delivery = Object.fromEntries(normalized.media.map((m) => [m.filename, m.delivery]));
    expect(delivery).toEqual({ 'harbor-1.svg': 'direct', 'harbor-2.svg': 'direct', 'harbor-notes.pdf': 'direct', 'harbor.m3u8': 'segmented' });
    expectMatchesFixture(normalized, 'demo-site/expected/harbor.json');
  });

  it('surfaces malformed embedded state as an error diagnostic', async () => {
    const { normalized } = await extractFixture(demoAdapter, 'demo-site/albums/broken.html', `${BASE}/albums/broken.html`);
    expect(normalized.diagnostics).toContainEqual(expect.objectContaining({ level: 'error', code: 'state-unparsed', phase: 'extract' }));
    expect(normalized.entities).toHaveLength(1); // only the Page record
  });

  it('reports a thrown adapter error with its phase', async () => {
    const { runAdapter } = await import('../src/core/runtime');
    const { JSDOM } = await import('jsdom');
    const dom = new JSDOM('<main data-demo-page="album"></main>', { url: `${BASE}/x` });
    const exploding = { ...demoAdapter, relate: async () => { throw new Error('boom'); } };
    const raw = await runAdapter(exploding, { document: dom.window.document, url: `${BASE}/x`, title: '', now: '2026-01-01T00:00:00Z' });
    expect(raw.diagnostics).toContainEqual({ level: 'error', code: 'relate-failed', message: 'Error: boom', phase: 'relate' });
    expect(raw.timings.find((t) => t.phase === 'relate')).toMatchObject({ ok: false });
  });
});
