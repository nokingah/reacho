import { describe, expect, it } from 'vitest';
import { commonsAdapter, originalFromThumb } from '../src/adapters/commons';
import { findAdapterForUrl } from '../src/adapters/registry';
import { expectMatchesFixture, extractFixture } from './helpers';

const CATEGORY_URL = 'https://commons.wikimedia.org/wiki/Category:Lighthouses_in_Maine';
const SUBCATEGORY_URL = 'https://commons.wikimedia.org/wiki/Category:Avery_Rock_Light';
const FILE_URL = 'https://commons.wikimedia.org/wiki/File:Bass_Harbor_Head_Light_-_the_Bell.jpg';

describe('wikimedia-commons adapter: matching', () => {
  it('matches category and file pages only', () => {
    expect(commonsAdapter.matches(new URL(CATEGORY_URL))).toBe(true);
    expect(commonsAdapter.matches(new URL(FILE_URL))).toBe(true);
    expect(commonsAdapter.matches(new URL('https://commons.wikimedia.org/wiki/Main_Page'))).toBe(false);
    expect(commonsAdapter.matches(new URL('https://commons.wikimedia.org/wiki/Special:UserLogin'))).toBe(false);
    expect(commonsAdapter.matches(new URL('https://en.wikipedia.org/wiki/Category:Lighthouses'))).toBe(false);
    expect(commonsAdapter.matches(new URL('http://commons.wikimedia.org/wiki/Category:X'))).toBe(false);
  });

  it('is chosen by the registry', () => {
    expect(findAdapterForUrl(FILE_URL)?.id).toBe('wikimedia-commons');
    expect(findAdapterForUrl('https://example.com/')).toBeUndefined();
  });

  it('derives original file URLs from thumbnails', () => {
    expect(
      originalFromThumb(
        'https://thumb.wikimedia.org/wikipedia/commons/thumb/4/40/Avery_Rock_Light%2C_Maine.jpg/120px-Avery_Rock_Light%2C_Maine.jpg?utm_source=x',
        new URL(CATEGORY_URL),
      ),
    ).toBe('https://upload.wikimedia.org/wikipedia/commons/4/40/Avery_Rock_Light%2C_Maine.jpg');
    expect(originalFromThumb('https://example.com/x.jpg', new URL(CATEGORY_URL))).toBeUndefined();
  });
});

describe('wikimedia-commons adapter: category page fixture', () => {
  it('extracts the category, subcategories, files, and parent categories', async () => {
    const { raw, normalized } = await extractFixture(commonsAdapter, 'commons/category-lighthouses-in-maine.html', CATEGORY_URL);
    expect(raw.timings.every((t) => t.ok)).toBe(true);
    expect(raw.discoveries).toContainEqual({ kind: 'files', label: 'Files listed', count: 4 });

    const self = normalized.entities.find((e) => e.id === 'collection:commons.wikimedia.org:id:Category:Lighthouses_in_Maine');
    expect(self).toMatchObject({ kind: 'category', title: 'Lighthouses in Maine', metadata: { pageId: 1118777, totalSubcategories: 16, totalFiles: 28 } });

    const bell = normalized.entities.find((e) => e.sourceId === 'File:Bass_Harbor_Head_Light_-_the_Bell.jpg');
    expect(bell).toMatchObject({ type: 'asset', kind: 'image', width: 1200, height: 1600, mimeType: 'image/jpeg' });
    expect(bell?.metadata.originalUrl).toBe('https://upload.wikimedia.org/wikipedia/commons/a/a9/Bass_Harbor_Head_Light_-_the_Bell.jpg');

    const rels = normalized.relationships.map((r) => `${r.fromId} -${r.type}-> ${r.toId}`);
    expect(rels).toContain(`${normalized.pageId} -describes-> collection:commons.wikimedia.org:id:Category:Lighthouses_in_Maine`);
    expect(rels).toContain('collection:commons.wikimedia.org:id:Category:Lighthouses_in_Maine -contains-> collection:commons.wikimedia.org:id:Category:Avery_Rock_Light');
    expect(rels).toContain('collection:commons.wikimedia.org:id:Category:Lighthouses_in_Maine -contains-> asset:commons.wikimedia.org:id:File:Bass_Harbor_Head_Light_-_the_Bell.jpg');
    expect(rels).toContain('collection:commons.wikimedia.org:id:Category:Coasts_of_Maine -contains-> collection:commons.wikimedia.org:id:Category:Lighthouses_in_Maine');

    expect(normalized.media.filter((m) => m.delivery === 'direct')).toHaveLength(4);
    expect(normalized.diagnostics.filter((d) => d.level !== 'info')).toEqual([]);
    expectMatchesFixture(normalized, 'commons/expected/category-lighthouses-in-maine.json');
  });

  it('extracts a subcategory page whose parent links back to the earlier category', async () => {
    const { normalized } = await extractFixture(commonsAdapter, 'commons/category-avery-rock-light.html', SUBCATEGORY_URL);
    const rels = normalized.relationships.map((r) => `${r.fromId} -${r.type}-> ${r.toId}`);
    expect(rels).toContain('collection:commons.wikimedia.org:id:Category:Lighthouses_in_Maine -contains-> collection:commons.wikimedia.org:id:Category:Avery_Rock_Light');
    expectMatchesFixture(normalized, 'commons/expected/category-avery-rock-light.json');
  });
});

describe('wikimedia-commons adapter: file page fixture', () => {
  it('extracts the asset with its original file as a direct media resource', async () => {
    const { normalized } = await extractFixture(commonsAdapter, 'commons/file-bass-harbor-head-light-bell.html', FILE_URL);
    const asset = normalized.entities.find((e) => e.type === 'asset');
    expect(asset).toMatchObject({
      id: 'asset:commons.wikimedia.org:id:File:Bass_Harbor_Head_Light_-_the_Bell.jpg',
      mimeType: 'image/jpeg',
      width: 1200,
      height: 1600,
      metadata: { pageId: 195318059, fileSize: '283 KB', license: 'https://creativecommons.org/licenses/by-sa/4.0/' },
    });
    expect(normalized.media).toEqual([
      expect.objectContaining({
        url: 'https://upload.wikimedia.org/wikipedia/commons/a/a9/Bass_Harbor_Head_Light_-_the_Bell.jpg',
        delivery: 'direct',
        filename: 'Bass_Harbor_Head_Light_-_the_Bell.jpg',
        assetId: asset!.id,
      }),
    ]);
    expectMatchesFixture(normalized, 'commons/expected/file-bass-harbor-head-light-bell.json');
  });

  it('reports a page whose markup changed instead of failing silently', async () => {
    const { JSDOM } = await import('jsdom');
    const { runAdapter } = await import('../src/core/runtime');
    const dom = new JSDOM('<html><head><title>x</title></head><body><p>redesigned</p></body></html>', { url: FILE_URL });
    const raw = await runAdapter(commonsAdapter, { document: dom.window.document, url: FILE_URL, title: 'x', now: '2026-01-01T00:00:00Z' });
    const codes = raw.diagnostics.map((d) => d.code);
    expect(codes).toContain('rlconf-missing');
    expect(codes).toContain('original-missing');
  });
});
