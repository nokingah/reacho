import { IDBFactory } from 'fake-indexeddb';
import { beforeEach, describe, expect, it } from 'vitest';
import { commonsAdapter } from '../src/adapters/commons';
import { demoAdapter } from '../src/adapters/demo';
import { buildExport } from '../src/core/export';
import { SCHEMA_VERSION, Workspace } from '../src/core/workspace';
import { extractFixture } from './helpers';

const CATEGORY = { fixture: 'commons/category-lighthouses-in-maine.html', url: 'https://commons.wikimedia.org/wiki/Category:Lighthouses_in_Maine' };
const SUBCATEGORY = { fixture: 'commons/category-avery-rock-light.html', url: 'https://commons.wikimedia.org/wiki/Category:Avery_Rock_Light' };
const FILE = { fixture: 'commons/file-bass-harbor-head-light-bell.html', url: 'https://commons.wikimedia.org/wiki/File:Bass_Harbor_Head_Light_-_the_Bell.jpg' };

const MAINE = 'collection:commons.wikimedia.org:id:Category:Lighthouses_in_Maine';
const AVERY = 'collection:commons.wikimedia.org:id:Category:Avery_Rock_Light';
const BELL = 'asset:commons.wikimedia.org:id:File:Bass_Harbor_Head_Light_-_the_Bell.jpg';

let factory: IDBFactory;
beforeEach(() => {
  factory = new IDBFactory();
});

async function extractAndCommit(ws: Workspace, page: { fixture: string; url: string }, now: string, adapter = commonsAdapter) {
  const { normalized } = await extractFixture(adapter, page.fixture, page.url, now);
  const summary = await ws.commit(normalized);
  return { normalized, summary };
}

describe('Workspace (IndexedDB)', () => {
  it('records its schema version on creation', async () => {
    const ws = await Workspace.open(factory, 'test');
    expect(await ws.schemaVersion()).toBe(SCHEMA_VERSION);
    expect((await ws.stats()).entities).toBe(0);
  });

  it('persists records across reopening the database (page reload / panel restart)', async () => {
    const first = await Workspace.open(factory, 'test');
    const { normalized } = await extractAndCommit(first, CATEGORY, '2026-01-01T00:00:00.000Z');
    first.close();

    const second = await Workspace.open(factory, 'test');
    const page = await second.findPage(normalized.pageId, null);
    expect(page?.title).toBe('Category:Lighthouses in Maine - Wikimedia Commons');
    const graph = await second.pageGraph(normalized.pageId);
    expect(graph.entities.map((e) => e.id)).toContain(BELL);
    expect(graph.media).toHaveLength(4);
  });

  it('finds a stored page by the tab URL', async () => {
    const ws = await Workspace.open(factory, 'test');
    await extractAndCommit(ws, CATEGORY, '2026-01-01T00:00:00.000Z');
    expect((await ws.findPage(null, CATEGORY.url))?.type).toBe('page');
  });

  it('links a subcategory page to the category captured on an earlier page', async () => {
    const ws = await Workspace.open(factory, 'test');
    const top = await extractAndCommit(ws, CATEGORY, '2026-01-01T00:00:00.000Z');
    const sub = await extractAndCommit(ws, SUBCATEGORY, '2026-01-01T00:05:00.000Z');

    // The Avery Rock Light collection existed as a listing stub and is now merged, not duplicated.
    expect(sub.summary.previouslyKnown).toContain(AVERY);
    expect(sub.summary.previouslyKnown).toContain(`${MAINE}|contains|${AVERY}`);
    const avery = await ws.getEntity(AVERY);
    expect(avery?.provenance.sourcePageIds).toEqual([top.normalized.pageId, sub.normalized.pageId]);
    expect(avery?.provenance.observations).toBe(2);
    expect(avery?.metadata).toMatchObject({ files: 2, pageId: 44544028, wikidataItem: 'Q790659' });

    // From the subcategory page, the graph reaches the earlier top-level page.
    const graph = await ws.pageGraph(sub.normalized.pageId);
    const maine = graph.entities.find((e) => e.id === MAINE)!;
    expect(maine.metadata).toMatchObject({ totalFiles: 28 }); // detail from the earlier page is kept
    const parentLink = graph.relationships.find((r) => r.id === `${MAINE}|contains|${AVERY}`)!;
    expect(parentLink.sourcePageIds).toEqual([top.normalized.pageId, sub.normalized.pageId]);
    expect(parentLink.firstObservedAt).toBe('2026-01-01T00:00:00.000Z');

    // New assets from the subcategory hang off the merged collection.
    expect(graph.relationships.some((r) => r.fromId === AVERY && r.toId === 'asset:commons.wikimedia.org:id:File:Avery_Rock_Light,_Maine.jpg')).toBe(true);
  });

  it('links a file page to the category and asset listed on an earlier page', async () => {
    const ws = await Workspace.open(factory, 'test');
    const top = await extractAndCommit(ws, CATEGORY, '2026-01-01T00:00:00.000Z');
    const file = await extractAndCommit(ws, FILE, '2026-01-01T00:10:00.000Z');

    expect(file.summary.previouslyKnown).toEqual(expect.arrayContaining([BELL, MAINE, `${MAINE}|contains|${BELL}`]));
    const graph = await ws.pageGraph(file.normalized.pageId);
    expect(graph.entities.map((e) => e.id)).toContain(top.normalized.pageId); // reached via Page -describes-> Maine
    const bell = graph.entities.find((e) => e.id === BELL)!;
    expect(bell.provenance.sourcePageIds).toEqual([top.normalized.pageId, file.normalized.pageId]);
    expect(bell.metadata).toMatchObject({ license: 'https://creativecommons.org/licenses/by-sa/4.0/', thumbnailUrl: expect.any(String) });
  });

  it('never overwrites local state when records are re-extracted', async () => {
    const ws = await Workspace.open(factory, 'test');
    const { normalized } = await extractAndCommit(ws, FILE, '2026-01-01T00:00:00.000Z');
    const media = normalized.media[0]!;
    await ws.setDownload([media.id, BELL], { state: 'complete', downloadId: 7, url: media.url, filename: 'Reacho/x.jpg', requestedAt: '2026-01-01T00:01:00.000Z' }, '2026-01-01T00:01:00.000Z');
    await extractAndCommit(ws, FILE, '2026-01-02T00:00:00.000Z');

    const graph = await ws.pageGraph(normalized.pageId);
    expect(graph.localState.find((s) => s.id === BELL)?.download?.state).toBe('complete');
    expect(await ws.findByDownloadId(7)).toHaveLength(2);
    expect(graph.entities.find((e) => e.id === BELL)?.provenance.observations).toBe(2);
  });

  it('clears one site without touching others, and clears everything', async () => {
    const ws = await Workspace.open(factory, 'test');
    await extractAndCommit(ws, CATEGORY, '2026-01-01T00:00:00.000Z');
    await extractAndCommit(ws, { fixture: 'demo-site/index.html', url: 'http://localhost:8787/' }, '2026-01-01T00:00:00.000Z', demoAdapter);

    await ws.clearSite('commons.wikimedia.org');
    const left = await ws.all();
    expect(left.entities.length).toBeGreaterThan(0);
    expect(left.entities.every((e) => e.site === 'reacho-demo.test')).toBe(true);
    expect(left.media.every((m) => m.site === 'reacho-demo.test')).toBe(true);

    await ws.clearAll();
    expect(await ws.stats()).toMatchObject({ entities: 0, relationships: 0, media: 0, localState: 0 });
  });

  it('exports a page graph with provenance and source information', async () => {
    const ws = await Workspace.open(factory, 'test');
    await extractAndCommit(ws, CATEGORY, '2026-01-01T00:00:00.000Z');
    const { normalized } = await extractAndCommit(ws, FILE, '2026-01-01T00:10:00.000Z');
    const exported = buildExport(await ws.pageGraph(normalized.pageId), { kind: 'page', pageId: normalized.pageId, url: FILE.url }, '2026-01-01T01:00:00.000Z', '0.1.0');

    const parsed = JSON.parse(JSON.stringify(exported));
    expect(parsed).toMatchObject({ format: 'reacho-export', formatVersion: 1, schemaVersion: SCHEMA_VERSION, scope: { kind: 'page', url: FILE.url } });
    expect(parsed.counts.entities).toBe(parsed.entities.length);
    for (const e of parsed.entities) {
      expect(e.provenance).toMatchObject({ adapterId: 'wikimedia-commons', adapterVersion: '0.1.0', firstObservedAt: expect.any(String), sourcePageIds: expect.any(Array) });
    }
    const bell = parsed.entities.find((e: { id: string }) => e.id === BELL);
    expect(bell.sourceUrl).toBe(FILE.url);
    expect(parsed.relationships.find((r: { id: string }) => r.id === `${MAINE}|contains|${BELL}`).sourcePageIds).toHaveLength(2);
    expect(parsed.media[0].url).toMatch(/^https:\/\/upload\.wikimedia\.org\//);
  });
});
