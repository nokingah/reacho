import { describe, expect, it } from 'vitest';
import { mergeEntity, mergeRelationship } from '../src/core/merge';
import type { EntityRecord, RelationshipRecord } from '../src/shared/types';

const prov = (at: string, page: string) => ({
  adapterId: 'a',
  adapterVersion: '1',
  firstObservedAt: at,
  lastObservedAt: at,
  sourcePageIds: [page],
  observations: 1,
  userEdited: false,
});

const detail: EntityRecord = {
  id: 'collection:s:id:1',
  type: 'collection',
  kind: 'album',
  site: 's',
  identity: { strategy: 'sourceId', value: '1' },
  sourceId: '1',
  title: 'Album',
  metadata: { itemCount: 5, cover: 'x.jpg' },
  provenance: prov('2026-01-02T00:00:00Z', 'page:album'),
};

describe('mergeEntity', () => {
  it('keeps detail fields when a later listing stub lacks them', () => {
    const stub: EntityRecord = { ...detail, kind: 'collection', title: 'Album (renamed)', metadata: { listedItemCount: 5 }, provenance: prov('2026-01-03T00:00:00Z', 'page:home') };
    const merged = mergeEntity(detail, stub);
    expect(merged.kind).toBe('album');
    expect(merged.title).toBe('Album (renamed)');
    expect(merged.metadata).toEqual({ itemCount: 5, cover: 'x.jpg', listedItemCount: 5 });
    expect(merged.provenance).toMatchObject({
      firstObservedAt: '2026-01-02T00:00:00Z',
      lastObservedAt: '2026-01-03T00:00:00Z',
      sourcePageIds: ['page:album', 'page:home'],
      observations: 2,
    });
  });

  it('never changes identity', () => {
    const merged = mergeEntity(detail, { ...detail, id: 'other', identity: { strategy: 'local', value: 'x' } });
    expect(merged.id).toBe(detail.id);
    expect(merged.identity).toEqual(detail.identity);
  });
});

describe('mergeRelationship', () => {
  it('accumulates source pages and observation window', () => {
    const base: RelationshipRecord = {
      id: 'a|contains|b', fromId: 'a', type: 'contains', toId: 'b',
      observedAt: '2026-01-02T00:00:00Z', firstObservedAt: '2026-01-02T00:00:00Z',
      sourcePageId: 'p1', sourcePageIds: ['p1'], site: 's', adapterId: 'x', adapterVersion: '1',
    };
    const merged = mergeRelationship(base, { ...base, observedAt: '2026-01-05T00:00:00Z', firstObservedAt: '2026-01-05T00:00:00Z', sourcePageId: 'p2', sourcePageIds: ['p2'] });
    expect(merged).toMatchObject({ firstObservedAt: '2026-01-02T00:00:00Z', observedAt: '2026-01-05T00:00:00Z', sourcePageId: 'p2', sourcePageIds: ['p1', 'p2'] });
  });
});
