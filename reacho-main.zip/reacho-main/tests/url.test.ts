import { describe, expect, it } from 'vitest';
import { normalizeUrl, patternsForUrl, restrictedReason } from '../src/shared/url';

describe('normalizeUrl', () => {
  it('drops fragments and tracking parameters and sorts the query', () => {
    expect(normalizeUrl('HTTPS://Example.COM:443/a/b?z=1&utm_source=x&a=2&fbclid=abc#frag')).toBe('https://example.com/a/b?a=2&z=1');
  });

  it('removes an empty query string', () => {
    expect(normalizeUrl('https://example.com/x?utm_campaign=y')).toBe('https://example.com/x');
  });

  it('resolves relative URLs against a base', () => {
    expect(normalizeUrl('/wiki/File:A.jpg', 'https://commons.wikimedia.org/wiki/Category:B')).toBe('https://commons.wikimedia.org/wiki/File:A.jpg');
  });

  it('rejects non-http(s) and invalid input', () => {
    expect(normalizeUrl('blob:https://example.com/123')).toBeNull();
    expect(normalizeUrl('javascript:alert(1)')).toBeNull();
    expect(normalizeUrl('not a url')).toBeNull();
  });
});

describe('restrictedReason', () => {
  it('refuses browser-internal pages and extension stores', () => {
    expect(restrictedReason('chrome://extensions')).toMatch(/does not run/);
    expect(restrictedReason('brave://settings')).toMatch(/does not run/);
    expect(restrictedReason('https://chromewebstore.google.com/detail/x')).toMatch(/extension stores/);
    expect(restrictedReason('https://chrome.google.com/webstore/detail/x')).toMatch(/extension stores/);
    expect(restrictedReason(undefined)).toMatch(/No access/);
  });

  it('allows ordinary web pages', () => {
    expect(restrictedReason('https://commons.wikimedia.org/wiki/Category:X')).toBeNull();
  });
});

describe('patternsForUrl', () => {
  const patterns = ['http://localhost/*', 'http://127.0.0.1/*', 'https://*.example.org/*'];

  it('selects only the patterns covering the current site', () => {
    expect(patternsForUrl(patterns, 'http://localhost:8787/albums/x.html')).toEqual(['http://localhost/*']);
    expect(patternsForUrl(patterns, 'http://127.0.0.1:8787/')).toEqual(['http://127.0.0.1/*']);
    expect(patternsForUrl(patterns, 'https://a.example.org/x')).toEqual(['https://*.example.org/*']);
  });

  it('matches nothing for other sites or schemes', () => {
    expect(patternsForUrl(patterns, 'https://localhost/')).toEqual([]);
    expect(patternsForUrl(patterns, 'https://evil.test/')).toEqual([]);
    expect(patternsForUrl(patterns, undefined)).toEqual([]);
  });
});
