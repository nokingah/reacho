import { readFileSync } from 'node:fs';
import path from 'node:path';
import { describe, expect, it } from 'vitest';
import { ADAPTERS } from '../src/adapters/registry';
import { ROOT } from './helpers';

const manifest = JSON.parse(readFileSync(path.join(ROOT, 'static/manifest.json'), 'utf8'));
const pkg = JSON.parse(readFileSync(path.join(ROOT, 'package.json'), 'utf8'));

describe('manifest: least privilege', () => {
  it('is Manifest V3 with a side panel', () => {
    expect(manifest.manifest_version).toBe(3);
    expect(manifest.side_panel.default_path).toBe('sidepanel.html');
    expect(manifest.version).toBe(pkg.version);
  });

  it('requests only the documented API permissions', () => {
    expect([...manifest.permissions].sort()).toEqual(['activeTab', 'downloads', 'scripting', 'sidePanel']);
  });

  it('requests no install-time host access and no content scripts', () => {
    expect(manifest.host_permissions).toBeUndefined();
    expect(manifest.content_scripts).toBeUndefined();
    expect(JSON.stringify(manifest)).not.toContain('<all_urls>');
    expect(manifest.optional_host_permissions.every((p: string) => !p.startsWith('*://') && !p.includes('://*/'))).toBe(true);
  });

  it('lists exactly the per-site optional access adapters declare', () => {
    const declared = new Set(ADAPTERS.flatMap((a) => a.hostPermissions));
    expect(new Set(manifest.optional_host_permissions)).toEqual(declared);
  });

  it('blocks network connections from extension pages', () => {
    expect(manifest.content_security_policy.extension_pages).toContain("connect-src 'none'");
  });
});

describe('adapters', () => {
  it('have unique ids, versions, and explicit match rules', () => {
    const ids = ADAPTERS.map((a) => a.id);
    expect(new Set(ids).size).toBe(ids.length);
    for (const a of ADAPTERS) {
      expect(a.version).toMatch(/^\d+\.\d+\.\d+$/);
      expect(a.matches(new URL('https://example.com/'))).toBe(false);
    }
  });
});
