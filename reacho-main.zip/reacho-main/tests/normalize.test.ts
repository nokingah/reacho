import { describe, expect, it } from 'vitest';
import { normalizeExtraction } from '../src/core/normalize';
import type { RawExtraction } from '../src/shared/types';

function raw(partial: Partial<RawExtraction>): RawExtraction {
  return {
    adapter: { id: 'test', version: '1.0.0' },
    page: { url: 'https://site.test/albums/7?utm_source=x', title: 'Album 7', canonicalUrl: 'https://site.test/albums/7' },
    observedAt: '2026-01-01T00:00:00.000Z',
    discoveries: [],
    entities: [],
    relationships: [],
    media: [],
    structuredData: { jsonLd: [], jsonLdErrors: 0, meta: {} },
    diagnostics: [],
    timings: [],
    ...partial,
  };
}

describe('normalizeExtraction', () => {
  it('always creates a Page record with provenance', () => {
    const n = normalizeExtraction(raw({}));
    expect(n.pageId).toBe('page:url:https://site.test/albums/7');
    const page = n.entities[0]!;
    expect(page).toMatchObject({ type: 'page', url: 'https://site.test/albums/7', title: 'Album 7', site: 'site.test' });
    expect(page.provenance).toEqual({
      adapterId: 'test',
      adapterVersion: '1.0.0',
      firstObservedAt: '2026-01-01T00:00:00.000Z',
      lastObservedAt: '2026-01-01T00:00:00.000Z',
      sourcePageIds: [n.pageId],
      observations: 1,
      userEdited: false,
    });
  });

  it('ignores a cross-origin canonical link', () => {
    const n = normalizeExtraction(raw({ page: { url: 'https://site.test/a', title: '', canonicalUrl: 'https://evil.test/a' } }));
    expect(n.pageId).toBe('page:url:https://site.test/a');
    expect(n.diagnostics.map((d) => d.code)).toContain('canonical-ignored');
  });

  it('resolves refs to ids and builds Page -> Collection -> Asset relationships', () => {
    const n = normalizeExtraction(
      raw({
        entities: [
          { ref: 'album', type: 'collection', kind: 'album', sourceId: '7', title: 'Album 7' },
          { ref: 'a1', type: 'asset', sourceId: 'x1', width: 10, height: 20, metadata: { caption: 'hi' } },
        ],
        relationships: [
          { from: 'page', type: 'describes', to: 'album' },
          { from: 'album', type: 'contains', to: 'a1' },
        ],
      }),
      { site: 'site.test' },
    );
    expect(n.entities.map((e) => e.id)).toEqual(['page:url:https://site.test/albums/7', 'collection:site.test:id:7', 'asset:site.test:id:x1']);
    expect(n.relationships.map((r) => r.id)).toEqual([
      'page:url:https://site.test/albums/7|describes|collection:site.test:id:7',
      'collection:site.test:id:7|contains|asset:site.test:id:x1',
    ]);
    expect(n.relationships[1]).toMatchObject({ sourcePageId: n.pageId, sourcePageIds: [n.pageId], adapterId: 'test' });
    expect(n.diagnostics).toEqual([]);
  });

  it('reports and drops invalid adapter output instead of failing silently', () => {
    const n = normalizeExtraction(
      raw({
        entities: [
          { ref: '', type: 'asset' } as never,
          { ref: 'bad-type', type: 'widget' } as never,
          { ref: 'page', type: 'asset' },
          { ref: 'nameless', type: 'asset' },
          { ref: 'w', type: 'asset', sourceId: 'w', width: -1, sourceUrl: 'javascript:void(0)' },
        ],
        relationships: [
          { from: 'nameless', type: 'contains', to: 'ghost' },
          { from: 'w', type: 'has spaces', to: 'nameless' },
        ],
        media: [{ url: 'https://site.test/x.jpg', kind: 'image', assetRef: 'ghost' }],
      }),
      { newLocalId: () => 'L1' },
    );
    const codes = n.diagnostics.map((d) => d.code);
    expect(codes).toEqual(
      expect.arrayContaining(['entity-ref-missing', 'entity-type-invalid', 'page-ref-misused', 'identity-local', 'number-invalid', 'url-invalid', 'relationship-dangling', 'relationship-invalid', 'media-asset-unknown']),
    );
    expect(n.diagnostics.every((d) => d.phase === 'normalize')).toBe(true);
    expect(n.entities.find((e) => e.id === 'asset:local:L1')).toBeDefined();
    expect(n.entities.find((e) => e.id === 'asset:site.test:id:w')?.width).toBeUndefined();
    expect(n.relationships).toEqual([]);
  });

  it('identifies linked pages by URL so a later visit merges with them', () => {
    const n = normalizeExtraction(
      raw({ entities: [{ ref: 'next', type: 'page', sourceId: '99', sourceUrl: 'https://site.test/albums/8?utm_source=x' }] }),
    );
    const linked = n.entities.find((e) => e.sourceId === '99');
    expect(linked?.id).toBe('page:url:https://site.test/albums/8');
    expect(normalizeExtraction(raw({ page: { url: 'https://site.test/albums/8', title: '' } })).pageId).toBe(linked?.id);
  });

  it('drops a later draft that reuses a ref for a different entity', () => {
    const n = normalizeExtraction(
      raw({
        entities: [
          { ref: 'x', type: 'asset', sourceId: '1' },
          { ref: 'x', type: 'asset', sourceId: '2' },
        ],
      }),
    );
    expect(n.entities.map((e) => e.id)).not.toContain('asset:site.test:id:2');
    expect(n.diagnostics.map((d) => d.code)).toContain('entity-ref-conflict');
  });

  it('merges duplicate entities within one extraction', () => {
    const n = normalizeExtraction(
      raw({
        entities: [
          { ref: 'x', type: 'asset', sourceId: '1', title: 'One' },
          { ref: 'y', type: 'asset', sourceId: '1', mimeType: 'image/png', metadata: { a: 1 } },
        ],
      }),
    );
    const assets = n.entities.filter((e) => e.type === 'asset');
    expect(assets).toHaveLength(1);
    expect(assets[0]).toMatchObject({ title: 'One', mimeType: 'image/png', metadata: { a: 1 } });
  });

  it('drops non-JSON metadata values with a warning', () => {
    const n = normalizeExtraction(raw({ entities: [{ ref: 'x', type: 'asset', sourceId: '1', metadata: { ok: 1, bad: Number.NaN } as never }] }));
    expect(n.entities[1]!.metadata).toEqual({ ok: 1 });
    expect(n.diagnostics.map((d) => d.code)).toContain('metadata-non-json');
  });

  it('classifies media and links it to its asset', () => {
    const n = normalizeExtraction(
      raw({
        entities: [{ ref: 'a', type: 'asset', sourceId: 'a' }],
        media: [
          { url: 'https://cdn.site.test/a.jpg?utm_medium=x', kind: 'image', assetRef: 'a', filename: 'a/../b.jpg' },
          { url: 'https://cdn.site.test/live.m3u8', kind: 'video' },
          { url: 'https://cdn.site.test/a.jpg', kind: 'image' },
        ],
      }),
    );
    expect(n.media).toHaveLength(2);
    expect(n.media[0]).toMatchObject({ id: 'media:https://cdn.site.test/a.jpg', delivery: 'direct', assetId: 'asset:site.test:id:a', filename: 'a_.._b.jpg' });
    expect(n.media[1]).toMatchObject({ delivery: 'segmented' });
  });
});
