import { describe, expect, it } from 'vitest';
import { classifyMedia, safeFilename } from '../src/core/media';

describe('classifyMedia', () => {
  it('accepts ordinary direct files', () => {
    const c = classifyMedia({ url: 'https://upload.wikimedia.org/wikipedia/commons/a/a9/A.jpg?utm_source=x' });
    expect(c).toMatchObject({ delivery: 'direct', identityUrl: 'https://upload.wikimedia.org/wikipedia/commons/a/a9/A.jpg' });
  });

  it('keeps the discovered URL for retrieval so signed queries still work', () => {
    const c = classifyMedia({ url: 'https://cdn.test/f.jpg?Signature=a%2Fb&Expires=9#frag' });
    expect(c.url).toBe('https://cdn.test/f.jpg?Signature=a%2Fb&Expires=9');
    expect(c.identityUrl).toBe('https://cdn.test/f.jpg?Expires=9&Signature=a%2Fb');
  });

  it('flags HLS/DASH manifests as segmented', () => {
    expect(classifyMedia({ url: 'https://cdn.test/v/master.m3u8' }).delivery).toBe('segmented');
    expect(classifyMedia({ url: 'https://cdn.test/v/manifest', mimeType: 'application/dash+xml' }).delivery).toBe('segmented');
  });

  it('refuses page-scoped and protected resources', () => {
    expect(classifyMedia({ url: 'blob:https://site.test/abc' }).delivery).toBe('unsupported');
    expect(classifyMedia({ url: 'data:image/png;base64,AAAA' }).delivery).toBe('unsupported');
    expect(classifyMedia({ url: 'https://site.test/a.mp4', delivery: 'protected' }).delivery).toBe('unsupported');
  });

  it('does not guess about URLs without a recognizable file type', () => {
    expect(classifyMedia({ url: 'https://site.test/media?id=5' }).delivery).toBe('unresolved');
  });
});

describe('safeFilename', () => {
  it('strips path separators and reserved characters', () => {
    expect(safeFilename('../../etc/passwd', 'https://x/y')).toBe('_.._etc_passwd');
    expect(safeFilename('a:b*c?.jpg', 'https://x/y')).toBe('a_b_c_.jpg');
  });

  it('avoids names Chrome rejects as shell-integrated', () => {
    expect(safeFilename('evil.lnk', 'https://x/y')).toBe('evil_lnk');
    expect(safeFilename(undefined, 'https://x/dir/site.local')).toBe('site_local');
  });

  it('derives a name from the URL when none is given', () => {
    expect(safeFilename(undefined, 'https://x/path/Avery_Rock_Light%2C_Maine.jpg')).toBe('Avery_Rock_Light,_Maine.jpg');
  });
});
