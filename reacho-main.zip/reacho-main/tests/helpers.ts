import { readFileSync, writeFileSync, existsSync, mkdirSync } from 'node:fs';
import path from 'node:path';
import { JSDOM } from 'jsdom';
import { expect } from 'vitest';
import { runAdapter } from '../src/core/runtime';
import { normalizeExtraction } from '../src/core/normalize';
import type { NormalizedExtraction, RawExtraction, SiteAdapter } from '../src/shared/types';

export const ROOT = path.resolve(__dirname, '..');
export const FIXED_NOW = '2026-10-07T12:00:00.000Z';

export function loadDom(fixture: string, url: string): JSDOM {
  const html = readFileSync(path.join(ROOT, 'fixtures', fixture), 'utf8');
  return new JSDOM(html, { url });
}

export async function extractFixture(adapter: SiteAdapter, fixture: string, url: string, now = FIXED_NOW): Promise<{ raw: RawExtraction; normalized: NormalizedExtraction }> {
  const dom = loadDom(fixture, url);
  const raw = await runAdapter(adapter, { document: dom.window.document, url, title: dom.window.document.title, now });
  const normalized = normalizeExtraction(raw, { site: adapter.site });
  return { raw, normalized };
}

/** Compare against fixtures/<dir>/expected/<name>.json; UPDATE_FIXTURES=1 rewrites it. */
export function expectMatchesFixture(normalized: NormalizedExtraction, expectedPath: string) {
  const file = path.join(ROOT, 'fixtures', expectedPath);
  const actual = {
    pageId: normalized.pageId,
    entities: [...normalized.entities].sort((a, b) => a.id.localeCompare(b.id)),
    relationships: [...normalized.relationships].sort((a, b) => a.id.localeCompare(b.id)).map((r) => `${r.fromId} -${r.type}-> ${r.toId}`),
    media: [...normalized.media].sort((a, b) => a.id.localeCompare(b.id)),
    diagnostics: normalized.diagnostics,
  };
  if (process.env.UPDATE_FIXTURES || !existsSync(file)) {
    mkdirSync(path.dirname(file), { recursive: true });
    writeFileSync(file, JSON.stringify(actual, null, 2) + '\n');
  }
  expect(actual).toEqual(JSON.parse(readFileSync(file, 'utf8')));
}
