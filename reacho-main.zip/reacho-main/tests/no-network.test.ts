import { readdirSync, readFileSync, statSync } from 'node:fs';
import path from 'node:path';
import { describe, expect, it } from 'vitest';
import { ROOT } from './helpers';

function files(dir: string): string[] {
  return readdirSync(dir).flatMap((name) => {
    const full = path.join(dir, name);
    return statSync(full).isDirectory() ? files(full) : full.endsWith('.ts') ? [full] : [];
  });
}

// Static guard for acceptance criterion 12: extracted page data must never be
// sent to a remote service. Reacho's source must not contain network APIs.
// (The only network activity Reacho causes is a user-clicked download, which
// goes through chrome.downloads and sends no page data.)
const NETWORK_APIS = /\b(fetch|XMLHttpRequest|WebSocket|EventSource|sendBeacon|importScripts|RTCPeerConnection)\s*\(|new\s+(XMLHttpRequest|WebSocket|EventSource|Worker)\b|chrome\.runtime\.connectNative|sendNativeMessage/;

describe('no remote data paths', () => {
  it('source code uses no network APIs', () => {
    const offenders = files(path.join(ROOT, 'src')).filter((f) => NETWORK_APIS.test(readFileSync(f, 'utf8')));
    expect(offenders).toEqual([]);
  });
});
