// End-to-end acceptance run in real Chromium (Playwright drives the browser).
//
//   npm run build && npm run e2e            demo site only (offline)
//   npm run e2e -- --live                   also exercise live commons.wikimedia.org
//
// Env: CHROME_PATH=/path/to/chrome (defaults to Playwright's bundled Chromium
//      under PLAYWRIGHT_BROWSERS_PATH), HEADED=1 to watch.
//
// Automation cannot click the browser toolbar, which is how a user grants
// activeTab. This script therefore loads a TEST-ONLY copy of dist/ whose
// manifest pre-grants the adapters' optional host patterns. The shipped
// manifest is unchanged; the activeTab flow is covered by docs/testing.md.
//
// Screenshots and a JSON report are written to artifacts/e2e/.

import { chromium } from 'playwright-core';
import { cp, mkdir, mkdtemp, readFile, readdir, rm, writeFile } from 'node:fs/promises';
import { existsSync } from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { startDemoServer } from './serve-demo.mjs';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const live = process.argv.includes('--live');
const out = path.join(root, 'artifacts/e2e');
const extDir = path.join(root, 'artifacts/e2e-extension');
const DEMO = 'http://localhost:8787';
const report = { startedAt: new Date().toISOString(), live, checks: [], extensionNetworkRequests: [] };

/** Poll an async in-page function until it returns a non-null value. */
async function poll(page, fn, arg, timeout = 15000) {
  const deadline = Date.now() + timeout;
  while (Date.now() < deadline) {
    const value = await page.evaluate(fn, arg);
    if (value) return value;
    await new Promise((r) => setTimeout(r, 250));
  }
  throw new Error(`Timed out polling: ${fn.toString().slice(0, 80)}`);
}

function check(name, ok, detail = '') {
  report.checks.push({ name, ok: Boolean(ok), detail });
  console.log(`${ok ? 'PASS' : 'FAIL'}  ${name}${detail ? ` — ${detail}` : ''}`);
}

async function findChrome() {
  if (process.env.CHROME_PATH) return process.env.CHROME_PATH;
  const base = process.env.PLAYWRIGHT_BROWSERS_PATH ?? path.join(os.homedir(), '.cache/ms-playwright');
  const dirs = existsSync(base) ? (await readdir(base)).filter((d) => /^chromium-\d+$/.test(d)).sort() : [];
  for (const d of dirs.reverse()) {
    const candidate = path.join(base, d, 'chrome-linux/chrome');
    if (existsSync(candidate)) return candidate;
  }
  throw new Error('No Chromium found. Set CHROME_PATH.');
}

async function prepareExtension() {
  if (!existsSync(path.join(root, 'dist/manifest.json'))) throw new Error('Run `npm run build` first.');
  await rm(extDir, { recursive: true, force: true });
  await cp(path.join(root, 'dist'), extDir, { recursive: true });
  const manifest = JSON.parse(await readFile(path.join(extDir, 'manifest.json'), 'utf8'));
  manifest.host_permissions = manifest.optional_host_permissions; // TEST ONLY — see header.
  manifest.name = 'Reacho (e2e test build)';
  await writeFile(path.join(extDir, 'manifest.json'), JSON.stringify(manifest, null, 2));
}

await mkdir(out, { recursive: true });
await prepareExtension();
const server = await startDemoServer(8787);
const userDataDir = await mkdtemp(path.join(os.tmpdir(), 'reacho-e2e-'));
const downloadsDir = path.join(userDataDir, 'Downloads');
await mkdir(downloadsDir, { recursive: true });

const context = await chromium.launchPersistentContext(userDataDir, {
  executablePath: await findChrome(),
  headless: !process.env.HEADED,
  acceptDownloads: true,
  downloadsPath: downloadsDir,
  viewport: { width: 1100, height: 800 },
  args: [
    `--disable-extensions-except=${extDir}`,
    `--load-extension=${extDir}`,
    // Wikimedia answers the default "HeadlessChrome" user agent with HTTP 429; a
    // desktop browser is not affected. Applies to chrome.downloads requests too.
    ...(process.env.HEADED ? [] : ['--user-agent=Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36']),
  ],
});

let failed = false;
try {
  let [worker] = context.serviceWorkers();
  if (!worker) worker = await context.waitForEvent('serviceworker');
  const extensionId = new URL(worker.url()).host;
  check('unpacked extension loads (service worker running)', Boolean(extensionId), extensionId);

  const site = await context.newPage();
  await site.goto(`${DEMO}/`);

  // A helper extension page to query tab ids (the panel binds to one tab via ?tabId=).
  const helper = await context.newPage();
  await helper.goto(`chrome-extension://${extensionId}/sidepanel.html`);
  const tabId = await helper.evaluate(async (url) => (await chrome.tabs.query({ url: url + '*' }))[0]?.id, `${DEMO}/`);
  await helper.close();

  const panel = await context.newPage();
  await panel.setViewportSize({ width: 420, height: 900 });
  panel.on('request', (req) => {
    const url = req.url();
    if (!url.startsWith('chrome-extension://') && !url.startsWith('blob:') && !url.startsWith('data:')) report.extensionNetworkRequests.push(url);
  });
  const errors = [];
  panel.on('pageerror', (err) => errors.push(String(err)));
  await panel.goto(`chrome-extension://${extensionId}/sidepanel.html?tabId=${tabId}`);

  const adapterText = () => panel.getByTestId('adapter').innerText();
  const extract = async () => {
    await panel.getByTestId('extract').click();
    await panel.getByTestId('notice').waitFor();
    await panel.waitForFunction(() => !document.querySelector('[data-testid="extract"]')?.textContent?.includes('…'));
    return panel.getByTestId('notice').innerText();
  };
  const shot = (name) => panel.screenshot({ path: path.join(out, `${name}.png`), fullPage: true });
  const tab = (name) => panel.getByTestId(`tab-${name}`).click();
  const waitForAdapter = async (re) => panel.waitForFunction((src) => new RegExp(src).test(document.querySelector('[data-testid="adapter"]')?.textContent ?? ''), re.source);

  // --- Demo site: creator page -------------------------------------------------
  await waitForAdapter(/reacho-demo/);
  check('supported page identifies the matching adapter', /reacho-demo@0\.1\.0/.test(await adapterText()), await adapterText());
  await shot('01-demo-matched');

  let notice = await extract();
  check('Extract from the side panel saves normalized entities', /Saved \d+ entities/.test(notice), notice);
  const records = await panel.getByTestId('records').innerText();
  check('extracted entities are displayed', records.includes('Ada Lumen') && records.includes('Harbor Lights'));
  await shot('02-demo-creator-extracted');

  // --- Navigate to a related album page ------------------------------------------
  await site.click('a[href="/albums/harbor.html"]');
  await site.waitForURL(`${DEMO}/albums/harbor.html`);
  await panel.waitForFunction(() => document.querySelector('.page-url')?.textContent?.includes('/albums/harbor.html'));
  notice = await extract();
  check('album extraction links to records from the earlier page', /already in the workspace/.test(notice) && !/ 0 records were already/.test(notice), notice);
  await tab('relationships');
  const links = await panel.getByTestId('relationships').innerText();
  check('relationships show Page -> Collection -> Asset and earlier-page links', links.includes('describes') && links.includes('contains') && links.includes('createdBy') && links.includes('recorded on an earlier page'));
  await shot('03-demo-album-links');

  await tab('records');
  const albumRecords = await panel.getByTestId('records').innerText();
  check('records captured on the earlier page are marked', albumRecords.includes('seen on 2 pages'));

  // --- Persistence across reload ------------------------------------------------
  await site.reload();
  await panel.reload();
  await waitForAdapter(/reacho-demo/);
  await panel.getByTestId('records').waitFor();
  check('data persists across page reload and panel restart', (await panel.getByTestId('records').innerText()).includes('Lighthouse at dusk'));

  // --- Inspector ------------------------------------------------------------------
  await tab('inspector');
  await panel.getByTestId('inspect-target').selectOption('graph');
  const json = JSON.parse(await panel.getByTestId('inspector-json').innerText());
  check('raw normalized JSON is inspectable', Array.isArray(json.entities) && json.entities.every((e) => e.provenance?.adapterId === 'reacho-demo'));
  await shot('04-inspector');

  // --- Media + download ----------------------------------------------------------------
  await tab('media');
  const mediaText = await panel.getByTestId('media').innerText();
  check('ordinary media discovered and classified', /direct/.test(mediaText) && /segmented/.test(mediaText) && /unsupported/.test(mediaText), mediaText.replace(/\s+/g, ' ').slice(0, 160));
  const saveButtons = panel.getByTestId('save-media');
  check('only direct resources offer Save', (await saveButtons.count()) === 3, `${await saveButtons.count()} Save buttons`);
  await saveButtons.first().click();
  await panel.waitForFunction(() => document.querySelector('[data-testid="media"]')?.textContent?.includes('download complete'), null, { timeout: 15000 });
  const downloaded = await panel.evaluate(async () => (await chrome.downloads.search({ state: 'complete' })).map((d) => ({ url: d.url, filename: d.filename })));
  check('direct resource saved through chrome.downloads', downloaded.some((d) => d.url.endsWith('/media/harbor-1.svg')), JSON.stringify(downloaded));
  await shot('05-media-saved');

  // --- Export -------------------------------------------------------------------------
  await panel.getByTestId('export-page').click();
  await panel.waitForFunction(() => document.querySelector('[data-testid="notice"]')?.textContent?.startsWith('Exported'));
  const exportInfo = await poll(panel, async () => {
    const [item] = await chrome.downloads.search({ mime: 'application/json', state: 'complete', orderBy: ['-startTime'] });
    return item ? { filename: item.filename, url: item.url } : null;
  });
  let exportJson;
  try {
    exportJson = JSON.parse(await readFile(exportInfo.filename, 'utf8'));
  } catch {
    exportJson = null;
  }
  check(
    'JSON export opens and contains provenance/source information',
    exportJson?.format === 'reacho-export' && exportJson.entities.length > 0 && exportJson.entities.every((e) => e.provenance?.sourcePageIds?.length && e.provenance.adapterVersion),
    exportInfo.filename,
  );
  if (exportJson) await writeFile(path.join(out, 'export-demo-album.json'), JSON.stringify(exportJson, null, 2));

  // --- Visible failure diagnostics ------------------------------------------------------
  await site.goto(`${DEMO}/albums/broken.html`);
  await panel.waitForFunction(() => document.querySelector('.page-url')?.textContent?.includes('broken.html'));
  notice = await extract();
  const diag = await panel.getByTestId('diagnostics').innerText();
  check('adapter failures are reported visibly', /error/.test(notice) && diag.includes('state-unparsed'), diag.replace(/\s+/g, ' ').slice(0, 160));
  await shot('06-diagnostics-error');

  // --- Unsupported page ------------------------------------------------------------------
  await site.goto('about:blank');
  await panel.waitForFunction(() => document.querySelector('[data-testid="extract"]')?.disabled === true);
  check('Extract is disabled where no adapter applies', true);

  // --- Live Wikimedia Commons --------------------------------------------------------------
  if (live) {
    await site.goto('https://commons.wikimedia.org/wiki/Category:Lighthouses_in_Maine');
    await waitForAdapter(/wikimedia-commons/);
    notice = await extract();
    check('[live] Commons category extracted', /Saved \d+ entities/.test(notice), notice);
    await tab('records');
    await shot('07-live-commons-category');

    await site.click('#mw-subcategories a[href="/wiki/Category:Avery_Rock_Light"]');
    await site.waitForURL(/Avery_Rock_Light/);
    await panel.waitForFunction(() => document.querySelector('.page-url')?.textContent?.includes('Avery_Rock_Light'));
    notice = await extract();
    await tab('relationships');
    const liveLinks = await panel.getByTestId('relationships').innerText();
    check('[live] subcategory links to the category captured earlier', /already in the workspace/.test(notice) && liveLinks.includes('Lighthouses in Maine') && liveLinks.includes('recorded on an earlier page'), notice);
    await shot('08-live-commons-subcategory-links');

    await site.goto('https://commons.wikimedia.org/wiki/File:Bass_Harbor_Head_Light_-_the_Bell.jpg');
    await panel.waitForFunction(() => document.querySelector('.page-url')?.textContent?.includes('Bass_Harbor'));
    notice = await extract();
    await tab('media');
    await panel.getByTestId('save-media').first().click();
    const ld = await poll(panel, async () => {
      const [item] = await chrome.downloads.search({ urlRegex: 'upload\\.wikimedia\\.org.*Bass_Harbor' });
      return item && item.state !== 'in_progress' ? { state: item.state, error: item.error ?? null, bytes: item.bytesReceived } : null;
    }, undefined, 60000);
    check('[live] original Commons file saved via chrome.downloads', ld.state === 'complete', JSON.stringify(ld));
    await shot('09-live-commons-file-saved');
  }

  check('side panel made no network requests', report.extensionNetworkRequests.length === 0, report.extensionNetworkRequests.join(', '));
  check('side panel threw no uncaught errors', errors.length === 0, errors.join('; '));
} catch (err) {
  failed = true;
  for (const page of context.pages()) {
    if (page.url().includes('sidepanel.html')) await page.screenshot({ path: path.join(out, 'failure.png'), fullPage: true }).catch(() => {});
  }
  check('e2e run completed', false, String(err?.stack ?? err));
} finally {
  report.finishedAt = new Date().toISOString();
  await writeFile(path.join(out, 'report.json'), JSON.stringify(report, null, 2));
  await context.close();
  server.close();
  await rm(userDataDir, { recursive: true, force: true });
}

const failures = report.checks.filter((c) => !c.ok);
console.log(`\n${report.checks.length - failures.length}/${report.checks.length} checks passed. Screenshots: artifacts/e2e/`);
process.exit(failed || failures.length ? 1 : 0);
