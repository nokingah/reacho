// Build the unpacked extension into dist/.
//   node scripts/build.mjs           production build
//   node scripts/build.mjs --watch   rebuild on change
//
// Bundles three entry points with esbuild (content bridge, service worker,
// side panel) and copies static files. The manifest's version is taken from
// package.json so there is a single source of truth.

import { build, context } from 'esbuild';
import { cp, mkdir, readFile, rm, writeFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const dist = path.join(root, 'dist');
const watch = process.argv.includes('--watch');
const pkg = JSON.parse(await readFile(path.join(root, 'package.json'), 'utf8'));

const common = {
  bundle: true,
  target: 'chrome116',
  logLevel: 'info',
  sourcemap: watch ? 'inline' : false,
  legalComments: 'none',
  define: { __REACHO_VERSION__: JSON.stringify(pkg.version) },
};

const entries = [
  // Classic script: chrome.scripting.executeScript({ files }) cannot load modules.
  { entryPoints: [path.join(root, 'src/content/bridge.ts')], outfile: path.join(dist, 'content.js'), format: 'iife' },
  { entryPoints: [path.join(root, 'src/background/service-worker.ts')], outfile: path.join(dist, 'background.js'), format: 'esm' },
  { entryPoints: [path.join(root, 'src/panel/main.ts')], outfile: path.join(dist, 'sidepanel.js'), format: 'esm' },
];

async function copyStatic() {
  await cp(path.join(root, 'static'), dist, { recursive: true });
  const manifest = JSON.parse(await readFile(path.join(root, 'static/manifest.json'), 'utf8'));
  manifest.version = pkg.version;
  await writeFile(path.join(dist, 'manifest.json'), JSON.stringify(manifest, null, 2) + '\n');
}

await rm(dist, { recursive: true, force: true });
await mkdir(dist, { recursive: true });
await copyStatic();

if (watch) {
  for (const entry of entries) {
    const ctx = await context({ ...common, ...entry });
    await ctx.watch();
  }
  console.log('Watching for changes. Reload the extension in chrome://extensions after edits (static files are copied once).');
} else {
  await Promise.all(entries.map((entry) => build({ ...common, ...entry })));
  console.log(`Built Reacho ${pkg.version} into dist/. Load it via chrome://extensions → Load unpacked.`);
}
