// Demo/fixture adapter for the local Reacho demo site (fixtures/demo-site,
// served by `npm run demo` on http://localhost:8787). It exists so the full
// workflow — including segmented and page-scoped media that Reacho must refuse
// to download, and a deliberately broken page — can be exercised offline and
// deterministically. It is isolated like any other adapter.
//
//   Creator page  -describes->  Person
//   Page          -contains->   Collection (album)    Collection -createdBy-> Person
//   Album page    -describes->  Collection            Collection -contains->  Asset

import type { EntityDraft, MediaCandidate, PageContext, RelationshipDraft, SiteAdapter } from '../../shared/types';
import { PAGE_REF } from '../../shared/types';
import { absoluteUrl, discoverOrdinaryMedia, guessKind, parseCount, text } from '../lib/dom';

export const DEMO_PORT = '8787';

interface AlbumState {
  album: {
    id: string;
    title: string;
    creator: { id: string; name: string };
    items: { id: string; title: string; src: string; type?: string; width?: number; height?: number; duration?: number }[];
  };
}

export const demoAdapter: SiteAdapter = {
  id: 'reacho-demo',
  version: '0.1.0',
  name: 'Reacho demo site (fixture)',
  description: 'Deterministic local fixture site served by `npm run demo`.',
  site: 'reacho-demo.test',
  hostPermissions: ['http://localhost/*', 'http://127.0.0.1/*'],
  demo: true,

  matches(url) {
    return url.protocol === 'http:' && (url.hostname === 'localhost' || url.hostname === '127.0.0.1') && url.port === DEMO_PORT;
  },

  async discover(ctx) {
    const kind = pageKind(ctx.document);
    return [
      { kind: 'page-kind', label: kind ? `Demo ${kind} page` : 'Unrecognized demo page' },
      { kind: 'albums', label: 'Albums listed', count: ctx.document.querySelectorAll('[data-album-id]').length },
      { kind: 'embedded-state', label: 'Embedded album state', count: ctx.document.getElementById('demo-state') ? 1 : 0 },
    ];
  },

  async extract(ctx) {
    const kind = pageKind(ctx.document);
    if (kind === 'creator') return extractCreator(ctx);
    if (kind === 'album') return extractAlbum(ctx);
    ctx.report('warning', 'unknown-page', 'This demo page has no data-demo-page marker.');
    return [];
  },

  async relate(entities) {
    const rels: RelationshipDraft[] = [];
    const person = entities.find((e) => e.type === 'person');
    for (const e of entities) {
      if (e.ref === 'self') rels.push({ from: PAGE_REF, type: 'describes', to: e.ref });
      if (e.type === 'collection') {
        if (e.ref !== 'self') rels.push({ from: PAGE_REF, type: 'contains', to: e.ref });
        if (person) rels.push({ from: e.ref, type: 'createdBy', to: person.ref });
      }
      if (e.type === 'asset') rels.push({ from: 'self', type: 'contains', to: e.ref });
    }
    return rels;
  },

  async media(ctx) {
    if (pageKind(ctx.document) !== 'album') return [];
    const state = readState(ctx);
    const byUrl = new Map<string, string>();
    for (const item of state?.album.items ?? []) {
      const url = absoluteUrl(item.src, ctx.url);
      if (url) byUrl.set(url, `item:${item.id}`);
    }
    const root = ctx.document.querySelector('main') ?? ctx.document;
    return discoverOrdinaryMedia(root, ctx.url).map((m): MediaCandidate => ({ ...m, assetRef: byUrl.get(m.url) }));
  },
};

function pageKind(doc: Document): 'creator' | 'album' | undefined {
  const kind = doc.querySelector('[data-demo-page]')?.getAttribute('data-demo-page');
  return kind === 'creator' || kind === 'album' ? kind : undefined;
}

function extractCreator(ctx: PageContext): EntityDraft[] {
  const main = ctx.document.querySelector('[data-demo-page="creator"]')!;
  const creatorId = main.getAttribute('data-creator-id');
  if (!creatorId) ctx.report('warning', 'creator-id-missing', 'Creator page has no data-creator-id.');
  const entities: EntityDraft[] = [
    { ref: PAGE_REF, type: 'page', kind: 'creator-page' },
    { ref: 'self', type: 'person', kind: 'creator', sourceId: creatorId ?? undefined, title: text(main.querySelector('h1')) },
  ];
  for (const li of ctx.document.querySelectorAll('[data-album-id]')) {
    const id = li.getAttribute('data-album-id')!;
    entities.push({
      ref: `album:${id}`,
      type: 'collection',
      kind: 'album',
      sourceId: id,
      sourceUrl: absoluteUrl(li.querySelector('a')?.getAttribute('href'), ctx.url),
      title: text(li.querySelector('a')),
      metadata: { listedItemCount: parseCount(text(li.querySelector('[data-count]'))) ?? null },
    });
  }
  return entities;
}

function extractAlbum(ctx: PageContext): EntityDraft[] {
  const state = readState(ctx);
  if (!state) return [];
  const { album } = state;
  const entities: EntityDraft[] = [
    { ref: PAGE_REF, type: 'page', kind: 'album-page' },
    { ref: 'self', type: 'collection', kind: 'album', sourceId: album.id, sourceUrl: ctx.url.href, title: album.title, metadata: { itemCount: album.items.length } },
    { ref: 'creator', type: 'person', kind: 'creator', sourceId: album.creator.id, title: album.creator.name },
  ];
  for (const item of album.items) {
    const src = absoluteUrl(item.src, ctx.url);
    entities.push({
      ref: `item:${item.id}`,
      type: 'asset',
      kind: guessKind(item.src, item.type),
      sourceId: item.id,
      title: item.title,
      mimeType: item.type,
      width: item.width,
      height: item.height,
      duration: item.duration,
      metadata: { src: src ?? item.src },
    });
  }
  return entities;
}

const stateCache = new WeakMap<Document, AlbumState | null>();

function readState(ctx: PageContext): AlbumState | null {
  if (stateCache.has(ctx.document)) return stateCache.get(ctx.document)!;
  let state: AlbumState | null = null;
  const el = ctx.document.getElementById('demo-state');
  if (!el) {
    ctx.report('error', 'state-missing', 'Album page has no #demo-state script.');
  } else {
    try {
      state = JSON.parse(el.textContent ?? '') as AlbumState;
      if (!state?.album?.id || !Array.isArray(state.album.items)) {
        ctx.report('error', 'state-invalid', 'Embedded album state is missing album.id or album.items.');
        state = null;
      }
    } catch (err) {
      ctx.report('error', 'state-unparsed', `Embedded album state is not valid JSON (${(err as Error).message}).`);
    }
  }
  stateCache.set(ctx.document, state);
  return state;
}
