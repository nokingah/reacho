import type { SiteAdapter } from '../shared/types';
import { commonsAdapter } from './commons';
import { demoAdapter } from './demo';

/**
 * Built-in adapters. Repository-controlled code only: Reacho never loads or
 * executes adapter code from elsewhere (see docs/privacy-security.md).
 */
export const ADAPTERS: readonly SiteAdapter[] = [commonsAdapter, demoAdapter];

export function findAdapterForUrl(url: string | undefined): SiteAdapter | undefined {
  if (!url) return undefined;
  let parsed: URL;
  try {
    parsed = new URL(url);
  } catch {
    return undefined;
  }
  return ADAPTERS.find((adapter) => {
    try {
      return adapter.matches(parsed);
    } catch {
      return false;
    }
  });
}

export function getAdapter(id: string): SiteAdapter | undefined {
  return ADAPTERS.find((adapter) => adapter.id === id);
}
