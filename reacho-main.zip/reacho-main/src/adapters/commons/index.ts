// Wikimedia Commons adapter.
//
// Commons is a public, freely licensed media repository whose pages map
// naturally onto Reacho's Page -> Collection -> Asset model:
//
//   Category page  -describes->  Collection (category)
//   Collection     -contains->   Collection (subcategory)
//   Collection     -contains->   Asset      (file)
//   File page      -describes->  Asset      (file, with original-file URL)
//
// Parent categories listed at the bottom of every page link a newly visited
// category or file back to categories captured earlier.
//
// Identity: page titles ("Category:Lighthouses_in_Maine",
// "File:Foo.jpg") are the site-native IDs because they are the only stable key
// visible both in listings and on the item's own page. Numeric page IDs are
// kept in metadata when available.
//
// Data sources: the DOM, plus MediaWiki's embedded page config (RLCONF) read
// from the inline script text. No network requests are made.

import type {
  Discovery,
  EntityDraft,
  JsonObject,
  MediaCandidate,
  PageContext,
  RelationshipDraft,
  SiteAdapter,
} from '../../shared/types';
import { PAGE_REF } from '../../shared/types';
import { absoluteUrl, guessKind, guessMime, intAttr, parseCount, text } from '../lib/dom';

const HOST = 'commons.wikimedia.org';
const SELF = 'self';

type PageKind = 'category' | 'file';

interface WikiConfig {
  wgCanonicalNamespace?: string;
  wgNamespaceNumber?: number;
  wgPageName?: string;
  wgTitle?: string;
  wgArticleId?: number;
  wgRevisionId?: number;
  wgIsRedirect?: boolean;
  wgCategories?: string[];
  wgWikibaseItemId?: string;
  wgCoordinates?: { lat: number; lon: number };
}

export const commonsAdapter: SiteAdapter = {
  id: 'wikimedia-commons',
  version: '0.1.0',
  name: 'Wikimedia Commons',
  description: 'Category and file pages on commons.wikimedia.org.',
  site: HOST,
  hostPermissions: [`https://${HOST}/*`],

  matches(url) {
    return url.protocol === 'https:' && url.hostname === HOST && pageKindFromUrl(url) !== null;
  },

  async discover(ctx) {
    const kind = pageKind(ctx);
    const out: Discovery[] = [{ kind: 'page-kind', label: kind === 'file' ? 'Commons file page' : 'Commons category page' }];
    if (kind === 'category') {
      out.push({ kind: 'subcategories', label: 'Subcategories listed', count: subcategoryLinks(ctx.document).length });
      out.push({ kind: 'files', label: 'Files listed', count: galleryItems(ctx.document).length });
    } else {
      out.push({ kind: 'original', label: 'Original file link', count: originalFileLink(ctx.document) ? 1 : 0 });
    }
    out.push({ kind: 'parent-categories', label: 'Parent categories', count: parentCategoryLinks(ctx.document).length });
    return out;
  },

  async extract(ctx) {
    const config = readConfig(ctx);
    const kind = pageKind(ctx);
    const pageName = titleKey(config.wgPageName ?? titleFromUrl(ctx.url) ?? '');
    if (!pageName) {
      ctx.report('error', 'title-missing', 'Could not determine the page title from RLCONF or the URL.');
      return [];
    }
    const canonical = ctx.document.querySelector('link[rel="canonical"]')?.getAttribute('href') ?? undefined;
    const sourceUrl = absoluteUrl(canonical, ctx.url) ?? ctx.url.href;

    const entities: EntityDraft[] = [
      {
        ref: PAGE_REF,
        type: 'page',
        kind: kind === 'file' ? 'file-page' : 'category-page',
        sourceId: config.wgArticleId ? String(config.wgArticleId) : undefined,
        metadata: compact({ namespace: config.wgCanonicalNamespace, revisionId: config.wgRevisionId }),
      },
    ];

    if (kind === 'category') {
      entities.push({
        ref: SELF,
        type: 'collection',
        kind: 'category',
        sourceId: pageName,
        sourceUrl,
        title: config.wgTitle ?? displayTitle(pageName),
        metadata: compact({
          pageId: config.wgArticleId,
          revisionId: config.wgRevisionId,
          wikidataItem: config.wgWikibaseItemId,
          coordinates: config.wgCoordinates ? { lat: config.wgCoordinates.lat, lon: config.wgCoordinates.lon } : undefined,
          totalSubcategories: totalFromHeading(ctx.document, '#mw-subcategories'),
          totalFiles: totalFromHeading(ctx.document, '#mw-category-media'),
        }),
      });
      for (const link of subcategoryLinks(ctx.document)) entities.push(categoryStub(link, ctx, true));
      for (const item of galleryItems(ctx.document)) {
        const asset = galleryAsset(item, ctx);
        if (asset) entities.push(asset);
      }
    } else {
      const fileInfo = text(ctx.document.querySelector('.fullMedia .fileInfo'));
      const dims = fileInfo?.match(/([\d,.\s]+)\s*×\s*([\d,.\s]+)\s*pixels/);
      const img = ctx.document.querySelector('#file img');
      const mimeType = text(ctx.document.querySelector('.fullMedia .mime-type')) ?? guessMime(pageName);
      const original = originalFileLink(ctx.document);
      if (!original) ctx.report('warning', 'original-missing', 'No original-file link found on this file page.');
      entities.push({
        ref: SELF,
        type: 'asset',
        kind: guessKind(pageName, mimeType),
        sourceId: pageName,
        sourceUrl,
        title: config.wgTitle ?? displayTitle(pageName),
        mimeType,
        width: parseCount(dims?.[1]) ?? intAttr(img, 'data-file-width'),
        height: parseCount(dims?.[2]) ?? intAttr(img, 'data-file-height'),
        metadata: compact({
          pageId: config.wgArticleId,
          revisionId: config.wgRevisionId,
          originalUrl: original ? stripTracking(original, ctx.url) : undefined,
          fileSize: fileInfo?.match(/file size:\s*([^,)]+)/)?.[1]?.trim(),
          license: absoluteUrl(ctx.document.querySelector('link[rel="license"]')?.getAttribute('href'), ctx.url),
        }),
      });
    }

    for (const link of parentCategoryLinks(ctx.document)) entities.push(categoryStub(link, ctx, false));
    return entities;
  },

  async relate(entities, ctx) {
    const rels: RelationshipDraft[] = [];
    const self = entities.find((e) => e.ref === SELF);
    if (!self) return rels;
    rels.push({ from: PAGE_REF, type: 'describes', to: SELF });
    for (const e of entities) {
      if (e.ref.startsWith('child:') || e.ref.startsWith('file:')) rels.push({ from: SELF, type: 'contains', to: e.ref });
      else if (e.ref.startsWith('parent:')) rels.push({ from: e.ref, type: 'contains', to: SELF });
    }
    if (pageKind(ctx) === 'file' && !entities.some((e) => e.ref.startsWith('parent:'))) {
      ctx.report('info', 'no-categories', 'This file is not in any visible category, so it cannot be linked to a collection.');
    }
    return rels;
  },

  async media(ctx) {
    const out: MediaCandidate[] = [];
    if (pageKind(ctx) === 'file') {
      const config = readConfig(ctx);
      const pageName = titleKey(config.wgPageName ?? titleFromUrl(ctx.url) ?? '');
      const original = originalFileLink(ctx.document);
      if (original) {
        const mimeType = text(ctx.document.querySelector('.fullMedia .mime-type')) ?? guessMime(pageName);
        out.push({
          url: stripTracking(original, ctx.url),
          kind: guessKind(pageName, mimeType),
          mimeType,
          assetRef: SELF,
          filename: fileNameOf(pageName),
          label: 'Original file',
          delivery: 'direct',
        });
      }
      return out;
    }
    for (const item of galleryItems(ctx.document)) {
      const link = item.querySelector('a.mw-file-description');
      const name = link ? titleFromHref(link.getAttribute('href'), ctx.url) : undefined;
      const thumb = item.querySelector('img')?.getAttribute('src');
      const originalUrl = thumb ? originalFromThumb(thumb, ctx.url) : undefined;
      if (!name || !originalUrl) continue;
      const mimeType = guessMime(name);
      out.push({
        url: originalUrl,
        kind: guessKind(name, mimeType),
        mimeType,
        assetRef: `file:${name}`,
        filename: fileNameOf(name),
        label: displayTitle(name),
        width: intAttr(item.querySelector('img'), 'data-file-width'),
        height: intAttr(item.querySelector('img'), 'data-file-height'),
        delivery: 'direct',
      });
    }
    return out;
  },
};

// ---------------------------------------------------------------------------
// Commons-specific parsing
// ---------------------------------------------------------------------------

function pageKindFromUrl(url: URL): PageKind | null {
  const title = titleFromUrl(url);
  if (!title) return null;
  if (title.startsWith('Category:')) return 'category';
  if (title.startsWith('File:')) return 'file';
  return null;
}

function pageKind(ctx: PageContext): PageKind {
  const ns = readConfig(ctx).wgNamespaceNumber;
  if (ns === 6) return 'file';
  if (ns === 14) return 'category';
  return pageKindFromUrl(ctx.url) ?? 'category';
}

const configCache = new WeakMap<Document, WikiConfig>();

/** Read MediaWiki's embedded page config from the inline `RLCONF=` script. */
function readConfig(ctx: PageContext): WikiConfig {
  const cached = configCache.get(ctx.document);
  if (cached) return cached;
  let config: WikiConfig = {};
  const script = [...ctx.document.querySelectorAll('script:not([src])')].find((s) => s.textContent?.includes('RLCONF='));
  const match = script?.textContent?.match(/RLCONF=(\{[\s\S]*?\});\s*RLSTATE=/);
  if (match?.[1]) {
    try {
      config = JSON.parse(match[1]) as WikiConfig;
    } catch {
      ctx.report('warning', 'rlconf-unparsed', 'Embedded page config (RLCONF) could not be parsed; falling back to DOM/URL.');
    }
  } else {
    ctx.report('warning', 'rlconf-missing', 'Embedded page config (RLCONF) not found; falling back to DOM/URL.');
  }
  configCache.set(ctx.document, config);
  return config;
}

function titleFromUrl(url: URL): string | undefined {
  if (url.pathname.startsWith('/wiki/')) return titleKey(safeDecode(url.pathname.slice('/wiki/'.length)));
  if (url.pathname === '/w/index.php') {
    const title = url.searchParams.get('title');
    return title ? titleKey(title) : undefined;
  }
  return undefined;
}

function titleFromHref(href: string | null, base: URL): string | undefined {
  const abs = absoluteUrl(href, base);
  if (!abs) return undefined;
  const url = new URL(abs);
  return url.hostname === HOST ? titleFromUrl(url) : undefined;
}

/** MediaWiki title key: spaces become underscores. */
function titleKey(title: string): string {
  return title.trim().replace(/ /g, '_');
}

function displayTitle(key: string): string {
  return key.replace(/^(Category|File):/, '').replace(/_/g, ' ');
}

function fileNameOf(key: string): string {
  return key.replace(/^File:/, '');
}

function safeDecode(value: string): string {
  try {
    return decodeURIComponent(value);
  } catch {
    return value;
  }
}

function subcategoryLinks(doc: Document): Element[] {
  return [...doc.querySelectorAll('#mw-subcategories .CategoryTreeItem a[href*="/wiki/Category:"]')];
}

function parentCategoryLinks(doc: Document): Element[] {
  // Only visible, topical categories; hidden maintenance categories are skipped.
  return [...doc.querySelectorAll('#mw-normal-catlinks ul a[href*="/wiki/Category:"]')];
}

function galleryItems(doc: Document): Element[] {
  return [...doc.querySelectorAll('#mw-category-media li.gallerybox')];
}

function originalFileLink(doc: Document): string | undefined {
  return doc.querySelector('.fullMedia a[href]')?.getAttribute('href') ?? doc.querySelector('#file > a[href]')?.getAttribute('href') ?? undefined;
}

function categoryStub(link: Element, ctx: PageContext, child: boolean): EntityDraft {
  const name = titleFromHref(link.getAttribute('href'), ctx.url) ?? titleKey(`Category:${text(link) ?? ''}`);
  const counts = link.closest('.CategoryTreeItem')?.querySelector('span[title]')?.getAttribute('title');
  const m = counts?.match(/([\d,]+) subcategor\w*, ([\d,]+) pages?, and ([\d,]+) files?/);
  return {
    ref: `${child ? 'child' : 'parent'}:${name}`,
    type: 'collection',
    kind: 'category',
    sourceId: name,
    sourceUrl: absoluteUrl(link.getAttribute('href'), ctx.url),
    title: displayTitle(name),
    metadata: m ? { subcategories: parseCount(m[1])!, pages: parseCount(m[2])!, files: parseCount(m[3])! } : undefined,
  };
}

function galleryAsset(item: Element, ctx: PageContext): EntityDraft | undefined {
  const link = item.querySelector('a.mw-file-description');
  const name = link ? titleFromHref(link.getAttribute('href'), ctx.url) : undefined;
  if (!name) {
    ctx.report('warning', 'gallery-item-unparsed', 'A gallery item had no file link; skipped.');
    return undefined;
  }
  const img = item.querySelector('img');
  const thumb = img?.getAttribute('src') ?? undefined;
  const caption = text(item.querySelector('.gallerytext'));
  const mimeType = guessMime(name);
  return {
    ref: `file:${name}`,
    type: 'asset',
    kind: guessKind(name, mimeType),
    sourceId: name,
    sourceUrl: absoluteUrl(link!.getAttribute('href'), ctx.url),
    title: displayTitle(name),
    mimeType,
    width: intAttr(img, 'data-file-width'),
    height: intAttr(img, 'data-file-height'),
    metadata: compact({
      originalUrl: thumb ? originalFromThumb(thumb, ctx.url) : undefined,
      thumbnailUrl: thumb ? stripTracking(thumb, ctx.url) : undefined,
      fileSize: caption?.match(/;\s*([\d.,]+\s*[KMG]?B)\b/)?.[1],
    }),
  };
}

function totalFromHeading(doc: Document, section: string): number | undefined {
  const p = text(doc.querySelector(`${section} > p`));
  return parseCount(p?.match(/out of ([\d,]+) total/)?.[1]);
}

/**
 * Commons thumbnails live at /wikipedia/commons/thumb/<h>/<hh>/<Name>/<size>-<name>;
 * the original is /wikipedia/commons/<h>/<hh>/<Name> on upload.wikimedia.org.
 */
export function originalFromThumb(src: string, base: URL): string | undefined {
  const abs = absoluteUrl(src, base);
  if (!abs) return undefined;
  const url = new URL(abs);
  const m = url.pathname.match(/^\/wikipedia\/commons\/thumb\/([0-9a-f])\/([0-9a-f]{2})\/([^/]+)\/[^/]+$/);
  if (!m) return undefined;
  return `https://upload.wikimedia.org/wikipedia/commons/${m[1]}/${m[2]}/${m[3]}`;
}

function stripTracking(href: string, base: URL): string {
  const url = new URL(href, base);
  for (const key of [...url.searchParams.keys()]) if (key.startsWith('utm_')) url.searchParams.delete(key);
  return url.href;
}

function compact(obj: Record<string, unknown>): JsonObject {
  const out: JsonObject = {};
  for (const [k, v] of Object.entries(obj)) if (v !== undefined && v !== null) out[k] = v as JsonObject[string];
  return out;
}
