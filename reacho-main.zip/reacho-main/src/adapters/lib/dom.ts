// Small helpers shared by built-in adapters. Site-specific selectors stay in
// each adapter; nothing here knows about storage or the UI.

import { extensionOf, kindForExtension } from '../../core/media';
import type { MediaCandidate, MediaKind } from '../../shared/types';

export function text(el: Element | null | undefined): string | undefined {
  const value = el?.textContent?.replace(/\s+/g, ' ').trim();
  return value || undefined;
}

export function absoluteUrl(href: string | null | undefined, base: URL): string | undefined {
  if (!href) return undefined;
  try {
    return new URL(href, base).href;
  } catch {
    return undefined;
  }
}

/** Parse "1,234" / "1 234" style integers. */
export function parseCount(value: string | undefined): number | undefined {
  if (!value) return undefined;
  const n = Number(value.replace(/[,\s  ]/g, ''));
  return Number.isFinite(n) ? n : undefined;
}

export function intAttr(el: Element | null | undefined, name: string): number | undefined {
  const raw = el?.getAttribute(name);
  if (raw == null || raw === '') return undefined;
  const n = Number(raw);
  return Number.isFinite(n) ? n : undefined;
}

const MIME_BY_EXTENSION: Record<string, string> = {
  jpg: 'image/jpeg', jpeg: 'image/jpeg', png: 'image/png', gif: 'image/gif', webp: 'image/webp', svg: 'image/svg+xml',
  tif: 'image/tiff', tiff: 'image/tiff', webm: 'video/webm', ogv: 'video/ogg', mp4: 'video/mp4', mpg: 'video/mpeg', mpeg: 'video/mpeg',
  ogg: 'audio/ogg', oga: 'audio/ogg', opus: 'audio/opus', mp3: 'audio/mpeg', wav: 'audio/wav', flac: 'audio/flac', mid: 'audio/midi',
  pdf: 'application/pdf', djvu: 'image/vnd.djvu', stl: 'model/stl',
};

export function guessMime(filename: string): string | undefined {
  return MIME_BY_EXTENSION[extensionOf(filename)];
}

export function guessKind(filename: string, mimeType?: string): MediaKind {
  const fromExt = kindForExtension(extensionOf(filename));
  if (fromExt) return fromExt;
  if (mimeType && /mpegurl|dash\+xml/i.test(mimeType)) return 'video';
  if (mimeType?.startsWith('image/')) return 'image';
  if (mimeType?.startsWith('video/')) return 'video';
  if (mimeType?.startsWith('audio/')) return 'audio';
  if (mimeType === 'application/pdf') return 'document';
  return 'other';
}

/**
 * Generic discovery of ordinary media elements in a subtree: img, video,
 * audio, source, and links to files. Adapters decide which root to scan and
 * may attach asset refs to the results.
 */
export function discoverOrdinaryMedia(root: ParentNode, base: URL): MediaCandidate[] {
  const out: MediaCandidate[] = [];
  const seen = new Set<string>();
  const push = (raw: string | null | undefined, kind: MediaKind, extra: Partial<MediaCandidate> = {}) => {
    if (!raw) return;
    const url = raw.startsWith('blob:') || raw.startsWith('data:') ? raw : absoluteUrl(raw, base);
    if (!url || seen.has(url)) return;
    seen.add(url);
    out.push({ url, kind, ...extra });
  };

  for (const img of root.querySelectorAll('img')) {
    push(img.getAttribute('src'), 'image', { width: intAttr(img, 'width'), height: intAttr(img, 'height'), label: img.getAttribute('alt') || undefined });
  }
  for (const media of root.querySelectorAll('video, audio')) {
    const kind: MediaKind = media.tagName.toLowerCase() === 'video' ? 'video' : 'audio';
    // `src` may have been assigned from script (e.g. a blob: MediaSource URL).
    push((media as HTMLMediaElement).src || media.getAttribute('src'), kind);
    for (const source of media.querySelectorAll('source')) {
      push(source.getAttribute('src'), kind, { mimeType: source.getAttribute('type') ?? undefined });
    }
  }
  for (const a of root.querySelectorAll('a[href]')) {
    const href = a.getAttribute('href')!;
    const kind = kindForExtension(extensionOf(href.split(/[?#]/)[0] ?? ''));
    if (kind && a.hasAttribute('download')) push(href, kind, { label: text(a) });
    else if (kind === 'document' || kind === 'archive') push(href, kind, { label: text(a) });
  }
  return out;
}
