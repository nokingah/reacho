import type { WorkspaceGraph } from '../shared/types';
import { SCHEMA_VERSION } from './workspace';

export type ExportScope =
  | { kind: 'page'; pageId: string; url?: string }
  | { kind: 'site'; site: string }
  | { kind: 'workspace' };

export interface ReachoExport extends WorkspaceGraph {
  format: 'reacho-export';
  formatVersion: 1;
  schemaVersion: number;
  exportedAt: string;
  generator: { name: 'Reacho'; version: string };
  scope: ExportScope;
  counts: { entities: number; relationships: number; media: number; localState: number };
  notes: string[];
}

/**
 * Build an explicit, user-requested JSON export. Records keep their full
 * provenance (adapter, version, timestamps, source pages) and source URLs.
 * Nothing here contacts the network; the panel hands the result to the
 * browser's download manager.
 */
export function buildExport(graph: WorkspaceGraph, scope: ExportScope, exportedAt: string, generatorVersion: string): ReachoExport {
  const byId = <T extends { id: string }>(a: T, b: T) => (a.id < b.id ? -1 : a.id > b.id ? 1 : 0);
  return {
    format: 'reacho-export',
    formatVersion: 1,
    schemaVersion: SCHEMA_VERSION,
    exportedAt,
    generator: { name: 'Reacho', version: generatorVersion },
    scope,
    counts: {
      entities: graph.entities.length,
      relationships: graph.relationships.length,
      media: graph.media.length,
      localState: graph.localState.length,
    },
    notes: [
      'Every entity, relationship, and media record carries provenance: adapter id/version, first/last observation time, and source page ids.',
      'localState holds local-only workspace state (e.g. downloads) and is separate from source metadata.',
    ],
    entities: [...graph.entities].sort(byId),
    relationships: [...graph.relationships].sort(byId),
    media: [...graph.media].sort(byId),
    localState: [...graph.localState].sort(byId),
  };
}

export function exportFilename(scope: ExportScope, exportedAt: string): string {
  const stamp = exportedAt.replace(/[:.]/g, '-');
  const label = scope.kind === 'site' ? `site-${scope.site}` : scope.kind;
  return `reacho-${label}-${stamp}.json`.replace(/[^A-Za-z0-9._-]/g, '_');
}
