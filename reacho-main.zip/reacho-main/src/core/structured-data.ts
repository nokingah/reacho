import { toJsonValue } from '../shared/json';
import type { JsonValue, StructuredData } from '../shared/types';

const MAX_JSON_LD_SCRIPTS = 20;
const MAX_JSON_LD_CHARS = 200_000;
const MAX_META = 100;

/**
 * Collect page-visible structured data (JSON-LD and OpenGraph/Twitter/basic
 * meta tags) for the raw inspector. Bounded in size; never includes cookies,
 * storage, or form values.
 */
export function collectStructuredData(document: Document): StructuredData {
  const jsonLd: JsonValue[] = [];
  let jsonLdErrors = 0;
  const scripts = [...document.querySelectorAll('script[type="application/ld+json"]')].slice(0, MAX_JSON_LD_SCRIPTS);
  for (const script of scripts) {
    const text = script.textContent ?? '';
    if (text.length > MAX_JSON_LD_CHARS) {
      jsonLdErrors++;
      continue;
    }
    try {
      const value = toJsonValue(JSON.parse(text));
      if (value !== undefined) jsonLd.push(value);
    } catch {
      jsonLdErrors++;
    }
  }

  const meta: Record<string, string> = {};
  let count = 0;
  for (const el of document.querySelectorAll('meta[property], meta[name]')) {
    const name = el.getAttribute('property') ?? el.getAttribute('name') ?? '';
    if (!/^(og:|twitter:|article:|description$|author$|keywords$)/i.test(name)) continue;
    const content = el.getAttribute('content');
    if (content == null || name in meta) continue;
    meta[name] = content.slice(0, 1000);
    if (++count >= MAX_META) break;
  }
  return { jsonLd, jsonLdErrors, meta };
}
