import { isPlainObject, toJsonValue } from '../shared/json';
import { hostnameOf, normalizeUrl } from '../shared/url';
import {
  ENTITY_TYPES,
  PAGE_REF,
  type Diagnostic,
  type EntityDraft,
  type EntityRecord,
  type JsonObject,
  type MediaRecord,
  type NormalizedExtraction,
  type Provenance,
  type RawExtraction,
  type RelationshipRecord,
} from '../shared/types';
import { mediaId, pageIdForUrl, relationshipId, resolveIdentity } from './identity';
import { classifyMedia, safeFilename } from './media';

export interface NormalizeOptions {
  /** Identity namespace (adapter `site`), defaults to the page hostname. */
  site?: string;
  newLocalId?: () => string;
}

const RELATIONSHIP_TYPE = /^[A-Za-z][A-Za-z0-9_-]{0,63}$/;
const MEDIA_KINDS = new Set(['image', 'video', 'audio', 'document', 'archive', 'other']);

/**
 * Validate adapter output and turn it into workspace records: resolve
 * identities, map draft refs to record ids, attach provenance, and classify
 * media. Invalid items are dropped and reported, never silently ignored.
 */
export function normalizeExtraction(raw: RawExtraction, options: NormalizeOptions = {}): NormalizedExtraction {
  const diagnostics: Diagnostic[] = [...raw.diagnostics];
  const issue = (level: Diagnostic['level'], code: string, message: string) =>
    diagnostics.push({ level, code, message, phase: 'normalize' });

  const site = options.site ?? hostnameOf(raw.page.url);
  const observedAt = raw.observedAt;
  const pageUrl = normalizeUrl(raw.page.url);
  if (!pageUrl) throw new Error(`Cannot normalize extraction for non-http(s) page ${raw.page.url}`);

  const canonical = acceptCanonical(raw.page.canonicalUrl, pageUrl);
  if (raw.page.canonicalUrl && !canonical) {
    issue('info', 'canonical-ignored', 'Ignored a canonical link that points to a different origin.');
  }
  const pageId = pageIdForUrl(canonical ?? pageUrl)!;

  const provenance = (): Provenance => ({
    adapterId: raw.adapter.id,
    adapterVersion: raw.adapter.version,
    firstObservedAt: observedAt,
    lastObservedAt: observedAt,
    sourcePageIds: [pageId],
    observations: 1,
    userEdited: false,
  });

  const page: EntityRecord = {
    id: pageId,
    type: 'page',
    kind: 'page',
    site,
    identity: { strategy: 'canonicalUrl', value: canonical ?? pageUrl },
    url: pageUrl,
    canonicalUrl: canonical ?? pageUrl,
    title: raw.page.title || undefined,
    metadata: raw.page.lang ? { lang: raw.page.lang } : {},
    provenance: provenance(),
  };

  const entities = new Map<string, EntityRecord>([[pageId, page]]);
  const refToId = new Map<string, string>([[PAGE_REF, pageId]]);

  for (const [index, draft] of (raw.entities ?? []).entries()) {
    const label = `Entity #${index + 1}`;
    if (!isPlainObject(draft)) {
      issue('error', 'entity-invalid', `${label} is not an object.`);
      continue;
    }
    if (typeof draft.ref !== 'string' || !draft.ref) {
      issue('error', 'entity-ref-missing', `${label} has no ref.`);
      continue;
    }
    if (!ENTITY_TYPES.includes(draft.type)) {
      issue('error', 'entity-type-invalid', `${label} (${draft.ref}) has unknown type ${JSON.stringify(draft.type)}.`);
      continue;
    }
    if (draft.ref === PAGE_REF) {
      if (draft.type !== 'page') {
        issue('error', 'page-ref-misused', `Ref "${PAGE_REF}" is reserved for the page but was used for a ${draft.type}.`);
        continue;
      }
      enrichPage(page, draft, issue);
      continue;
    }
    if (draft.type === 'page') {
      // Other pages are allowed (e.g. links) but need an http(s) URL for identity.
      if (!draft.sourceUrl || !normalizeUrl(draft.sourceUrl)) {
        issue('warning', 'page-url-missing', `Page entity ${draft.ref} has no valid sourceUrl; dropped.`);
        continue;
      }
    }
    const sourceUrl = cleanUrl(draft.sourceUrl, `${draft.ref}.sourceUrl`, issue);
    // Pages are always identified by URL (like the current page), so a linked
    // page and a later visit to it resolve to the same record.
    const identity = draft.type === 'page'
      ? resolveIdentity({ type: 'page', sourceUrl }, site, options.newLocalId)
      : resolveIdentity({ type: draft.type, sourceId: str(draft.sourceId), sourceUrl, key: str(draft.key) }, site, options.newLocalId);
    const mappedId = refToId.get(draft.ref);
    if (mappedId !== undefined && mappedId !== identity.id) {
      issue('warning', 'entity-ref-conflict', `Ref ${draft.ref} is reused for a different entity; the later entity was dropped.`);
      continue;
    }
    if (identity.strategy === 'local') {
      issue('warning', 'identity-local', `${draft.ref} has no sourceId, sourceUrl, or key; stored with a non-durable local id.`);
    }

    const record: EntityRecord = {
      id: identity.id,
      type: draft.type,
      kind: str(draft.kind) ?? draft.type,
      site,
      identity: { strategy: identity.strategy, value: identity.value },
      sourceId: str(draft.sourceId),
      sourceUrl,
      title: str(draft.title),
      mimeType: str(draft.mimeType),
      width: dimension(draft.width, `${draft.ref}.width`, issue),
      height: dimension(draft.height, `${draft.ref}.height`, issue),
      duration: dimension(draft.duration, `${draft.ref}.duration`, issue),
      metadata: metadata(draft.metadata, draft.ref, issue),
      provenance: provenance(),
    };
    if (draft.type === 'page') {
      record.url = sourceUrl;
      record.canonicalUrl = sourceUrl;
    }
    stripUndefined(record);

    const existing = entities.get(record.id);
    entities.set(record.id, existing ? mergeDraftRecords(existing, record) : record);
    if (!refToId.has(draft.ref)) refToId.set(draft.ref, record.id);
  }

  const relationships = new Map<string, RelationshipRecord>();
  for (const [index, rel] of (raw.relationships ?? []).entries()) {
    if (!isPlainObject(rel) || typeof rel.type !== 'string' || !RELATIONSHIP_TYPE.test(rel.type)) {
      issue('warning', 'relationship-invalid', `Relationship #${index + 1} has an invalid type.`);
      continue;
    }
    const fromId = refToId.get(rel.from);
    const toId = refToId.get(rel.to);
    if (!fromId || !toId) {
      issue('warning', 'relationship-dangling', `Relationship ${rel.from} -${rel.type}-> ${rel.to} references an unknown ref; dropped.`);
      continue;
    }
    if (fromId === toId) continue;
    const id = relationshipId(fromId, rel.type, toId);
    relationships.set(id, {
      id,
      fromId,
      type: rel.type,
      toId,
      observedAt,
      firstObservedAt: observedAt,
      sourcePageId: pageId,
      sourcePageIds: [pageId],
      site,
      adapterId: raw.adapter.id,
      adapterVersion: raw.adapter.version,
    });
  }

  const media = new Map<string, MediaRecord>();
  for (const [index, candidate] of (raw.media ?? []).entries()) {
    if (!isPlainObject(candidate) || typeof candidate.url !== 'string') {
      issue('warning', 'media-invalid', `Media candidate #${index + 1} has no URL.`);
      continue;
    }
    const classification = classifyMedia(candidate);
    const id = mediaId(classification.identityUrl);
    let assetId: string | undefined;
    if (candidate.assetRef) {
      assetId = refToId.get(candidate.assetRef);
      if (!assetId) issue('warning', 'media-asset-unknown', `Media ${index + 1} references unknown asset ref ${candidate.assetRef}.`);
    }
    const record: MediaRecord = {
      id,
      url: classification.url,
      kind: MEDIA_KINDS.has(candidate.kind) ? candidate.kind : 'other',
      mimeType: str(candidate.mimeType),
      filename: safeFilename(candidate.filename, classification.url),
      label: str(candidate.label),
      width: dimension(candidate.width, `media ${index + 1} width`, issue),
      height: dimension(candidate.height, `media ${index + 1} height`, issue),
      delivery: classification.delivery,
      deliveryReason: classification.reason,
      assetId,
      site,
      provenance: provenance(),
    };
    stripUndefined(record);
    if (!media.has(id)) media.set(id, record);
  }

  return {
    pageId,
    site,
    observedAt,
    adapter: raw.adapter,
    entities: [...entities.values()],
    relationships: [...relationships.values()],
    media: [...media.values()],
    diagnostics,
  };
}

type Issue = (level: Diagnostic['level'], code: string, message: string) => void;

function acceptCanonical(canonical: string | undefined, pageUrl: string): string | null {
  if (!canonical) return null;
  const normalized = normalizeUrl(canonical, pageUrl);
  if (!normalized) return null;
  return new URL(normalized).origin === new URL(pageUrl).origin ? normalized : null;
}

function enrichPage(page: EntityRecord, draft: EntityDraft, issue: Issue) {
  if (str(draft.kind)) page.kind = draft.kind!;
  if (str(draft.title)) page.title = draft.title;
  if (str(draft.sourceId)) page.sourceId = draft.sourceId;
  Object.assign(page.metadata, metadata(draft.metadata, PAGE_REF, issue));
}

function mergeDraftRecords(a: EntityRecord, b: EntityRecord): EntityRecord {
  const merged: EntityRecord = { ...a };
  for (const [k, v] of Object.entries(b)) {
    if (v !== undefined && k !== 'metadata' && k !== 'provenance') (merged as unknown as Record<string, unknown>)[k] = v;
  }
  merged.metadata = { ...a.metadata, ...b.metadata };
  return merged;
}

function str(value: unknown): string | undefined {
  return typeof value === 'string' && value.trim() ? value.trim() : undefined;
}

function cleanUrl(value: unknown, field: string, issue: Issue): string | undefined {
  if (value === undefined) return undefined;
  const url = typeof value === 'string' ? normalizeUrl(value) : null;
  if (!url) {
    issue('warning', 'url-invalid', `${field} is not an absolute http(s) URL; ignored.`);
    return undefined;
  }
  return url;
}

function dimension(value: unknown, field: string, issue: Issue): number | undefined {
  if (value === undefined) return undefined;
  if (typeof value === 'number' && Number.isFinite(value) && value >= 0) return value;
  issue('warning', 'number-invalid', `${field} is not a non-negative number; ignored.`);
  return undefined;
}

function metadata(value: unknown, ref: string, issue: Issue): JsonObject {
  if (value === undefined) return {};
  if (!isPlainObject(value)) {
    issue('warning', 'metadata-invalid', `${ref}.metadata is not an object; ignored.`);
    return {};
  }
  const dropped = { count: 0 };
  const json = toJsonValue(value, dropped) as JsonObject;
  if (dropped.count) issue('warning', 'metadata-non-json', `${ref}.metadata had ${dropped.count} non-JSON value(s); dropped.`);
  return json;
}

function stripUndefined(record: object) {
  for (const [k, v] of Object.entries(record)) {
    if (v === undefined) delete (record as Record<string, unknown>)[k];
  }
}
