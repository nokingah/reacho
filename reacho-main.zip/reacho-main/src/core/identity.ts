import { normalizeUrl } from '../shared/url';
import type { EntityType, IdentityStrategy } from '../shared/types';

export interface Identity {
  id: string;
  strategy: IdentityStrategy;
  value: string;
}

export interface IdentityInput {
  type: EntityType;
  sourceId?: string;
  sourceUrl?: string;
  key?: string;
}

/**
 * Resolve a durable record id, following docs/data-model.md:
 *   1. site-native stable ID
 *   2. canonical source URL
 *   3. adapter-defined deterministic compound key
 *   4. generated local ID (not durable; reported as a warning by normalize)
 *
 * Site-native IDs and compound keys are namespaced by `site` so two sites can
 * share an ID without colliding; URL identities already carry their host.
 */
export function resolveIdentity(input: IdentityInput, site: string, newLocalId: () => string = randomId): Identity {
  const sourceId = input.sourceId?.trim();
  if (sourceId) {
    return { id: `${input.type}:${site}:id:${sourceId}`, strategy: 'sourceId', value: sourceId };
  }
  const url = input.sourceUrl ? normalizeUrl(input.sourceUrl) : null;
  if (url) {
    return { id: `${input.type}:url:${url}`, strategy: 'canonicalUrl', value: url };
  }
  const key = input.key?.trim();
  if (key) {
    return { id: `${input.type}:${site}:key:${key}`, strategy: 'compoundKey', value: key };
  }
  const local = newLocalId();
  return { id: `${input.type}:local:${local}`, strategy: 'local', value: local };
}

/** Page identity is always URL-based so it does not depend on which adapter ran. */
export function pageIdForUrl(url: string): string | null {
  const normalized = normalizeUrl(url);
  return normalized ? `page:url:${normalized}` : null;
}

export function relationshipId(fromId: string, type: string, toId: string): string {
  return `${fromId}|${type}|${toId}`;
}

export function mediaId(url: string): string {
  return `media:${url}`;
}

function randomId(): string {
  return crypto.randomUUID();
}
