import type {
  DownloadState,
  EntityRecord,
  LocalState,
  MediaRecord,
  NormalizedExtraction,
  RelationshipRecord,
  WorkspaceGraph,
} from '../shared/types';
import { mergeEntity, mergeMedia, mergeRelationship } from './merge';

export const DB_NAME = 'reacho-workspace';
export const SCHEMA_VERSION = 1;

const ENTITIES = 'entities';
const RELATIONSHIPS = 'relationships';
const MEDIA = 'media';
const LOCAL_STATE = 'localState';
const META = 'meta';

type Migration = (db: IDBDatabase, tx: IDBTransaction) => void;

/**
 * Explicit, ordered schema migrations. Migration N upgrades a database from
 * version N-1 to N. Add new entries here; never edit a released one.
 */
export const MIGRATIONS: Record<number, Migration> = {
  1: (db) => {
    const entities = db.createObjectStore(ENTITIES, { keyPath: 'id' });
    entities.createIndex('type', 'type');
    entities.createIndex('site', 'site');
    entities.createIndex('url', 'url');
    entities.createIndex('sourcePageIds', 'provenance.sourcePageIds', { multiEntry: true });

    const relationships = db.createObjectStore(RELATIONSHIPS, { keyPath: 'id' });
    relationships.createIndex('fromId', 'fromId');
    relationships.createIndex('toId', 'toId');
    relationships.createIndex('site', 'site');
    relationships.createIndex('sourcePageIds', 'sourcePageIds', { multiEntry: true });

    const media = db.createObjectStore(MEDIA, { keyPath: 'id' });
    media.createIndex('site', 'site');
    media.createIndex('assetId', 'assetId');
    media.createIndex('sourcePageIds', 'provenance.sourcePageIds', { multiEntry: true });

    db.createObjectStore(LOCAL_STATE, { keyPath: 'id' });
    db.createObjectStore(META, { keyPath: 'key' });
  },
};

export interface CommitSummary {
  entitiesCreated: number;
  entitiesUpdated: number;
  relationshipsCreated: number;
  relationshipsUpdated: number;
  mediaCreated: number;
  mediaUpdated: number;
  /** Ids of records in this extraction that already existed (linked to prior records). */
  previouslyKnown: string[];
}

export interface WorkspaceStats {
  entities: number;
  relationships: number;
  media: number;
  localState: number;
  schemaVersion: number;
}

export class Workspace {
  private constructor(private readonly db: IDBDatabase) {}

  static open(factory: IDBFactory = indexedDB, name = DB_NAME): Promise<Workspace> {
    return new Promise((resolve, reject) => {
      const request = factory.open(name, SCHEMA_VERSION);
      request.onupgradeneeded = (event) => {
        const db = request.result;
        const tx = request.transaction!;
        for (let v = event.oldVersion + 1; v <= SCHEMA_VERSION; v++) {
          const migrate = MIGRATIONS[v];
          if (!migrate) throw new Error(`Missing workspace migration to version ${v}`);
          migrate(db, tx);
        }
        tx.objectStore(META).put({ key: 'schema', version: SCHEMA_VERSION, migratedAt: new Date().toISOString() });
      };
      request.onsuccess = () => resolve(new Workspace(request.result));
      request.onerror = () => reject(request.error);
      request.onblocked = () => reject(new Error('Workspace upgrade blocked by another open Reacho view.'));
    });
  }

  close() {
    this.db.close();
  }

  async schemaVersion(): Promise<number> {
    const tx = this.db.transaction(META);
    const record = await req<{ version: number } | undefined>(tx.objectStore(META).get('schema'));
    return record?.version ?? 0;
  }

  /** Persist a normalized extraction, merging with records already stored. */
  async commit(extraction: NormalizedExtraction): Promise<CommitSummary> {
    const tx = this.db.transaction([ENTITIES, RELATIONSHIPS, MEDIA], 'readwrite');
    const entities = tx.objectStore(ENTITIES);
    const relationships = tx.objectStore(RELATIONSHIPS);
    const media = tx.objectStore(MEDIA);

    const [prevEntities, prevRelationships, prevMedia] = await Promise.all([
      Promise.all(extraction.entities.map((e) => req<EntityRecord | undefined>(entities.get(e.id)))),
      Promise.all(extraction.relationships.map((r) => req<RelationshipRecord | undefined>(relationships.get(r.id)))),
      Promise.all(extraction.media.map((m) => req<MediaRecord | undefined>(media.get(m.id)))),
    ]);

    const summary: CommitSummary = {
      entitiesCreated: 0,
      entitiesUpdated: 0,
      relationshipsCreated: 0,
      relationshipsUpdated: 0,
      mediaCreated: 0,
      mediaUpdated: 0,
      previouslyKnown: [],
    };

    extraction.entities.forEach((next, i) => {
      const prev = prevEntities[i];
      if (prev) {
        summary.entitiesUpdated++;
        summary.previouslyKnown.push(next.id);
      } else {
        summary.entitiesCreated++;
      }
      entities.put(prev ? mergeEntity(prev, next) : next);
    });
    extraction.relationships.forEach((next, i) => {
      const prev = prevRelationships[i];
      if (prev) {
        summary.relationshipsUpdated++;
        summary.previouslyKnown.push(next.id);
      } else {
        summary.relationshipsCreated++;
      }
      relationships.put(prev ? mergeRelationship(prev, next) : next);
    });
    extraction.media.forEach((next, i) => {
      const prev = prevMedia[i];
      if (prev) summary.mediaUpdated++;
      else summary.mediaCreated++;
      media.put(prev ? mergeMedia(prev, next) : next);
    });

    await done(tx);
    return summary;
  }

  async getEntity(id: string): Promise<EntityRecord | undefined> {
    return req(this.db.transaction(ENTITIES).objectStore(ENTITIES).get(id));
  }

  /** Find the stored Page record for a tab URL (by id or by observed URL). */
  async findPage(pageId: string | null, normalizedUrl: string | null): Promise<EntityRecord | undefined> {
    const store = this.db.transaction(ENTITIES).objectStore(ENTITIES);
    if (pageId) {
      const byId = await req<EntityRecord | undefined>(store.get(pageId));
      if (byId) return byId;
    }
    if (normalizedUrl) {
      return req<EntityRecord | undefined>(store.index('url').get(normalizedUrl));
    }
    return undefined;
  }

  /**
   * Records observed on a page, plus every stored relationship touching them
   * and the records at the other end — so links to records captured on
   * earlier pages are included.
   */
  async pageGraph(pageId: string): Promise<WorkspaceGraph> {
    const tx = this.db.transaction([ENTITIES, RELATIONSHIPS, MEDIA, LOCAL_STATE]);
    const entityStore = tx.objectStore(ENTITIES);
    const relStore = tx.objectStore(RELATIONSHIPS);

    const observed = await req<EntityRecord[]>(entityStore.index('sourcePageIds').getAll(pageId));
    const page = await req<EntityRecord | undefined>(entityStore.get(pageId));
    const entities = new Map(observed.map((e) => [e.id, e]));
    if (page) entities.set(page.id, page);

    const relationships = new Map<string, RelationshipRecord>();
    const ids = [...entities.keys()];
    const touching = await Promise.all(
      ids.flatMap((id) => [
        req<RelationshipRecord[]>(relStore.index('fromId').getAll(id)),
        req<RelationshipRecord[]>(relStore.index('toId').getAll(id)),
      ]),
    );
    for (const rel of touching.flat()) relationships.set(rel.id, rel);

    const missing = new Set<string>();
    for (const rel of relationships.values()) {
      if (!entities.has(rel.fromId)) missing.add(rel.fromId);
      if (!entities.has(rel.toId)) missing.add(rel.toId);
    }
    const linked = await Promise.all([...missing].map((id) => req<EntityRecord | undefined>(entityStore.get(id))));
    for (const e of linked) if (e) entities.set(e.id, e);

    const media = await req<MediaRecord[]>(tx.objectStore(MEDIA).index('sourcePageIds').getAll(pageId));
    const localStore = tx.objectStore(LOCAL_STATE);
    const stateIds = [...entities.keys(), ...media.map((m) => m.id)];
    const states = await Promise.all(stateIds.map((id) => req<LocalState | undefined>(localStore.get(id))));

    return {
      entities: [...entities.values()],
      relationships: [...relationships.values()],
      media,
      localState: states.filter((s): s is LocalState => Boolean(s)),
    };
  }

  async siteGraph(site: string): Promise<WorkspaceGraph> {
    const tx = this.db.transaction([ENTITIES, RELATIONSHIPS, MEDIA, LOCAL_STATE]);
    const [entities, relationships, media, localState] = await Promise.all([
      req<EntityRecord[]>(tx.objectStore(ENTITIES).index('site').getAll(site)),
      req<RelationshipRecord[]>(tx.objectStore(RELATIONSHIPS).index('site').getAll(site)),
      req<MediaRecord[]>(tx.objectStore(MEDIA).index('site').getAll(site)),
      req<LocalState[]>(tx.objectStore(LOCAL_STATE).getAll()),
    ]);
    const ids = new Set([...entities.map((e) => e.id), ...media.map((m) => m.id)]);
    return { entities, relationships, media, localState: localState.filter((s) => ids.has(s.id)) };
  }

  async all(): Promise<WorkspaceGraph> {
    const tx = this.db.transaction([ENTITIES, RELATIONSHIPS, MEDIA, LOCAL_STATE]);
    const [entities, relationships, media, localState] = await Promise.all([
      req<EntityRecord[]>(tx.objectStore(ENTITIES).getAll()),
      req<RelationshipRecord[]>(tx.objectStore(RELATIONSHIPS).getAll()),
      req<MediaRecord[]>(tx.objectStore(MEDIA).getAll()),
      req<LocalState[]>(tx.objectStore(LOCAL_STATE).getAll()),
    ]);
    return { entities, relationships, media, localState };
  }

  async stats(): Promise<WorkspaceStats> {
    const tx = this.db.transaction([ENTITIES, RELATIONSHIPS, MEDIA, LOCAL_STATE]);
    const [entities, relationships, media, localState] = await Promise.all([
      req<number>(tx.objectStore(ENTITIES).count()),
      req<number>(tx.objectStore(RELATIONSHIPS).count()),
      req<number>(tx.objectStore(MEDIA).count()),
      req<number>(tx.objectStore(LOCAL_STATE).count()),
    ]);
    return { entities, relationships, media, localState, schemaVersion: await this.schemaVersion() };
  }

  /** Record download progress for one or more records (media and its asset). */
  async setDownload(ids: string[], download: DownloadState, now: string): Promise<void> {
    const tx = this.db.transaction(LOCAL_STATE, 'readwrite');
    const store = tx.objectStore(LOCAL_STATE);
    const prev = await Promise.all(ids.map((id) => req<LocalState | undefined>(store.get(id))));
    ids.forEach((id, i) => store.put({ ...prev[i], id, updatedAt: now, download }));
    await done(tx);
  }

  async findByDownloadId(downloadId: number): Promise<LocalState[]> {
    const all = await req<LocalState[]>(this.db.transaction(LOCAL_STATE).objectStore(LOCAL_STATE).getAll());
    return all.filter((s) => s.download?.downloadId === downloadId);
  }

  /** Delete every record captured from one site, including its local state. */
  async clearSite(site: string): Promise<number> {
    const tx = this.db.transaction([ENTITIES, RELATIONSHIPS, MEDIA, LOCAL_STATE], 'readwrite');
    const [entityKeys, relKeys, mediaKeys] = await Promise.all([
      req<IDBValidKey[]>(tx.objectStore(ENTITIES).index('site').getAllKeys(site)),
      req<IDBValidKey[]>(tx.objectStore(RELATIONSHIPS).index('site').getAllKeys(site)),
      req<IDBValidKey[]>(tx.objectStore(MEDIA).index('site').getAllKeys(site)),
    ]);
    for (const k of entityKeys) {
      tx.objectStore(ENTITIES).delete(k);
      tx.objectStore(LOCAL_STATE).delete(k);
    }
    for (const k of relKeys) tx.objectStore(RELATIONSHIPS).delete(k);
    for (const k of mediaKeys) {
      tx.objectStore(MEDIA).delete(k);
      tx.objectStore(LOCAL_STATE).delete(k);
    }
    await done(tx);
    return entityKeys.length + relKeys.length + mediaKeys.length;
  }

  async clearAll(): Promise<void> {
    const tx = this.db.transaction([ENTITIES, RELATIONSHIPS, MEDIA, LOCAL_STATE], 'readwrite');
    for (const name of [ENTITIES, RELATIONSHIPS, MEDIA, LOCAL_STATE]) tx.objectStore(name).clear();
    await done(tx);
  }
}

function req<T>(request: IDBRequest): Promise<T> {
  return new Promise((resolve, reject) => {
    request.onsuccess = () => resolve(request.result as T);
    request.onerror = () => reject(request.error);
  });
}

function done(tx: IDBTransaction): Promise<void> {
  return new Promise((resolve, reject) => {
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
    tx.onabort = () => reject(tx.error ?? new Error('Transaction aborted'));
  });
}
