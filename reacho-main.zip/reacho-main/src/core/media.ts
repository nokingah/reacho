import type { MediaCandidate, MediaDelivery, MediaKind } from '../shared/types';
import { normalizeUrl } from '../shared/url';

const DIRECT_EXTENSIONS: Record<string, MediaKind> = {
  jpg: 'image', jpeg: 'image', png: 'image', gif: 'image', webp: 'image', avif: 'image', svg: 'image', tif: 'image', tiff: 'image', bmp: 'image',
  mp4: 'video', webm: 'video', ogv: 'video', mov: 'video', mkv: 'video', mpg: 'video', mpeg: 'video',
  mp3: 'audio', ogg: 'audio', oga: 'audio', opus: 'audio', wav: 'audio', flac: 'audio', m4a: 'audio', aac: 'audio', mid: 'audio',
  pdf: 'document', djvu: 'document', epub: 'document', txt: 'document', csv: 'document', json: 'document',
  zip: 'archive', tar: 'archive', gz: 'archive', '7z': 'archive',
};

const SEGMENTED_EXTENSIONS = new Set(['m3u8', 'mpd', 'ism', 'f4m']);
const SEGMENTED_MIME = new Set(['application/vnd.apple.mpegurl', 'application/x-mpegurl', 'audio/mpegurl', 'application/dash+xml', 'application/vnd.ms-sstr+xml']);

export function extensionOf(pathname: string): string {
  const last = pathname.split('/').pop() ?? '';
  const dot = last.lastIndexOf('.');
  return dot > 0 ? last.slice(dot + 1).toLowerCase() : '';
}

export function kindForExtension(ext: string): MediaKind | undefined {
  return DIRECT_EXTENSIONS[ext.toLowerCase()];
}

export interface MediaClassification {
  delivery: MediaDelivery;
  reason: string;
  /** URL to retrieve, exactly as discovered (minus any fragment), so signed or order-sensitive queries still work. */
  url: string;
  /** Normalized URL used only for identity/deduplication. */
  identityUrl: string;
}

/**
 * Decide whether a discovered resource is an ordinary direct file Reacho may
 * download. Only `direct` resources get a Save action. Segmented streams,
 * page-scoped blob/data URLs, and anything an adapter marks as protected are
 * reported but never downloaded (no universal media promise; no DRM handling).
 */
export function classifyMedia(candidate: Pick<MediaCandidate, 'url' | 'mimeType' | 'delivery'>): MediaClassification {
  let parsed: URL;
  try {
    parsed = new URL(candidate.url);
  } catch {
    return { delivery: 'unsupported', reason: 'Not a valid absolute URL.', url: candidate.url, identityUrl: candidate.url };
  }
  if (parsed.protocol === 'blob:') {
    return { delivery: 'unsupported', reason: 'blob: URL is page-scoped (in-memory or MediaSource); not an ordinary resource.', url: candidate.url, identityUrl: candidate.url };
  }
  if (parsed.protocol === 'data:') {
    const short = candidate.url.slice(0, 64);
    return { delivery: 'unsupported', reason: 'Inline data: URI; not a downloadable resource.', url: short, identityUrl: short };
  }
  const identityUrl = normalizeUrl(candidate.url);
  if (!identityUrl) {
    return { delivery: 'unsupported', reason: `Unsupported scheme ${parsed.protocol}`, url: candidate.url, identityUrl: candidate.url };
  }
  parsed.hash = '';
  const url = parsed.href;
  if (candidate.delivery === 'protected') {
    return { delivery: 'unsupported', reason: 'Adapter reports protected delivery (DRM/access control); out of scope.', url, identityUrl };
  }
  const ext = extensionOf(parsed.pathname);
  const mime = candidate.mimeType?.toLowerCase();
  if (candidate.delivery === 'segmented' || SEGMENTED_EXTENSIONS.has(ext) || (mime && SEGMENTED_MIME.has(mime))) {
    return { delivery: 'segmented', reason: 'Streaming manifest (HLS/DASH). Segmented media is not downloaded by Reacho.', url, identityUrl };
  }
  if (candidate.delivery === 'direct') {
    return { delivery: 'direct', reason: 'Adapter identified a direct file URL.', url, identityUrl };
  }
  if (ext && DIRECT_EXTENSIONS[ext]) {
    return { delivery: 'direct', reason: `Direct file URL (.${ext}).`, url, identityUrl };
  }
  return { delivery: 'unresolved', reason: 'Could not confirm this URL is a direct file; not offered for download.', url, identityUrl };
}

/** Derive a safe download file name (no directories, no reserved characters). */
export function safeFilename(preferred: string | undefined, url: string, fallback = 'resource'): string {
  let name = preferred?.trim() ?? '';
  if (!name) {
    try {
      const last = new URL(url).pathname.split('/').pop() ?? '';
      name = decodeURIComponent(last);
    } catch {
      name = '';
    }
  }
  name = safePathSegment(name).slice(0, 150);
  return name || fallback;
}

/**
 * Make one path segment acceptable to chrome.downloads: no separators or
 * reserved characters, no leading/trailing dots, and no shell-integrated
 * extensions (Chrome rejects names ending in .local or .lnk).
 */
export function safePathSegment(value: string): string {
  return value
    .replace(/[\u0000-\u001f\u007f<>:"/\\|?*~]/g, '_')
    .replace(/^[.\s]+|[.\s]+$/g, '')
    .replace(/\.(local|lnk)$/i, '_$1');
}
