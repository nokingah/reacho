import type { EntityRecord, MediaRecord, Provenance, RelationshipRecord } from '../shared/types';

// Merge rules for re-observing a record that already exists in the workspace.
// Newer observations win for source fields they provide; fields the newer
// observation lacks are kept (a listing "stub" never erases detail captured on
// the record's own page). Local state lives in a separate store and is never
// touched here.

export function mergeProvenance(prev: Provenance, next: Provenance): Provenance {
  return {
    adapterId: next.adapterId,
    adapterVersion: next.adapterVersion,
    firstObservedAt: minIso(prev.firstObservedAt, next.firstObservedAt),
    lastObservedAt: maxIso(prev.lastObservedAt, next.lastObservedAt),
    sourcePageIds: union(prev.sourcePageIds, next.sourcePageIds),
    observations: prev.observations + next.observations,
    userEdited: prev.userEdited || next.userEdited,
  };
}

export function mergeEntity(prev: EntityRecord, next: EntityRecord): EntityRecord {
  const merged: EntityRecord = { ...prev };
  for (const [k, v] of Object.entries(next)) {
    if (v === undefined || k === 'id' || k === 'identity' || k === 'metadata' || k === 'provenance') continue;
    (merged as unknown as Record<string, unknown>)[k] = v;
  }
  // A generic kind (equal to the type) never overrides a specific one.
  if (next.kind === next.type && prev.kind !== prev.type) merged.kind = prev.kind;
  merged.metadata = { ...prev.metadata, ...next.metadata };
  merged.provenance = mergeProvenance(prev.provenance, next.provenance);
  return merged;
}

export function mergeRelationship(prev: RelationshipRecord, next: RelationshipRecord): RelationshipRecord {
  return {
    ...prev,
    observedAt: maxIso(prev.observedAt, next.observedAt),
    firstObservedAt: minIso(prev.firstObservedAt, next.firstObservedAt),
    sourcePageId: next.sourcePageId,
    sourcePageIds: union(prev.sourcePageIds, next.sourcePageIds),
    adapterId: next.adapterId,
    adapterVersion: next.adapterVersion,
  };
}

export function mergeMedia(prev: MediaRecord, next: MediaRecord): MediaRecord {
  return {
    ...prev,
    ...next,
    assetId: next.assetId ?? prev.assetId,
    label: next.label ?? prev.label,
    provenance: mergeProvenance(prev.provenance, next.provenance),
  };
}

function union(a: string[], b: string[]): string[] {
  return [...new Set([...a, ...b])];
}

function minIso(a: string, b: string): string {
  return a <= b ? a : b;
}

function maxIso(a: string, b: string): string {
  return a >= b ? a : b;
}
