import type {
  Diagnostic,
  DiagnosticLevel,
  PageContext,
  Phase,
  PhaseTiming,
  RawExtraction,
  SiteAdapter,
} from '../shared/types';
import { collectStructuredData } from './structured-data';

export interface RunEnvironment {
  document: Document;
  url: string;
  title: string;
  now: string;
}

export interface RunOptions {
  /** Per-phase timeout. */
  timeoutMs?: number;
}

const DEFAULT_TIMEOUT_MS = 15_000;

/**
 * Execute an adapter against a page with a bounded context. Runs in the
 * content-script world. Every phase is timed and isolated: a failing optional
 * phase is reported and the run continues; a failing `extract` yields no
 * entities. The result is JSON-safe so it can cross the extension boundary.
 */
export async function runAdapter(adapter: SiteAdapter | undefined, env: RunEnvironment, options: RunOptions = {}): Promise<RawExtraction> {
  const diagnostics: Diagnostic[] = [];
  const timings: PhaseTiming[] = [];
  let phase: Phase = 'bridge';
  const report = (level: DiagnosticLevel, code: string, message: string) =>
    diagnostics.push({ level, code: String(code), message: String(message).slice(0, 500), phase });

  const result: RawExtraction = {
    adapter: { id: adapter?.id ?? 'none', version: adapter?.version ?? '0' },
    page: snapshot(env),
    observedAt: env.now,
    discoveries: [],
    entities: [],
    relationships: [],
    media: [],
    structuredData: { jsonLd: [], jsonLdErrors: 0, meta: {} },
    diagnostics,
    timings,
  };

  try {
    result.structuredData = collectStructuredData(env.document);
  } catch (err) {
    report('warning', 'structured-data-failed', describe(err));
  }

  if (!adapter) {
    report('error', 'adapter-not-found', 'The requested adapter is not registered in this build.');
    return result;
  }

  const url = new URL(env.url);
  phase = 'match';
  if (!adapter.matches(url)) {
    report('error', 'adapter-mismatch', `Adapter ${adapter.id} does not match ${url.origin}${url.pathname}.`);
    return result;
  }

  const ctx: PageContext = { url, title: env.title, document: env.document, now: env.now, report };
  const timeoutMs = options.timeoutMs ?? DEFAULT_TIMEOUT_MS;

  const runPhase = async <T>(name: Phase, fn: (() => Promise<T[]>) | undefined): Promise<T[]> => {
    if (!fn) return [];
    phase = name;
    const started = performance.now();
    try {
      const value = await withTimeout(fn(), timeoutMs, `${name} timed out after ${timeoutMs} ms`);
      if (!Array.isArray(value)) throw new TypeError(`${name}() must resolve to an array`);
      timings.push({ phase: name, ms: Math.round(performance.now() - started), ok: true, count: value.length });
      return value;
    } catch (err) {
      timings.push({ phase: name, ms: Math.round(performance.now() - started), ok: false });
      report('error', `${name}-failed`, describe(err));
      return [];
    }
  };

  result.discoveries = await runPhase('discover', adapter.discover && (() => adapter.discover!(ctx)));
  result.entities = await runPhase('extract', () => adapter.extract(ctx));
  result.relationships = await runPhase('relate', adapter.relate && (() => adapter.relate!(result.entities, ctx)));
  result.media = await runPhase('media', adapter.media && (() => adapter.media!(ctx)));
  phase = 'bridge';

  if (result.entities.length === 0 && !diagnostics.some((d) => d.level === 'error')) {
    report('warning', 'no-entities', 'The adapter matched but extracted no entities. Selectors may be out of date.');
  }

  try {
    return JSON.parse(JSON.stringify(result)) as RawExtraction;
  } catch (err) {
    return { ...result, entities: [], relationships: [], media: [], diagnostics: [...diagnostics, { level: 'error', code: 'output-not-serializable', message: describe(err), phase: 'bridge' }] };
  }
}

function snapshot(env: RunEnvironment): RawExtraction['page'] {
  const canonical = env.document.querySelector('link[rel="canonical"]')?.getAttribute('href') ?? undefined;
  let canonicalUrl: string | undefined;
  if (canonical) {
    try {
      canonicalUrl = new URL(canonical, env.url).href;
    } catch {
      canonicalUrl = undefined;
    }
  }
  const lang = env.document.documentElement?.getAttribute('lang') ?? undefined;
  return { url: env.url, title: env.title, canonicalUrl, lang: lang || undefined };
}

function describe(err: unknown): string {
  if (err instanceof Error) return `${err.name}: ${err.message}`.slice(0, 500);
  return String(err).slice(0, 500);
}

function withTimeout<T>(promise: Promise<T>, ms: number, message: string): Promise<T> {
  let timer: ReturnType<typeof setTimeout>;
  return Promise.race([
    promise.finally(() => clearTimeout(timer)),
    new Promise<never>((_, reject) => {
      timer = setTimeout(() => reject(new Error(message)), ms);
    }),
  ]);
}
