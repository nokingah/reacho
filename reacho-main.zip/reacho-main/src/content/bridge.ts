// Content bridge. Injected on demand with chrome.scripting.executeScript into
// the active tab's top frame only after the user acts (activeTab) or has
// granted per-site access. It never runs on its own, never touches the
// network, and returns only the adapter's JSON-safe output to the side panel.

import { getAdapter } from '../adapters/registry';
import { runAdapter } from '../core/runtime';
import type { RawExtraction } from '../shared/types';

export interface ReachoBridge {
  version: string;
  run(adapterId: string): Promise<RawExtraction>;
}

declare global {
  // eslint-disable-next-line no-var
  var __reachoBridge: ReachoBridge | undefined;
}

globalThis.__reachoBridge = {
  version: __REACHO_VERSION__,
  run(adapterId) {
    return runAdapter(getAdapter(adapterId), {
      document,
      url: location.href,
      title: document.title,
      now: new Date().toISOString(),
    });
  },
};
