// Shared types for Reacho.
//
// Two layers are kept deliberately separate:
//   * adapter output ("drafts") — what site-specific code returns; refers to
//     other drafts by adapter-local `ref` strings and knows nothing about storage;
//   * workspace records — normalized, identity-resolved, provenance-carrying
//     records produced by core and persisted in IndexedDB.

export type JsonValue = string | number | boolean | null | JsonValue[] | { [key: string]: JsonValue };
export type JsonObject = { [key: string]: JsonValue };

export type EntityType = 'page' | 'collection' | 'asset' | 'person';
export const ENTITY_TYPES: readonly EntityType[] = ['page', 'collection', 'asset', 'person'];

/**
 * Reserved draft ref for the page being extracted. Core always creates the Page
 * record itself; an adapter may return a draft with this ref to enrich it, and
 * may use it as a relationship endpoint.
 */
export const PAGE_REF = 'page';

// ---------------------------------------------------------------------------
// Adapter contract (see docs/adapters.md)
// ---------------------------------------------------------------------------

export type DiagnosticLevel = 'info' | 'warning' | 'error';

export interface PageContext {
  url: URL;
  title: string;
  document: Document;
  /** ISO timestamp for this extraction run. */
  now: string;
  /** Report a recoverable extraction problem. Shown in the Diagnostics view. */
  report(level: DiagnosticLevel, code: string, message: string): void;
}

/** Cheap description of what an adapter recognizes on the page. */
export interface Discovery {
  kind: string;
  label: string;
  count?: number;
}

/** Adapter output: one normalized entity, before identity resolution. */
export interface EntityDraft {
  /** Adapter-local reference, unique within one extraction. */
  ref: string;
  type: EntityType;
  /** Site-specific label: album, category, file, gallery, thread, ... */
  kind?: string;
  /** Site-native stable identifier (preferred identity). */
  sourceId?: string;
  /** Canonical URL of the thing itself (second identity choice). */
  sourceUrl?: string;
  /** Adapter-defined deterministic compound key (third identity choice). */
  key?: string;
  title?: string;
  mimeType?: string;
  width?: number;
  height?: number;
  /** Seconds. */
  duration?: number;
  metadata?: JsonObject;
}

/** Adapter output: a relationship between two drafts, by ref. */
export interface RelationshipDraft {
  from: string;
  type: string;
  to: string;
}

export type MediaKind = 'image' | 'video' | 'audio' | 'document' | 'archive' | 'other';

export interface MediaCandidate {
  url: string;
  kind: MediaKind;
  mimeType?: string;
  /** Draft ref of the asset this resource belongs to, if any. */
  assetRef?: string;
  /** Suggested file name; core sanitizes it. */
  filename?: string;
  label?: string;
  width?: number;
  height?: number;
  /** Adapter hint about delivery. Core makes the final classification. */
  delivery?: 'direct' | 'segmented' | 'protected';
}

export interface SiteAdapter {
  id: string;
  version: string;
  /** Human-readable name for the UI. */
  name: string;
  description?: string;
  /** Identity namespace for site-native IDs. Defaults to the page hostname. */
  site?: string;
  /**
   * Match patterns this adapter may be granted as *optional*, per-site,
   * user-approved persistent access. Every pattern must also be listed in the
   * manifest's `optional_host_permissions` (enforced by tests).
   */
  hostPermissions: string[];
  /** Marks fixture/demo adapters so the UI can label them. */
  demo?: boolean;
  matches(url: URL): boolean;

  discover?(ctx: PageContext): Promise<Discovery[]>;
  extract(ctx: PageContext): Promise<EntityDraft[]>;
  relate?(entities: EntityDraft[], ctx: PageContext): Promise<RelationshipDraft[]>;
  media?(ctx: PageContext): Promise<MediaCandidate[]>;
}

// ---------------------------------------------------------------------------
// Bridge output (content script -> side panel)
// ---------------------------------------------------------------------------

export type Phase = 'bridge' | 'match' | 'discover' | 'extract' | 'relate' | 'media' | 'normalize' | 'persist';

export interface Diagnostic {
  level: DiagnosticLevel;
  code: string;
  message: string;
  phase?: Phase;
}

export interface PhaseTiming {
  phase: Phase;
  ms: number;
  ok: boolean;
  count?: number;
}

export interface PageSnapshot {
  url: string;
  title: string;
  canonicalUrl?: string;
  lang?: string;
}

/** Page-visible structured data, shown raw in the inspector (not persisted). */
export interface StructuredData {
  jsonLd: JsonValue[];
  jsonLdErrors: number;
  meta: Record<string, string>;
}

export interface RawExtraction {
  adapter: { id: string; version: string };
  page: PageSnapshot;
  observedAt: string;
  discoveries: Discovery[];
  entities: EntityDraft[];
  relationships: RelationshipDraft[];
  media: MediaCandidate[];
  structuredData: StructuredData;
  diagnostics: Diagnostic[];
  timings: PhaseTiming[];
}

// ---------------------------------------------------------------------------
// Workspace records (IndexedDB)
// ---------------------------------------------------------------------------

export type IdentityStrategy = 'sourceId' | 'canonicalUrl' | 'compoundKey' | 'local';

export interface Provenance {
  adapterId: string;
  adapterVersion: string;
  firstObservedAt: string;
  lastObservedAt: string;
  /** Page records on which this record was observed. */
  sourcePageIds: string[];
  observations: number;
  userEdited: boolean;
}

export interface EntityRecord {
  id: string;
  type: EntityType;
  kind: string;
  site: string;
  identity: { strategy: IdentityStrategy; value: string };
  sourceId?: string;
  sourceUrl?: string;
  title?: string;
  /** Pages only: last observed URL (normalized). */
  url?: string;
  /** Pages only. */
  canonicalUrl?: string;
  mimeType?: string;
  width?: number;
  height?: number;
  duration?: number;
  metadata: JsonObject;
  provenance: Provenance;
}

export interface RelationshipRecord {
  id: string;
  fromId: string;
  type: string;
  toId: string;
  /** Last time this relationship was observed. */
  observedAt: string;
  firstObservedAt: string;
  /** Page on which it was last observed. */
  sourcePageId: string;
  sourcePageIds: string[];
  site: string;
  adapterId: string;
  adapterVersion: string;
}

export type MediaDelivery = 'direct' | 'segmented' | 'unresolved' | 'unsupported';

export interface MediaRecord {
  id: string;
  url: string;
  kind: MediaKind;
  mimeType?: string;
  filename: string;
  label?: string;
  width?: number;
  height?: number;
  delivery: MediaDelivery;
  deliveryReason: string;
  assetId?: string;
  site: string;
  provenance: Provenance;
}

export interface DownloadState {
  state: 'requested' | 'complete' | 'interrupted';
  downloadId?: number;
  url: string;
  filename: string;
  requestedAt: string;
  completedAt?: string;
  error?: string;
}

/**
 * Local-only workspace state, keyed by entity or media record id. Kept in its
 * own store so re-extraction never overwrites it.
 */
export interface LocalState {
  id: string;
  updatedAt: string;
  download?: DownloadState;
}

export interface NormalizedExtraction {
  pageId: string;
  site: string;
  observedAt: string;
  adapter: { id: string; version: string };
  entities: EntityRecord[];
  relationships: RelationshipRecord[];
  media: MediaRecord[];
  diagnostics: Diagnostic[];
}

/** A slice of the workspace around one page. */
export interface WorkspaceGraph {
  entities: EntityRecord[];
  relationships: RelationshipRecord[];
  media: MediaRecord[];
  localState: LocalState[];
}
