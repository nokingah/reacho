import type { JsonObject, JsonValue } from './types';

/**
 * Return a JSON-safe copy of `value`, dropping anything JSON cannot represent
 * (functions, DOM nodes, non-finite numbers, cycles). `dropped` counts what was
 * removed so callers can report it.
 */
export function toJsonValue(value: unknown, dropped = { count: 0 }, seen = new WeakSet<object>()): JsonValue | undefined {
  if (value === null) return null;
  switch (typeof value) {
    case 'string':
    case 'boolean':
      return value;
    case 'number':
      if (Number.isFinite(value)) return value;
      dropped.count++;
      return undefined;
    case 'object': {
      if (seen.has(value)) {
        dropped.count++;
        return undefined;
      }
      seen.add(value);
      if (Array.isArray(value)) {
        const out: JsonValue[] = [];
        for (const item of value) {
          const v = toJsonValue(item, dropped, seen);
          if (v !== undefined) out.push(v);
        }
        seen.delete(value);
        return out;
      }
      const proto = Object.getPrototypeOf(value);
      if (proto !== Object.prototype && proto !== null) {
        dropped.count++;
        seen.delete(value);
        return undefined;
      }
      const out: JsonObject = {};
      for (const [k, item] of Object.entries(value)) {
        const v = toJsonValue(item, dropped, seen);
        if (v !== undefined) out[k] = v;
      }
      seen.delete(value);
      return out;
    }
    default:
      dropped.count++;
      return undefined;
  }
}

export function isPlainObject(value: unknown): value is Record<string, unknown> {
  if (typeof value !== 'object' || value === null || Array.isArray(value)) return false;
  const proto = Object.getPrototypeOf(value);
  return proto === Object.prototype || proto === null;
}
