/** Injected by scripts/build.mjs from package.json. */
declare const __REACHO_VERSION__: string;
