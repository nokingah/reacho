// URL helpers shared by core identity logic and the side panel.

const TRACKING_PARAMS = new Set(['fbclid', 'gclid', 'dclid', 'msclkid', 'mc_cid', 'mc_eid', 'igshid', 'yclid']);

function isTrackingParam(name: string): boolean {
  const lower = name.toLowerCase();
  return lower.startsWith('utm_') || TRACKING_PARAMS.has(lower);
}

/**
 * Normalize an http(s) URL for use as identity: drops the fragment and
 * well-known tracking parameters and sorts the remaining query parameters.
 * Scheme/host case and default ports are already normalized by `URL`.
 * Returns null for anything that is not an absolute http(s) URL.
 */
export function normalizeUrl(input: string, base?: string): string | null {
  let url: URL;
  try {
    url = new URL(input, base);
  } catch {
    return null;
  }
  if (url.protocol !== 'http:' && url.protocol !== 'https:') return null;
  url.hash = '';
  const params = [...url.searchParams].filter(([name]) => !isTrackingParam(name));
  params.sort(([a], [b]) => (a < b ? -1 : a > b ? 1 : 0));
  url.search = new URLSearchParams(params).toString();
  return url.href;
}

export function hostnameOf(input: string): string {
  try {
    return new URL(input).hostname;
  } catch {
    return '';
  }
}

const EXTENSION_STORES = ['chromewebstore.google.com', 'chrome.google.com', 'microsoftedge.microsoft.com', 'addons.mozilla.org'];

/**
 * Pages Reacho never touches regardless of adapter matching: browser internals,
 * extension stores, and non-web schemes. Adapters additionally only match
 * explicit sites (see docs/privacy-security.md).
 */
export function restrictedReason(input: string | undefined): string | null {
  if (!input) return 'No access to this tab yet.';
  let url: URL;
  try {
    url = new URL(input);
  } catch {
    return 'Unrecognized URL.';
  }
  if (url.protocol !== 'http:' && url.protocol !== 'https:') {
    return `Reacho does not run on ${url.protocol} pages.`;
  }
  if (EXTENSION_STORES.includes(url.hostname) && (url.hostname !== 'chrome.google.com' || url.pathname.startsWith('/webstore'))) {
    return 'Reacho does not run on extension stores.';
  }
  return null;
}

/**
 * The host match patterns (`scheme://host/*`, optionally `*.host`) that cover
 * `url`. Used to request or revoke persistent access for the current site only.
 */
export function patternsForUrl(patterns: readonly string[], input: string | undefined): string[] {
  if (!input) return [];
  let url: URL;
  try {
    url = new URL(input);
  } catch {
    return [];
  }
  return patterns.filter((pattern) => {
    const m = pattern.match(/^(https?|\*):\/\/([^/]+)\//);
    if (!m) return false;
    const [, scheme, host] = m;
    if (scheme !== '*' && `${scheme}:` !== url.protocol) return false;
    if (host === '*') return true;
    if (host!.startsWith('*.')) return url.hostname === host!.slice(2) || url.hostname.endsWith(host!.slice(1));
    return url.hostname === host;
  });
}
