// Background service worker. Its only job is to turn the toolbar click (or
// keyboard shortcut) into "open the side panel": that user action is also what
// grants Reacho temporary activeTab access to the current tab. No data is
// processed here.

export type AccessMessage = { type: 'reacho:tab-access'; tabId: number; windowId: number };

chrome.action.onClicked.addListener((tab) => {
  if (tab.id === undefined) return;
  // sidePanel.open must be called synchronously inside the user gesture.
  if (chrome.sidePanel?.open) {
    chrome.sidePanel.open({ windowId: tab.windowId }).catch((err) => console.warn('Reacho: could not open side panel', err));
  } else {
    // Fallback for browsers without the sidePanel API: open the same UI in a tab bound to this tab.
    void chrome.tabs.create({ url: chrome.runtime.getURL(`sidepanel.html?tabId=${tab.id}`) });
  }
  const message: AccessMessage = { type: 'reacho:tab-access', tabId: tab.id, windowId: tab.windowId };
  chrome.runtime.sendMessage(message).catch(() => {
    // Panel not open yet; it reads the active tab when it loads.
  });
});
