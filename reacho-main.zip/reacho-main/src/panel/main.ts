// Reacho side panel: the primary UI. Shows the matched adapter, access state,
// stored records for the current page, relationships, media, the raw
// inspector, and diagnostics. All persistence is local (IndexedDB).

import { ADAPTERS, findAdapterForUrl } from '../adapters/registry';
import { buildExport, exportFilename, type ExportScope } from '../core/export';
import { pageIdForUrl } from '../core/identity';
import { safePathSegment } from '../core/media';
import { normalizeExtraction } from '../core/normalize';
import { Workspace, type CommitSummary, type WorkspaceStats } from '../core/workspace';
import type {
  Diagnostic,
  DownloadState,
  EntityRecord,
  JsonValue,
  LocalState,
  MediaRecord,
  NormalizedExtraction,
  RawExtraction,
  RelationshipRecord,
  SiteAdapter,
  WorkspaceGraph,
} from '../shared/types';
import { normalizeUrl, patternsForUrl, restrictedReason } from '../shared/url';
import * as browser from './browser';
import type { TabInfo } from './browser';
import { h } from './dom';

type View = 'records' | 'relationships' | 'media' | 'inspector' | 'diagnostics';
type InspectTarget = 'record' | 'graph' | 'normalized' | 'raw' | 'structured';

interface RunState {
  mode: 'extract' | 'test';
  at: string;
  raw?: RawExtraction;
  normalized?: NormalizedExtraction;
  commit?: CommitSummary;
  /** Injection/bridge failure (no adapter output at all). */
  error?: string;
}

const state = {
  tab: undefined as TabInfo | undefined,
  adapter: undefined as SiteAdapter | undefined,
  restricted: null as string | null,
  persistent: false,
  pageId: undefined as string | undefined,
  graph: undefined as WorkspaceGraph | undefined,
  stats: undefined as WorkspaceStats | undefined,
  run: undefined as RunState | undefined,
  view: 'records' as View,
  inspect: 'graph' as InspectTarget,
  selectedId: undefined as string | undefined,
  busy: false,
  notice: undefined as { level: 'info' | 'error'; text: string } | undefined,
  confirm: undefined as string | undefined,
};

const app = document.getElementById('app')!;
let workspace: Workspace;

// ---------------------------------------------------------------------------
// State loading
// ---------------------------------------------------------------------------

async function refresh() {
  const tab = await browser.getTargetTab();
  const urlChanged = tab?.id !== state.tab?.id || tab?.url !== state.tab?.url;
  state.tab = tab;
  state.restricted = restrictedReason(tab?.url);
  state.adapter = state.restricted ? undefined : findAdapterForUrl(tab?.url);
  state.persistent = await browser.hasOrigins(siteOrigins());
  if (urlChanged) {
    if (state.run?.raw?.page.url !== tab?.url) state.run = undefined;
    state.selectedId = undefined;
    state.notice = undefined;
  }
  await loadGraph();
  render();
}

async function loadGraph() {
  const url = state.tab?.url;
  state.stats = await workspace.stats();
  if (!url || state.restricted) {
    state.pageId = undefined;
    state.graph = undefined;
    return;
  }
  const page = await workspace.findPage(pageIdForUrl(url), normalizeUrl(url));
  state.pageId = page?.id ?? state.run?.normalized?.pageId ?? pageIdForUrl(url) ?? undefined;
  state.graph = page ? await workspace.pageGraph(page.id) : undefined;
}

let refreshTimer: ReturnType<typeof setTimeout> | undefined;
function scheduleRefresh() {
  clearTimeout(refreshTimer);
  refreshTimer = setTimeout(() => void refresh().catch(showError), 120);
}

// ---------------------------------------------------------------------------
// Actions
// ---------------------------------------------------------------------------

async function extract(mode: RunState['mode']) {
  const { adapter, tab } = state;
  if (!adapter || !tab) return;
  state.busy = true;
  state.notice = undefined;
  render();
  const at = new Date().toISOString();
  try {
    const raw = await browser.runBridge(tab.id, adapter.id);
    const normalized = normalizeExtraction(raw, { site: adapter.site });
    let commit: CommitSummary | undefined;
    if (mode === 'extract') {
      try {
        commit = await workspace.commit(normalized);
      } catch (err) {
        normalized.diagnostics.push({ level: 'error', code: 'persist-failed', message: errorText(err), phase: 'persist' });
      }
    }
    state.run = { mode, at, raw, normalized, commit };
    const errors = normalized.diagnostics.filter((d) => d.level === 'error').length;
    const warnings = normalized.diagnostics.filter((d) => d.level === 'warning').length;
    const counts = `${normalized.entities.length} entities, ${normalized.relationships.length} relationships, ${normalized.media.length} media`;
    let text: string;
    if (mode === 'test') {
      text = `Dry run: ${counts}. Nothing was saved.`;
    } else if (commit) {
      const known = commit.previouslyKnown.length;
      text = `Saved ${counts}. ${commit.entitiesCreated} new entities; ${known} records were already in the workspace and have been linked/updated.`;
    } else {
      text = 'Extraction finished, but nothing could be saved. See Diagnostics.';
    }
    if (errors || warnings) text += ` ${errors} error(s), ${warnings} warning(s). See Diagnostics.`;
    state.notice = { level: errors ? 'error' : 'info', text };
    if (errors && normalized.entities.length <= 1) state.view = 'diagnostics';
  } catch (err) {
    state.run = { mode, at, error: browser.describeAccessError(err) };
    state.notice = { level: 'error', text: `Extraction failed: ${state.run.error}` };
    state.view = 'diagnostics';
  } finally {
    state.busy = false;
  }
  await loadGraph();
  render();
}

async function save(media: MediaRecord) {
  if (media.delivery !== 'direct' || isDryRun()) return;
  const now = new Date().toISOString();
  const filename = `Reacho/${safeSegment(media.site)}/${media.filename}`;
  const ids = [media.id, ...(media.assetId ? [media.assetId] : [])];
  try {
    const downloadId = await chrome.downloads.download({ url: media.url, filename, conflictAction: 'uniquify', saveAs: false });
    await workspace.setDownload(ids, { state: 'requested', downloadId, url: media.url, filename, requestedAt: now }, now);
    state.notice = { level: 'info', text: `Download started: ${filename}` };
    // Small files can finish before the id above was stored, so onChanged found nothing to update.
    const [item] = await chrome.downloads.search({ id: downloadId });
    if (item && item.state !== 'in_progress') await recordDownloadResult(downloadId, item.state, item.error);
  } catch (err) {
    await workspace.setDownload(ids, { state: 'interrupted', url: media.url, filename, requestedAt: now, error: errorText(err) }, now);
    state.notice = { level: 'error', text: `Download failed: ${errorText(err)}` };
  }
  await loadGraph();
  render();
}

async function onDownloadChanged(delta: chrome.downloads.DownloadDelta) {
  const next = delta.state?.current;
  if (next !== 'complete' && next !== 'interrupted') return;
  if (await recordDownloadResult(delta.id, next, delta.error?.current)) {
    await loadGraph();
    render();
  }
}

async function recordDownloadResult(downloadId: number, result: string, error?: string): Promise<boolean> {
  const records = await workspace.findByDownloadId(downloadId);
  const now = new Date().toISOString();
  for (const record of records) {
    if (record.download!.state !== 'requested') continue;
    const download: DownloadState = { ...record.download!, state: result === 'complete' ? 'complete' : 'interrupted', completedAt: now };
    if (error) download.error = error;
    await workspace.setDownload([record.id], download, now);
  }
  const filename = records[0]?.download?.filename;
  if (filename) {
    state.notice = result === 'complete'
      ? { level: 'info', text: `Saved to Downloads/${filename}` }
      : { level: 'error', text: `Download interrupted (${error ?? 'unknown error'}): ${filename}` };
  }
  return records.length > 0;
}

async function exportJson(kind: ExportScope['kind']) {
  let graph: WorkspaceGraph;
  let scope: ExportScope;
  if (kind === 'page') {
    if (!state.pageId) return;
    graph = await workspace.pageGraph(state.pageId);
    scope = { kind: 'page', pageId: state.pageId, url: state.tab?.url };
  } else if (kind === 'site') {
    const site = state.adapter?.site ?? new URL(state.tab!.url!).hostname;
    graph = await workspace.siteGraph(site);
    scope = { kind: 'site', site };
  } else {
    graph = await workspace.all();
    scope = { kind: 'workspace' };
  }
  const now = new Date().toISOString();
  const data = buildExport(graph, scope, now, chrome.runtime.getManifest().version);
  const url = URL.createObjectURL(new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' }));
  const filename = `Reacho/exports/${exportFilename(scope, now)}`;
  try {
    await chrome.downloads.download({ url, filename, saveAs: false, conflictAction: 'uniquify' });
    state.notice = { level: 'info', text: `Exported ${data.counts.entities} entities, ${data.counts.relationships} relationships to Downloads/${filename}` };
  } catch (err) {
    state.notice = { level: 'error', text: `Export failed: ${errorText(err)}` };
  }
  setTimeout(() => URL.revokeObjectURL(url), 60_000);
  render();
}

/** The adapter's optional host patterns that cover the current tab only. */
function siteOrigins(): string[] {
  return state.adapter ? patternsForUrl(state.adapter.hostPermissions, state.tab?.url) : [];
}

function togglePersistent() {
  const origins = siteOrigins();
  if (!origins.length) return;
  // Called directly from the click handler so the permission prompt keeps the user gesture.
  const action = state.persistent ? chrome.permissions.remove({ origins }) : chrome.permissions.request({ origins });
  action.then(() => refresh()).catch(showError);
}

/** Destructive actions use an inline two-step confirmation. */
function confirmThen(key: string, action: () => Promise<void>) {
  if (state.confirm !== key) {
    state.confirm = key;
    render();
    setTimeout(() => {
      if (state.confirm === key) {
        state.confirm = undefined;
        render();
      }
    }, 4000);
    return;
  }
  state.confirm = undefined;
  action().then(loadGraph).then(render).catch(showError);
}

async function clearSite() {
  const site = state.adapter?.site ?? (state.tab?.url ? new URL(state.tab.url).hostname : '');
  if (!site) return;
  const removed = await workspace.clearSite(site);
  state.run = undefined;
  state.notice = { level: 'info', text: `Removed ${removed} records for ${site}.` };
}

async function clearAll() {
  await workspace.clearAll();
  state.run = undefined;
  state.notice = { level: 'info', text: 'Workspace cleared.' };
}

// ---------------------------------------------------------------------------
// Rendering
// ---------------------------------------------------------------------------

/** The data shown in the record views: a dry run's output, else the stored page graph. */
function currentGraph(): WorkspaceGraph | undefined {
  if (state.run?.mode === 'test' && state.run.normalized) {
    const n = state.run.normalized;
    return { entities: n.entities, relationships: n.relationships, media: n.media, localState: [] };
  }
  return state.graph;
}

function isDryRun(): boolean {
  return state.run?.mode === 'test' && Boolean(state.run.normalized);
}

function currentDiagnostics(): Diagnostic[] {
  return state.run?.normalized?.diagnostics ?? state.run?.raw?.diagnostics ?? [];
}

function render() {
  const scrollTop = document.querySelector('.view')?.scrollTop ?? 0;
  const parts = [
    renderHeader(),
    renderPageCard(),
    renderActions(),
    state.notice ? h('div', { className: `notice ${state.notice.level}`, role: 'status', 'data-testid': 'notice' }, state.notice.text) : null,
    renderTabs(),
    h('section', { className: 'view' }, renderView()),
    renderFooter(),
  ];
  app.replaceChildren(...parts.filter((p): p is HTMLElement => p !== null));
  const view = document.querySelector('.view');
  if (view) view.scrollTop = scrollTop;
}

function renderHeader() {
  return h('header', { className: 'header' }, h('h1', null, 'Reacho'), h('span', { className: 'pill ok', title: 'Extracted data stays in this browser profile.' }, 'local only'));
}

function renderPageCard() {
  const { tab, adapter, restricted } = state;
  let adapterLine: Node;
  if (restricted) adapterLine = h('span', { className: 'muted' }, restricted);
  else if (adapter) {
    adapterLine = h('span', null, h('strong', null, adapter.name), ' ', h('code', null, `${adapter.id}@${adapter.version}`), adapter.demo ? h('span', { className: 'pill' }, 'demo fixture') : null);
  } else adapterLine = h('span', { className: 'muted' }, 'No built-in adapter matches this page. Reacho only extracts from supported sites.');

  let access: Node;
  if (!tab?.url) {
    access = h('span', { className: 'warn' }, 'None — click the Reacho toolbar button to grant one-time access to this tab.');
  } else if (state.persistent) {
    access = h('span', null, 'Persistent (opted in) for ', h('code', null, siteOrigins().join(', ')));
  } else {
    access = h('span', null, 'Temporary ', h('code', null, 'activeTab'), ' grant for this tab');
  }

  return h(
    'section',
    { className: 'card' },
    h('div', { className: 'page-title', title: tab?.title ?? '' }, tab?.title ?? 'No tab'),
    tab?.url ? h('div', { className: 'page-url', title: tab.url }, tab.url) : null,
    h('dl', { className: 'facts' },
      h('dt', null, 'Adapter'), h('dd', { 'data-testid': 'adapter' }, adapterLine),
      h('dt', null, 'Access'), h('dd', { 'data-testid': 'access' }, access,
        adapter && tab?.url && siteOrigins().length
          ? h('button', { className: 'link', onclick: togglePersistent, title: 'Optional, per-site, removable.' }, state.persistent ? 'Revoke persistent access' : 'Allow on this site')
          : null),
      state.graph ? h('dt', null, 'Stored') : null,
      state.graph ? h('dd', null, storedSummary()) : null,
    ),
  );
}

function storedSummary(): string {
  const page = state.graph?.entities.find((e) => e.id === state.pageId);
  if (!page) return '';
  const p = page.provenance;
  return `Page extracted ${p.observations}× · last ${formatTime(p.lastObservedAt)} · ${state.graph!.entities.length} linked records`;
}

function renderActions() {
  const canRun = Boolean(state.adapter && state.tab?.url && !state.restricted && !state.busy);
  const hasPage = Boolean(state.graph);
  const button = (label: string, onclick: () => void, opts: { disabled?: boolean; primary?: boolean; title?: string; testid?: string } = {}) =>
    h('button', { className: opts.primary ? 'primary' : '', disabled: opts.disabled, title: opts.title, onclick, 'data-testid': opts.testid }, label);
  return h(
    'section',
    { className: 'actions' },
    h('div', { className: 'row' },
      button(state.busy ? 'Extracting…' : 'Extract', () => void extract('extract'), { disabled: !canRun, primary: true, title: 'Run the adapter on this page and save the results locally.', testid: 'extract' }),
      button('Test', () => void extract('test'), { disabled: !canRun, title: 'Dry run: run the adapter and show results without saving.', testid: 'test' }),
    ),
    h('div', { className: 'row' },
      h('span', { className: 'label' }, 'Export JSON'),
      button('Page', () => void exportJson('page').catch(showError), { disabled: !hasPage, title: 'This page’s records plus records linked to them.', testid: 'export-page' }),
      button('Site', () => void exportJson('site').catch(showError), { disabled: !state.adapter, testid: 'export-site' }),
      button('All', () => void exportJson('workspace').catch(showError), { disabled: !state.stats?.entities, testid: 'export-all' }),
    ),
    h('div', { className: 'row' },
      h('span', { className: 'label' }, 'Clear'),
      button(state.confirm === 'site' ? 'Confirm: clear site' : 'Site data', () => confirmThen('site', clearSite), { disabled: !state.adapter }),
      button(state.confirm === 'all' ? 'Confirm: clear everything' : 'Workspace', () => confirmThen('all', clearAll), { disabled: !state.stats?.entities }),
    ),
  );
}

function renderTabs() {
  const graph = currentGraph();
  const diags = currentDiagnostics();
  const problems = diags.filter((d) => d.level !== 'info').length + (state.run?.error ? 1 : 0);
  const tabs: [View, string][] = [
    ['records', `Records${graph ? ` (${graph.entities.length})` : ''}`],
    ['relationships', `Links${graph ? ` (${graph.relationships.length})` : ''}`],
    ['media', `Media${graph ? ` (${graph.media.length})` : ''}`],
    ['inspector', 'Inspector'],
    ['diagnostics', `Diagnostics${problems ? ` (${problems})` : ''}`],
  ];
  return h(
    'nav',
    { className: 'tabs', role: 'tablist' },
    tabs.map(([view, label]) =>
      h('button', {
        role: 'tab',
        className: `${state.view === view ? 'active' : ''} ${view === 'diagnostics' && problems ? 'has-problems' : ''}`,
        'aria-selected': String(state.view === view),
        'data-testid': `tab-${view}`,
        onclick: () => {
          state.view = view;
          render();
        },
      }, label),
    ),
  );
}

function renderView(): Node | Node[] {
  const banner = state.run?.mode === 'test' && state.run.normalized ? h('div', { className: 'notice info' }, 'Showing dry-run output (not saved). Use Extract to save.') : null;
  switch (state.view) {
    case 'records':
      return [banner, renderRecords()].filter(Boolean) as Node[];
    case 'relationships':
      return [banner, renderRelationships()].filter(Boolean) as Node[];
    case 'media':
      return [banner, renderMedia()].filter(Boolean) as Node[];
    case 'inspector':
      return renderInspector();
    case 'diagnostics':
      return renderDiagnostics();
  }
}

function empty(text: string) {
  return h('p', { className: 'empty' }, text);
}

const TYPE_ORDER = ['page', 'person', 'collection', 'asset'];
const TYPE_LABEL: Record<string, string> = { page: 'Pages', person: 'People', collection: 'Collections', asset: 'Assets' };

function renderRecords(): Node {
  const graph = currentGraph();
  if (!graph) return empty(state.adapter ? 'Nothing stored for this page yet. Press Extract.' : 'No records for this page.');
  const groups = TYPE_ORDER.map((type) => [type, graph.entities.filter((e) => e.type === type)] as const).filter(([, list]) => list.length);
  return h(
    'div',
    { 'data-testid': 'records' },
    groups.map(([type, list]) =>
      h('div', { className: 'group' }, h('h2', null, `${TYPE_LABEL[type]} (${list.length})`), h('ul', { className: 'list' }, sortEntities(list).map(renderEntity))),
    ),
  );
}

function sortEntities(list: EntityRecord[]) {
  return [...list].sort((a, b) => (a.title ?? a.id).localeCompare(b.title ?? b.id));
}

function renderEntity(entity: EntityRecord) {
  const p = entity.provenance;
  const fromEarlier = state.pageId !== undefined && !p.sourcePageIds.includes(state.pageId);
  const pages = p.sourcePageIds.length;
  const download = localStateFor(entity.id)?.download;
  return h(
    'li',
    { className: `item ${state.selectedId === entity.id ? 'selected' : ''}`, onclick: () => select(entity.id), title: entity.id },
    h('div', { className: 'item-main' }, h('span', { className: 'kind' }, entity.kind), ' ', entity.title ?? entity.sourceId ?? entity.id),
    h('div', { className: 'item-meta' },
      entity.width && entity.height ? h('span', null, `${entity.width}×${entity.height}`) : null,
      entity.mimeType ? h('span', null, entity.mimeType) : null,
      h('span', { title: `identity: ${entity.identity.strategy}` }, entity.identity.strategy === 'local' ? 'local id' : `id: ${entity.identity.strategy}`),
      fromEarlier ? h('span', { className: 'pill link-pill', title: 'Captured on another page and linked to this one.' }, 'from earlier page') : null,
      pages > 1 ? h('span', { className: 'pill', title: 'Observed on multiple pages; records were merged.' }, `seen on ${pages} pages`) : null,
      download ? h('span', { className: `pill dl-${download.state}` }, `download ${download.state}`) : null,
    ),
  );
}

function renderRelationships(): Node {
  const graph = currentGraph();
  if (!graph?.relationships.length) return empty('No relationships yet.');
  const byId = new Map(graph.entities.map((e) => [e.id, e]));
  const sorted = [...graph.relationships].sort((a, b) => a.type.localeCompare(b.type) || label(byId, a.fromId).localeCompare(label(byId, b.fromId)));
  const here = sorted.filter((r) => state.pageId === undefined || r.sourcePageIds.includes(state.pageId));
  const earlier = sorted.filter((r) => !here.includes(r));
  return h(
    'div',
    { 'data-testid': 'relationships' },
    h('h2', null, `Observed on this page (${here.length})`),
    here.length ? h('ul', { className: 'list' }, here.map((rel) => renderRelationship(rel, byId))) : empty('None.'),
    earlier.length ? h('h2', null, `Linked from earlier pages (${earlier.length})`) : null,
    earlier.length ? h('ul', { className: 'list' }, earlier.map((rel) => renderRelationship(rel, byId))) : null,
  );
}

function renderRelationship(rel: RelationshipRecord, byId: Map<string, EntityRecord>) {
  const earlier = state.pageId !== undefined && !rel.sourcePageIds.includes(state.pageId);
  const endpoint = (id: string) =>
    h('button', { className: 'link', onclick: () => select(id), title: id }, h('span', { className: 'kind' }, byId.get(id)?.kind ?? '?'), ' ', label(byId, id));
  return h(
    'li',
    { className: 'item rel', title: `first ${formatTime(rel.firstObservedAt)} · last ${formatTime(rel.observedAt)}` },
    h('div', { className: 'item-main' }, endpoint(rel.fromId), h('span', { className: 'rel-type' }, ` —${rel.type}→ `), endpoint(rel.toId)),
    earlier ? h('div', { className: 'item-meta' }, h('span', { className: 'pill link-pill' }, 'recorded on an earlier page')) : null,
  );
}

function label(byId: Map<string, EntityRecord>, id: string): string {
  const e = byId.get(id);
  return e?.title ?? e?.sourceId ?? id;
}

function renderMedia(): Node {
  const graph = currentGraph();
  if (!graph?.media.length) return empty('No media discovered on this page.');
  const order = { direct: 0, segmented: 1, unresolved: 2, unsupported: 3 } as const;
  const sorted = [...graph.media].sort((a, b) => order[a.delivery] - order[b.delivery] || a.filename.localeCompare(b.filename));
  return h('ul', { className: 'list', 'data-testid': 'media' }, sorted.map(renderMediaItem));
}

function renderMediaItem(media: MediaRecord) {
  const download = localStateFor(media.id)?.download;
  return h(
    'li',
    { className: 'item media' },
    h('div', { className: 'item-main' }, h('span', { className: 'kind' }, media.kind), ' ', media.label ?? media.filename),
    h('div', { className: 'item-meta' },
      h('span', { className: `pill delivery-${media.delivery}`, title: media.deliveryReason }, media.delivery),
      media.width && media.height ? h('span', null, `${media.width}×${media.height}`) : null,
      media.mimeType ? h('span', null, media.mimeType) : null,
      download ? h('span', { className: `pill dl-${download.state}`, title: download.error ?? download.filename }, `download ${download.state}`) : null,
    ),
    h('div', { className: 'item-reason' }, media.deliveryReason),
    h('div', { className: 'item-url', title: media.url }, media.url),
    media.delivery === 'direct' && isDryRun()
      ? h('div', { className: 'item-reason' }, 'Dry run: press Extract to save this record before downloading it.')
      : null,
    media.delivery === 'direct' && !isDryRun()
      ? h('button', { onclick: () => void save(media).catch(showError), 'data-testid': 'save-media', title: `Save to Downloads/Reacho/${media.site}/` }, download?.state === 'complete' ? 'Save again' : 'Save')
      : null,
  );
}

function renderInspector(): Node[] {
  const options: [InspectTarget, string][] = [
    ['record', 'Selected record'],
    ['graph', 'Stored records for this page (normalized)'],
    ['normalized', 'Last run: normalized output'],
    ['raw', 'Last run: raw adapter output'],
    ['structured', 'Page structured data (JSON-LD / meta)'],
  ];
  let value: unknown;
  switch (state.inspect) {
    case 'record': {
      const graph = currentGraph();
      const record = graph?.entities.find((e) => e.id === state.selectedId) ?? graph?.media.find((m) => m.id === state.selectedId);
      value = record ? { record, localState: localStateFor(record.id) ?? null } : 'Select a record in Records or Links.';
      break;
    }
    case 'graph':
      value = state.graph ?? 'Nothing stored for this page.';
      break;
    case 'normalized':
      value = state.run?.normalized ?? 'No extraction in this session yet.';
      break;
    case 'raw':
      value = state.run?.raw ? { ...state.run.raw, structuredData: '(see "Page structured data")' } : 'No extraction in this session yet.';
      break;
    case 'structured':
      value = state.run?.raw?.structuredData ?? 'Run Extract or Test to read the page’s structured data.';
      break;
  }
  const json = typeof value === 'string' ? value : JSON.stringify(value as JsonValue, null, 2);
  return [
    h('div', { className: 'row' },
      h('select', {
        'data-testid': 'inspect-target',
        onchange: (e: Event) => {
          state.inspect = (e.target as HTMLSelectElement).value as InspectTarget;
          render();
        },
      }, options.map(([v, text]) => h('option', { value: v, selected: state.inspect === v }, text))),
      h('button', { onclick: () => void navigator.clipboard.writeText(json).then(() => flash('Copied JSON.')).catch(showError) }, 'Copy'),
    ),
    h('pre', { className: 'json', 'data-testid': 'inspector-json' }, json),
  ];
}

function renderDiagnostics(): Node[] {
  const out: Node[] = [];
  const url = state.tab?.url;
  out.push(
    h('h2', null, 'Adapter matching'),
    h('ul', { className: 'list compact', 'data-testid': 'adapter-matches' },
      ADAPTERS.map((a) => {
        let matched = false;
        try {
          matched = Boolean(url && !state.restricted && a.matches(new URL(url)));
        } catch {
          matched = false;
        }
        return h('li', { className: 'item' }, h('span', { className: `pill ${matched ? 'ok' : ''}` }, matched ? 'match' : 'no match'), ' ', h('code', null, `${a.id}@${a.version}`), ' ', a.name);
      }),
    ),
  );
  if (!url) out.push(empty('Reacho cannot read this tab’s URL yet, so adapters cannot be matched. Click the toolbar button.'));

  const run = state.run;
  if (!run) {
    out.push(empty('No extraction has run in this panel session.'));
    return out;
  }
  out.push(h('h2', null, `Last run: ${run.mode === 'test' ? 'Test (dry run)' : 'Extract'} at ${formatTime(run.at)}`));
  if (run.error) out.push(h('div', { className: 'notice error', 'data-testid': 'run-error' }, run.error));
  if (run.raw) {
    out.push(
      h('table', { className: 'timings' },
        h('thead', null, h('tr', null, h('th', null, 'Phase'), h('th', null, 'Result'), h('th', null, 'Items'), h('th', null, 'ms'))),
        h('tbody', null, run.raw.timings.map((t) => h('tr', { className: t.ok ? '' : 'failed' }, h('td', null, t.phase), h('td', null, t.ok ? 'ok' : 'failed'), h('td', null, t.count ?? '—'), h('td', null, t.ms)))),
      ),
    );
    if (run.raw.discoveries.length) {
      out.push(h('h2', null, 'Discovered'), h('ul', { className: 'list compact' }, run.raw.discoveries.map((d) => h('li', { className: 'item' }, d.label, d.count !== undefined ? `: ${d.count}` : ''))));
    }
    if (run.commit) {
      const c = run.commit;
      out.push(h('p', { className: 'muted' }, `Persisted: ${c.entitiesCreated} entities created, ${c.entitiesUpdated} updated; ${c.relationshipsCreated} relationships created, ${c.relationshipsUpdated} updated; ${c.mediaCreated + c.mediaUpdated} media.`));
    }
  }
  const diags = currentDiagnostics();
  out.push(h('h2', null, `Messages (${diags.length})`));
  out.push(
    diags.length
      ? h('ul', { className: 'list compact', 'data-testid': 'diagnostics' }, diags.map((d) => h('li', { className: `item diag ${d.level}` }, h('span', { className: `pill ${d.level}` }, d.level), ' ', h('code', null, d.phase ? `${d.phase}/${d.code}` : d.code), ' ', d.message)))
      : empty('No problems reported.'),
  );
  return out;
}

function renderFooter() {
  const s = state.stats;
  return h(
    'footer',
    { className: 'footer' },
    s ? `Workspace: ${s.entities} entities · ${s.relationships} links · ${s.media} media · IndexedDB schema v${s.schemaVersion}. ` : '',
    'Stored only in this browser profile; Reacho sends no page data anywhere.',
  );
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function localStateFor(id: string): LocalState | undefined {
  return state.graph?.localState.find((s) => s.id === id);
}

function select(id: string) {
  state.selectedId = id;
  state.inspect = 'record';
  state.view = 'inspector';
  render();
}

function flash(text: string) {
  state.notice = { level: 'info', text };
  render();
}

function showError(err: unknown) {
  console.error(err);
  state.busy = false;
  state.notice = { level: 'error', text: errorText(err) };
  render();
}

function errorText(err: unknown): string {
  return err instanceof Error ? err.message : String(err);
}

function formatTime(iso: string): string {
  const d = new Date(iso);
  return Number.isNaN(d.getTime()) ? iso : d.toLocaleString();
}

function safeSegment(value: string): string {
  return safePathSegment(value) || 'site';
}

// ---------------------------------------------------------------------------
// Boot
// ---------------------------------------------------------------------------

async function boot() {
  workspace = await Workspace.open();
  chrome.tabs.onActivated.addListener(async (info) => {
    if (browser.boundTabId === undefined && info.windowId === (await browser.panelWindow())) scheduleRefresh();
  });
  chrome.tabs.onUpdated.addListener((tabId, change) => {
    if (tabId === state.tab?.id && (change.url !== undefined || change.status === 'complete' || change.title !== undefined)) scheduleRefresh();
  });
  chrome.runtime.onMessage.addListener((message: { type?: string }) => {
    if (message?.type === 'reacho:tab-access') scheduleRefresh();
  });
  chrome.permissions.onAdded.addListener(scheduleRefresh);
  chrome.permissions.onRemoved.addListener(scheduleRefresh);
  chrome.downloads.onChanged.addListener((delta) => void onDownloadChanged(delta).catch(showError));
  window.addEventListener('focus', scheduleRefresh);
  await refresh();
}

boot().catch((err) => {
  app.replaceChildren(h('div', { className: 'notice error' }, `Reacho failed to start: ${errorText(err)}`));
});
