// Thin wrappers around the extension APIs the side panel uses.

import type { RawExtraction } from '../shared/types';

export interface TabInfo {
  id: number;
  windowId: number;
  /** Only present when Reacho has activeTab or host access to this tab. */
  url?: string;
  title?: string;
}

/** `?tabId=` binds the UI to one tab (fallback mode and automated tests). */
export const boundTabId = (() => {
  const raw = new URLSearchParams(location.search).get('tabId');
  return raw ? Number(raw) : undefined;
})();

let panelWindowId: number | undefined;

export async function panelWindow(): Promise<number | undefined> {
  if (panelWindowId === undefined) panelWindowId = (await chrome.windows.getCurrent()).id;
  return panelWindowId;
}

export async function getTargetTab(): Promise<TabInfo | undefined> {
  let tab: chrome.tabs.Tab | undefined;
  if (boundTabId !== undefined) {
    tab = await chrome.tabs.get(boundTabId).catch(() => undefined);
  } else {
    const windowId = await panelWindow();
    [tab] = await chrome.tabs.query({ active: true, windowId });
  }
  if (!tab || tab.id === undefined) return undefined;
  return { id: tab.id, windowId: tab.windowId, url: tab.url, title: tab.title };
}

/** Inject the content bridge into the tab's top frame and run one adapter. */
export async function runBridge(tabId: number, adapterId: string): Promise<RawExtraction> {
  await chrome.scripting.executeScript({ target: { tabId }, files: ['content.js'] });
  const [injection] = await chrome.scripting.executeScript({
    target: { tabId },
    func: (id: string) => {
      const bridge = (globalThis as { __reachoBridge?: { run(id: string): Promise<unknown> } }).__reachoBridge;
      if (!bridge) throw new Error('Reacho content bridge did not load.');
      return bridge.run(id);
    },
    args: [adapterId],
  });
  if (!injection || injection.result === undefined || injection.result === null) {
    throw new Error('The page returned no extraction result.');
  }
  return injection.result as RawExtraction;
}

export function hasOrigins(origins: string[]): Promise<boolean> {
  return origins.length ? chrome.permissions.contains({ origins }) : Promise.resolve(false);
}

export function describeAccessError(err: unknown): string {
  const message = err instanceof Error ? err.message : String(err);
  if (/Cannot access|permission|Missing host/i.test(message)) {
    return `Reacho has no access to this tab. Click the Reacho toolbar button (grants one-time access to this tab) or allow persistent access for this site. (${message})`;
  }
  return message;
}
